p = '/home/claude/v5/reel5.html'
src = open(p, encoding='utf-8').read()

def rep(old, new, cnt=1):
    global src
    assert src.count(old) == cnt, (src.count(old), old[:80])
    src = src.replace(old, new)

# ---- CSS ----
rep("#zoom{position:absolute;", """#a_box,#b_box,#i_box,#j_box,#anchor{display:none!important}
#b_p0,#b_p1,#b_p2{display:none}
#hero{position:absolute;overflow:visible;pointer-events:none;transform-origin:50% 85%}
#kw{position:absolute;top:524px;left:70px;right:140px;height:96px;font:800 84px M;letter-spacing:-3px;white-space:nowrap;line-height:1;color:var(--ink)}
#kw i{display:inline-block;font-style:normal;will-change:transform}
#kw .a{color:var(--acc)}
#kwu{position:absolute;height:9px;background:#E8452C;border-radius:5px;top:90px}
#zoom{position:absolute;""")

# ---- HTML: hero и баннер до gfx ----
rep('<div id="gfx">', '<svg id="hero" viewBox="-230 -360 460 480"></svg>\n  <div id="kw"></div>\n  <div id="gfx">')

# ---- папка: створка-трапеция, скрытие телефонов ----
rep("const FOL=(open,glow=0,big=0,U='x')=>{", "const FOL=(open,glow=0,big=0,U='x',ph=1)=>{")
rep("[-1,0,1].forEach((q,j)=>{const kk", "(ph?[-1,0,1]:[]).forEach((q,j)=>{const kk")
rep("[[-170,110],[170,110],[170,ft],[-170,ft]]", "[[-170,110],[170,110],[170+26*o,ft],[-170-26*o,ft]]")
rep('<rect x="-166" y="${ft+2}" width="332" height="9" fill="#F7EDD6"/>', '<rect x="${-166-26*o}" y="${ft+2}" width="${332+52*o}" height="9" fill="#F7EDD6"/>')

# ---- заголовок компактнее, чтобы баннер не налезал ----
rep("while(T.offsetHeight>250&&f>50)", "while(T.offsetHeight>225&&f>50)")

# ---- вызовы в seek ----
rep(" B[i]&&B[i](lt,t,Sb);\n const gx", " heroUpd(t,i,lt,kbk);kwUpd(t,i,lt);\n B[i]&&B[i](lt,t,Sb);\n const gx")
rep("ZIMG={3:'r8.jpg',7:'rose2.jpg'}", "ZIMG={3:'r0.jpg',7:'rose2.jpg'}")
rep("ZB={3:'#fp1b',7:'#e_ph'}", "ZB={3:'#fan3',7:'#e_ph'}")

NEW = r'''
/* ===================== v5: единая папка-герой, веер, баннер ключевого слова ===================== */
const eio=x=>{x=cl(x);return x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2};
// t, x, y, ширина svg, раскрытие
const KF=[[0,540,950,560,0],[.35,540,940,560,0],[1.0,540,940,560,1],[2.84,540,940,560,1],[3.3,470,900,440,1],[4.72,470,900,440,1],[5.2,470,1110,480,1],[5.999,470,1110,480,1],
 [6.0,135,1306,257,0],[25.31,135,1306,257,0],[25.75,470,1000,480,0],[26.1,470,1000,480,1],[26.23,470,1000,480,1],[26.75,720,990,400,1],[60,720,990,400,1]];
let HERO={x:540,y:940,w:560};
function heroUpd(t,i,lt,kbk){
 let a=KF[0],b=KF[1];for(let k=0;k<KF.length-1;k++){if(t>=KF[k][0]&&t<KF[k+1][0]){a=KF[k];b=KF[k+1];break}if(t>=KF[KF.length-1][0]){a=b=KF[KF.length-1]}}
 const u=b[0]>a[0]?cl((t-a[0])/(b[0]-a[0])):1,e=eio(u),L=(k)=>a[k]+(b[k]-a[k])*e;
 let x=L(1),y=L(2),W=L(3),open=L(4),glow=0;
 if(t>=2.84&&t<3.5)glow=1-(t-2.84)/.66;
 if([4,6,8,10].includes(i)){const s=lt<.3?eo(lt/.3):1-cl((lt-.3)/.4);open=Math.max(open,.6*s);glow=s}
 if(i==11)glow=cl((lt-.4)/.3)*(1-cl((lt-.7)/.3));
 if(i==12)glow=.5+.5*Math.sin(t*4);
 const wob=t<1.0?Math.sin(t*28)*Math.max(0,1-t/.9)*2.4:0,fl=Math.sin(t*2)*5,rot=wob+Math.sin(t*1.3)*(i>=3&&i<11?2:.8);
 const h=$("#hero"),H=W*480/460;HERO={x,y,w:W};
 h.style.width=W+"px";h.style.height=H+"px";h.style.left=(x-W/2)+"px";h.style.top=(y-H/2)+"px";h.style.transform=`translateY(${fl}px) rotate(${rot}deg)`;
 h.style.opacity=(i>=3&&i<=10)?1-kbk:1;
 h.innerHTML=FOL(open,glow,1,"h",(i==2&&lt>.12)?0:1);
}
const KW={0:["НЕ НЕЙРОСЕТЬ",0],1:["СДЕЛАНО КОДОМ",1],3:["ЭТО СЛОЖНО?",3],4:["ОДНА СТРОКА",4],5:["ОДНА СТРОКА",4],6:["САМ СОБИРАЕТ",6],7:["ДЁШЕВО?",7],8:["ЖИВОЕ",8],9:["КОМАНДА?",9],10:["ТЕКСТ + ГОЛОС",10],11:["ВСЁ — КОД",11],12:["КОД",12]};
let curKW=null;
function kwUpd(t,i,lt){const kw=$("#kw"),d=KW[i];
 if(!d){kw.style.display="none";curKW=null;return}
 kw.style.display="block";
 if(curKW!==d[1]+d[0]){curKW=d[1]+d[0];const ws=d[0].split(" ");
  kw.innerHTML=ws.map((w,j)=>`<span class="${j==ws.length-1?'a':''}" style="display:inline-block;margin-right:.25em">${[...w].map(c=>`<i>${c}</i>`).join("")}</span>`).join("")+`<div id="kwu"></div>`}
 const g=SC[d[1]].s,loc=t-g-.12;let n=i+1;while(KW[n]&&KW[n][1]==d[1])n++;const gEnd=n<SC.length?SC[n].s:END;
 [...kw.querySelectorAll("i")].forEach((c,q)=>{const e=eb((loc-q*.035)/.38);c.style.opacity=cl((loc-q*.035)/.07);c.style.transform=`translateY(${-(1-e)*70}px) scale(${1+(1-e)*.3}) rotate(${-(1-e)*6}deg)`});
 const last=kw.querySelector("span:last-of-type"),u=$("#kwu");if(last){u.style.left=last.offsetLeft+"px";u.style.width=(last.offsetWidth*eo((loc-.35)/.3))+"px"}
 const ex=cl((t-(gEnd-.2))/.2);kw.style.opacity=1-ex;kw.style.transform=`translateY(${-ex*20}px)`}

/* веер телефонов + терминал */
$("#bB").insertAdjacentHTML("beforeend",[0,1,2,3,4,5,6].map(j=>`<div class="ph fc" id="fan${j}" style="left:0;top:0;width:200px;height:356px;border-radius:30px;opacity:0"><div class="scr"><img src="as/${R[j]}.jpg"></div></div>`).join(""));
$("#b_cur").insertAdjacentText("beforebegin","/ролик про розы ");
$("#bA").insertAdjacentHTML("beforeend",`<div class="card" id="a_term" style="left:200px;top:610px;width:540px;background:#141414;color:#F1EEE7;border-color:#141414;opacity:0"><div class="mono" style="padding:14px 18px"><span style="color:#E8452C">✱ claude</span> · ~/код <span id="a_tt"></span><span id="a_cur" style="background:#F1EEE7">&nbsp;</span></div></div>`);
const TT="/ролик про розы ";

B[0]=(lt,t)=>{$("#a_code").style.opacity=0;$("#a_ph").style.opacity=0;const ai=$("#a_ai");tilt(ai,lt,1.0,.45);ai.style.filter+=` grayscale(${cl((lt-1.8)/.3)})`;
 $("#a_str").style.width=eo((lt-1.75)/.25)*110+"%";
 const s=$("#a_stamp"),k=eb((lt-2.05)/.25),sh=lt>2.05&&lt<2.35?Math.sin(t*70)*8:0;s.style.opacity=cl((lt-2.05)/.05);s.style.transform=`rotate(-10deg) scale(${2.6-1.6*k}) translateX(${sh}px)`;
 tilt($("#a_term"),lt,.85,.35);$("#a_tt").textContent=TT.slice(0,Math.floor(cl((lt-1.0)/1.2)*TT.length));$("#a_cur").style.opacity=(t*2%1)<.5?1:0};
B[1]=(lt,t)=>{const k=ei(lt/.3);const ai=$("#a_ai"),stp=$("#a_stamp");[ai,stp].forEach(e=>{e.style.transform=`translate(0px,${-150*k}px) scale(${1-.9*k}) rotate(${15*k}deg)`;e.style.opacity=1-cl((lt-.22)/.1);e.style.filter=`blur(${k*5}px)`});
 const at=$("#a_term");at.style.opacity=1;at.style.transform="none";at.style.filter="none";$("#a_tt").textContent=TT;$("#a_cur").style.opacity=(t*2%1)<.5?1:0;
 tilt($("#a_code"),lt,.55,.4,"rotate(-2deg)");$("#a_fr").textContent=String(136+Math.floor(lt*30)).padStart(4,"0");pop($("#a_ph"),lt,1.1,.4,`rotate(4deg) translateY(${Math.sin(t*2)*6}px)`);};
B[2]=(lt,t)=>{const P={x:HERO.x,y:HERO.y+60-630},R0=300;
 for(let j=0;j<7;j++){const c=$("#fan"+j),a=(-54+18*j)*Math.PI/180,s=eb((lt-.04-j*.065)/.5),sk=cl(s),sa=Math.max(0,s);
  const rr=R0*sa,aa=a*(.55+.45*sa),cx=P.x+Math.sin(aa)*rr,cy=P.y-Math.cos(aa)*rr+Math.sin(t*2+j)*(lt>.7?4:0);
  c.style.left=(cx-100)+"px";c.style.top=(cy-178)+"px";c.style.zIndex=10-Math.abs(j-3);
  c.style.opacity=cl((lt-.04-j*.065)/.05);c.style.filter=`blur(${(1-sk)*4}px)`;
  c.style.transform=`rotate(${a*180/Math.PI*sa+(1-sk)*(j%2?170:-170)+(lt>.7?Math.sin(t*1.5+j)*1.2:0)}deg) scale(${.35+.65*sa})`}
 tilt($("#b_term"),lt,.45,.3);$("#b_cur").style.opacity=(t*2%1)<.5?1:0;};
B[11]=(lt,t)=>{const k=eo(lt/.45);$("#i_cA").style.transform=`translate(${300*k}px,${210*k}px) scale(${1-.8*k}) rotate(${20*k}deg)`;$("#i_cB").style.transform=`translate(${-300*k}px,${210*k}px) scale(${1-.8*k}) rotate(${-20*k}deg)`;
 $("#i_cA").style.opacity=$("#i_cB").style.opacity=1-cl((lt-.4)/.08);$("#i_cA").style.filter=$("#i_cB").style.filter=`blur(${Math.sin(k*3.14)*5}px)`};
B[12]=(lt,t)=>{
 const tx="КОД",pr=cl((lt-.45)/.6)*3,n=Math.min(3,Math.floor(pr+.4));$("#j_tx").textContent=lt<.45?"":tx.slice(0,n);if(lt>=.45&&pr<3&&pr%1<.6)PRESS=tx[Math.floor(pr)].toLowerCase();
 const s=$("#j_send"),sk=lt>1.2&&lt<1.45;s.style.transform=`scale(${sk?.85:1})`;s.style.boxShadow=lt>1.2?`0 0 0 ${cl((lt-1.2)/.5)*30}px rgba(20,20,20,${.3*(1-cl((lt-1.2)/.5))})`:"none";
 pop($("#j_pr"),lt,1.45,.35,"rotate(-2deg)");
 $$(".j_c").forEach((c,j)=>{const at=1.7+j*.28,p=cl((lt-at)/1.8);c.style.opacity=lt<at?0:1-cl((p-.8)/.2);c.style.transform=`translateY(${640-p*600}px) rotate(${(j%2?4:-4)}deg)`})};
'''
rep("window.seek=seek;", NEW + "window.seek=seek;")
open(p, 'w', encoding='utf-8').write(src)
print('ok', len(src))
