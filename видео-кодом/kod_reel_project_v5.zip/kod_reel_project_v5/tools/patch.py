import re, sys
src = open('/home/claude/work/reel4_src.html', encoding='utf-8').read()

def rep(old, new, cnt=1):
    global src
    assert src.count(old) == cnt, (src.count(old), old[:70])
    src = src.replace(old, new)

def chunk(start, end, new):
    global src
    a = src.index(start); b = src.index(end, a)
    src = src[:a] + new + src[b:]

# ---------- 1. фон: белая миллиметровка ----------
rep("--ink:#141414;--grey:#b9b5ad;--bg:#EDEAE3;--acc:#E8452C;--sh:#141414;background:var(--bg);color:var(--ink)}",
    "--ink:#141414;--grey:#b9b5ad;--bg:#FFFFFF;--acc:#E8452C;--sh:#141414;--g1:rgba(20,20,20,.07);--g2:rgba(20,20,20,.15);color:var(--ink);background-color:var(--bg);"
    "background-image:linear-gradient(var(--g2) 2px,transparent 2px),linear-gradient(90deg,var(--g2) 2px,transparent 2px),linear-gradient(var(--g1) 1px,transparent 1px),linear-gradient(90deg,var(--g1) 1px,transparent 1px);"
    "background-size:200px 200px,200px 200px,40px 40px,40px 40px}")
rep("#stage.dark{--ink:#F1EEE7;--grey:#4a4a4a;--bg:#121212;--sh:#000}",
    "#stage.dark{--ink:#F1EEE7;--grey:#4a4a4a;--bg:#121212;--sh:#000;--g1:rgba(255,255,255,.055);--g2:rgba(255,255,255,.12)}")
rep("#stage.orange{--ink:#fff;--grey:#ffb39f;--bg:#E8452C;--acc:#141414;--sh:#141414}",
    "#stage.orange{--ink:#fff;--grey:#ffb39f;--bg:#E8452C;--acc:#141414;--sh:#141414;--g1:rgba(255,255,255,.16);--g2:rgba(255,255,255,.3)}")
rep("</style>", """#ht1,#ht2{display:none}
#kb{position:absolute;left:57px;top:1190px;width:906px;padding:14px;background:#E3E1DA;border:3px solid #141414;border-radius:26px;box-shadow:10px 10px 0 var(--sh);z-index:20;display:none;color:#141414}
.krow{display:flex;gap:8px;margin-bottom:10px;justify-content:center}.krow:last-child{margin-bottom:0}
.key{width:72px;height:60px;border:2px solid #141414;border-radius:11px;background:#fff;display:grid;place-items:center;font:800 30px M;color:#141414;box-shadow:0 3px 0 #141414}
.key.on{background:#E8452C;color:#fff;transform:translateY(3px);box-shadow:none}
#kbub{position:absolute;width:84px;height:80px;background:#fff;border:3px solid #141414;border-radius:14px;place-items:center;font:800 46px M;display:none;z-index:3;box-shadow:4px 4px 0 #141414}
#zoom{position:absolute;display:none;z-index:50;box-sizing:border-box}
#zoom .scr{background:transparent}
</style>""")
rep('const BG={"":"#EDEAE3"', 'const BG={"":"#FFFFFF"')

# ---------- 2. папка вместо коробки ----------
rep('viewBox="-200 -230 400 400"', 'viewBox="-230 -360 460 480"')
a = src.index("function heroBox("); b = src.index("const svgBox=")
src = src[:a] + r'''const FOL=(open,glow=0,big=0,U='x')=>{
 const o=cl(open),ft=-110+130*eo(o),P=q=>q.map(p=>p.join(",")).join(" ");
 const back=[[-170,-120],[-170,-148],[-62,-148],[-38,-120],[170,-120],[170,110],[-170,110]];
 let s=`<defs><clipPath id="fcl${U}"><rect x="-400" y="-420" width="800" height="530"/></clipPath><clipPath id="pcb${U}"><rect x="7" y="7" width="156" height="286" rx="18"/></clipPath><clipPath id="pcs${U}"><rect x="7" y="7" width="110" height="210" rx="13"/></clipPath></defs>`;
 s+=`<g transform="translate(12 12)"><polygon points="${P(back)}" fill="#141414" stroke="#141414" stroke-width="4" stroke-linejoin="round"/></g>`;
 if(glow)s+=`<ellipse cx="0" cy="-60" rx="${120+80*glow}" ry="${70+40*glow}" fill="#E8452C" opacity="${.35*glow}"/>`;
 s+=`<polygon points="${P(back)}" fill="#D9C29A" stroke="#141414" stroke-width="4" stroke-linejoin="round"/>`;
 const w=big?170:124,h=big?300:224,imgs=["r6","r8","r10"];
 s+=`<g clip-path="url(#fcl${U})">`;
 [-1,0,1].forEach((q,j)=>{const kk=eo(cl(o*1.5-j*.18)),cx=q*(big?104:78)*kk,top=10+(-(big?335:250)+Math.abs(q)*(big?36:26)-10)*kk,rot=q*11*kk;
  s+=`<g ${q==0?`id="fp1${U}"`:''} transform="translate(${cx.toFixed(1)} ${(top+h).toFixed(1)}) rotate(${rot.toFixed(1)}) translate(${-w/2} ${-h})"><rect width="${w}" height="${h}" rx="${big?24:18}" fill="#141414"/><image href="as/${imgs[j]}.jpg" x="7" y="7" width="${w-14}" height="${h-14}" preserveAspectRatio="xMidYMid slice" clip-path="url(#${big?'pcb':'pcs'}${U})"/></g>`});
 s+=`</g>`;
 s+=`<polygon points="${P([[-170,110],[170,110],[170,ft],[-170,ft]])}" fill="#EBDDBF" stroke="#141414" stroke-width="4" stroke-linejoin="round"/><rect x="-166" y="${ft+2}" width="332" height="9" fill="#F7EDD6"/>`;
 const lh=Math.min(110-ft-32,86),fs=lh*.74;
 s+=`<rect x="-148" y="${ft+18}" width="236" height="${lh}" rx="6" fill="#FAF7F0" stroke="#141414" stroke-width="3"/><text x="-134" y="${(ft+18+lh/2+fs*.36).toFixed(1)}" style="font:800 ${fs.toFixed(0)}px M;fill:#141414">КОД</text>`;
 s+=`<rect x="116" y="${ft}" width="28" height="${110-ft}" fill="#E8452C" stroke="#141414" stroke-width="3"/>`;
 return s};
function heroBox(open,lid=1,glow=0,big=0,U='x'){return FOL(open*lid,glow,big,U)}
''' + src[b:]

rep('viewBox="-120 -170 240 230"', 'viewBox="-200 -200 400 330"')
rep("an.style.opacity=showA?1:0;", "an.style.opacity=showA?1-kbk:0;")
rep("an.innerHTML=DEFS+heroBox(1,1,suck);", "an.innerHTML=heroBox(suck*.6,1,suck,0,'n');")

# ---------- 3. kbk, PRESS ----------
rep("const Sb=SC[i],lt=t-Sb.s;",
    "const Sb=SC[i],lt=t-Sb.s;PRESS=null;\n let kbk=0;if(i==4)kbk=eo(lt/.4);else if(i==5)kbk=1;else if(i==6)kbk=1-ei(lt/.35);else if(i==12)kbk=eo(lt/.4)*(1-ei((lt-1.6)/.35));")
rep("${Math.sin(t*2.3)*5+(1-pk)*50}px)", "${Math.sin(t*2.3)*5+(1-pk)*50+kbk*360}px)")
rep("let curBeat=-1;", "let curBeat=-1,PRESS=null;")

# ---------- 4. мягкий текст ----------
a = src.index(" ws.forEach((w,j)=>{const at="); b = src.index(" // персонаж")
src = src[:a] + ''' ws.forEach((w,j)=>{const at=(m?Sb.wt[Math.min(m-1,Math.floor(j*m/ws.length))]:Sb.s+j*.25)-Sb.s;
  if(w.classList.contains("k")){w.style.opacity=1;[...w.children].forEach((c,q)=>{const e=eo((lt-at-q*.045)/.42);c.style.opacity=e;c.style.transform=`translateY(${(1-e)*26}px) scale(${.82+.18*e})`;c.style.filter=`blur(${(1-e)*4}px)`})}
  else{const op=eo((lt-at+.35)/.3),p=eo((lt-at)/.24);w.style.opacity=op;w.style.color=`color-mix(in srgb,var(--ink) ${(p*100).toFixed(0)}%,var(--grey))`;w.style.transform=`translateY(${(1-op)*10}px)`;w.style.filter=`blur(${(1-op)*3}px)`}});
''' + src[b:]

# ---------- 5. шторка только там, где нет влёта в телефон ----------
rep("if(sx[0]>0&&t-bound<.25){", "if(sx[0]>0&&!ZB[sx[0]]&&t-bound<.25){")
rep("if(nextSec&&SC[nextSec[0]].s-t<.28){", "if(nextSec&&!ZB[nextSec[0]]&&SC[nextSec[0]].s-t<.28){")
rep("const BG={", "const ZB={3:'#fp1b',7:'#e_ph'},ZIMG={3:'r8.jpg',7:'rose2.jpg'};\nconst BG={")

# ---------- 6. HTML: zoom и клавиатура ----------
rep('<canvas id="wipe" width="540" height="960" style="width:1080px;height:1920px"></canvas>',
    '<canvas id="wipe" width="540" height="960" style="width:1080px;height:1920px"></canvas>\n <div id="kb"></div>\n <div id="zoom" class="ph"><div class="scr"><img id="zimg"><div id="zfill" style="position:absolute;inset:0"></div></div></div>')

# ---------- 7. сцены ----------
rep('<span style="margin-left:auto;color:#E8452C">рендер 3%</span>', '<span id="c_pc" style="margin-left:auto;color:#E8452C">рендер 3%</span>')
rep('style="left:560px;top:320px;width:320px;padding:10px;background:#fff;transform-origin:50% 100%"><img src="as/rose1.jpg" style="width:100%;height:300px',
    'style="left:610px;top:290px;width:290px;padding:10px;background:#fff;transform-origin:50% 100%"><img src="as/rose1.jpg" style="width:100%;height:200px')
rep('const GRP=["bA","bA","bB","bC","bD","bD","bE","bF","bF",', 'const GRP=["bA","bA","bB","bC","bD","bD","bE","bF","bK",')

# клавиатура + плитки стилей
rep("/* ===== группы:", r'''const KR=["йцукенгшщзх","фывапролджэ","ячсмитьбю"],KEYS=[],KMAP={};
$("#kb").innerHTML=`<div id="kbub"></div>`+KR.map(r=>`<div class="krow">${[...r].map(c=>`<span class="key" data-c="${c}">${c.toUpperCase()}</span>`).join("")}</div>`).join("")+`<div class="krow"><span class="key" data-c=" " style="width:600px;font:500 20px J">пробел</span><span class="key" style="width:120px;background:#E8452C;color:#fff">↵</span></div>`;
document.querySelectorAll("#kb .key").forEach(e=>{KEYS.push(e);if(e.dataset.c)KMAP[e.dataset.c]=e});
const tile=(id,n,body,x,y,bg)=>`<div class="card s_t" id="${id}" style="left:${x}px;top:${y}px;width:440px;height:320px;background:${bg||'#fff'}"><div class="bar"><span style="color:#E8452C">●</span> ${n}<span style="margin-left:auto;opacity:.5">живое</span></div>${body}</div>`;
const ABS="position:absolute;left:0;right:0;top:52px;bottom:0;";
$("#bK").innerHTML=
 tile("s_a","ШРИФТЫ",`<div id="s0" style="${ABS}display:flex;align-items:center;justify-content:center">${[..."Живое"].map(c=>`<i style="display:inline-block;font-style:normal;margin:0 2px">${c}</i>`).join("")}</div><div class="mono" style="position:absolute;left:18px;bottom:12px;font-size:16px;opacity:.5">Manrope 800 ↔ Playfair italic</div>`,20,0)+
 tile("s_b","ГРАФИКА",`<svg id="s1" viewBox="0 0 440 268" style="position:absolute;left:0;top:52px;width:440px;height:268px"></svg>`,480,0)+
 tile("s_c","ПЕРСОНАЖ",`<div style="${ABS}background:#2B59D9;overflow:hidden"><div style="position:absolute;inset:0;background:radial-gradient(rgba(255,255,255,.25) 1.8px,transparent 2.2px) 0 0/12px 12px"></div><img id="s2" style="position:absolute;left:50px;top:30px;width:340px"></div>`,20,345)+
 tile("s_d","ЦВЕТА",`<div id="s3" style="${ABS}display:flex;gap:10px;padding:16px 18px 40px">${["#E8452C","#2B59D9","#141414","#EDEAE3","#ffb39f"].map(c=>`<div style="flex:1;position:relative;border:2px solid #141414;border-radius:10px;overflow:hidden;background:#fff"><div class="sw" style="position:absolute;left:0;right:0;bottom:0;background:${c}"></div></div>`).join("")}</div><div class="mono" style="position:absolute;left:18px;bottom:10px;font-size:16px;opacity:.55">#E8452C · #2B59D9 · #141414 …</div>`,480,345)+
 `<div id="s_pose" style="display:none"></div>`;

/* ===== группы:''')

# B[2]
chunk("B[2]=", "B[3]=", '''B[2]=(lt,t)=>{$("#b_bs").innerHTML=heroBox(cl((lt-.05)/.5),1,0,1,"b");tilt($("#b_term"),lt,.45,.3);$("#b_cur").style.opacity=(t*2%1)<.5?1:0;};
''')
rep('B[3]=(lt,t)=>{$("#c_ph")', 'B[3]=(lt,t)=>{$("#c_pc").textContent="рендер "+Math.floor(3+cl(lt/1.3)*34)+"%";$("#c_ph")')
# B[5]
chunk("B[5]=", "B[6]=", '''B[5]=(lt,t)=>{const tx="сделай ролик, почему розы пахнут слабее садовых",L=tx.length,pr=cl(lt/2.0)*L,n=Math.min(L,Math.floor(pr+.4));
 $("#d_tx").textContent=tx.slice(0,n);$("#d_cnt").textContent=n+" символов";$("#d_cur").style.opacity=(t*2%1)<.5?1:0;
 if(pr<L&&pr%1<.6)PRESS=tx[Math.floor(pr)];
 const im=$("#d_img");const k=eb((lt-1.0)/.45);im.style.opacity=cl((lt-1)/.08);im.style.transform=`rotate(${5-2*k}deg) scale(${.4+.6*k}) translateY(${Math.sin(t*1.6)*5}px)`;pop($("#d_q"),lt,2.2,.3,"rotate(-6deg)");};
''')
# B[8]
chunk("B[8]=", "B[9]=", '''B[8]=(lt,t,Sb)=>{const w=Sb.wt,idx=[0,1,2,8];
 $$(".s_t").forEach((c,j)=>{const at=Math.max(0,(w[idx[j]]??Sb.s)-Sb.s-.05);pop(c,lt,at,.42,`translateY(${Math.sin(t*3+j)*4}px)`);const on=lt>=at&&lt<at+.9;c.style.borderColor=on?"#E8452C":"#141414"});
 [...$("#s0").children].forEach((c,j)=>{const alt=(Math.floor(t*2)+j)%2;c.style.font=alt?"italic 500 112px P":"800 96px M";c.style.color=alt?"#E8452C":"#141414";c.style.transform=`translateY(${Math.sin(t*5+j*.8)*16}px) rotate(${Math.sin(t*4+j)*7}deg)`});
 let g=`<circle cx="${220+Math.cos(t*2.2)*120}" cy="${134+Math.sin(t*2.2)*48}" r="26" fill="#2B59D9" stroke="#141414" stroke-width="4"/>`;
 g+=`<rect x="-34" y="-34" width="68" height="68" fill="#E8452C" stroke="#141414" stroke-width="4" transform="translate(${220+Math.cos(t*2.2+3.14)*120} ${134+Math.sin(t*2.2+3.14)*48}) rotate(${t*90})"/>`;
 for(let q=0;q<9;q++){const hh=14+Math.abs(Math.sin(t*3+q*.7))*70;g+=`<rect x="${30+q*44}" y="${250-hh}" width="30" height="${hh}" fill="${q%3==0?'#E8452C':'#141414'}" rx="4"/>`}
 g+=`<polygon points="220,40 250,92 190,92" fill="#fff" stroke="#141414" stroke-width="4" transform="rotate(${Math.sin(t*2)*25} 220 70)"/>`;
 $("#s1").innerHTML=g;
 const poses=["talk","wave","guns","fingerUp"],pn=poses[Math.floor(t*1.6)%4],im=$("#s2");if(im.dataset.p!==pn){im.src="poses/"+pn+".png";im.dataset.p=pn}im.style.transform=`translateY(${Math.abs(Math.sin(t*3.2))*-10}px) rotate(${Math.sin(t*3.2)*2}deg)`;
 $$("#s3 .sw").forEach((s,j)=>{s.style.height=(22+Math.abs(Math.sin(t*1.8+j*.9))*72)+"%"})};
''')
# B[12]
chunk("B[12]=", "window.seek=", '''B[12]=(lt,t)=>{$("#j_bs").innerHTML=heroBox(1,1,.5+.5*Math.sin(t*4),0,"j");pop($("#j_box"),lt,.1,.45,`rotate(${Math.sin(t*2)*2}deg)`);
 const tx="КОД",pr=cl((lt-.45)/.6)*3,n=Math.min(3,Math.floor(pr+.4));$("#j_tx").textContent=lt<.45?"":tx.slice(0,n);if(lt>=.45&&pr<3&&pr%1<.6)PRESS=tx[Math.floor(pr)].toLowerCase();
 const s=$("#j_send"),sk=lt>1.2&&lt<1.45;s.style.transform=`scale(${sk?.85:1})`;s.style.boxShadow=lt>1.2?`0 0 0 ${cl((lt-1.2)/.5)*30}px rgba(20,20,20,${.3*(1-cl((lt-1.2)/.5))})`:"none";
 pop($("#j_pr"),lt,1.45,.35,"rotate(-2deg)");
 $$(".j_c").forEach((c,j)=>{const at=1.7+j*.28,p=cl((lt-at)/1.8);c.style.opacity=lt<at?0:1-cl((p-.8)/.2);c.style.transform=`translateY(${640-p*600}px) rotate(${(j%2?4:-4)}deg)`})};
''')

# ---------- 8. хвост seek: сетка, клавиатура, влёт в телефон ----------
rep(" B[i]&&B[i](lt,t,Sb);\n}", r''' B[i]&&B[i](lt,t,Sb);
 const gx=(t*7).toFixed(1),gy=(t*4).toFixed(1);st.style.backgroundPosition=[0,1,2,3].map(()=>`${gx}px ${gy}px`).join(",");
 const kb=$("#kb");kb.style.display=kbk>.002?"block":"none";kb.style.transform=`translateY(${(1-kbk)*560}px)`;
 KEYS.forEach(e=>e.classList.remove("on"));const bub=$("#kbub");bub.style.display="none";
 if(PRESS&&KMAP[PRESS]){const e=KMAP[PRESS];e.classList.add("on");if(PRESS!==" "){bub.style.display="grid";bub.textContent=PRESS.toUpperCase();bub.style.left=(e.offsetLeft-6)+"px";bub.style.top=(e.offsetTop-86)+"px"}}
 const zo=$("#zoom");let zv=null;for(const k in ZB){const b=SC[+k].s;if(t>=b-.55&&t<b+.4)zv=+k}
 if(zv===null)zo.style.display="none";else{const b=SC[zv].s,p=cl((t-(b-.55))/.55),k2=Math.pow(p,2.2);let r={x:0,y:0,width:240,height:420};const el=document.querySelector(ZB[zv]);if(el&&t<b)r=el.getBoundingClientRect();
  zo.style.display="block";zo.style.left=(r.x+(-40-r.x)*k2)+"px";zo.style.top=(r.y+(-40-r.y)*k2)+"px";zo.style.width=(r.width+(1160-r.width)*k2)+"px";zo.style.height=(r.height+(2000-r.height)*k2)+"px";
  zo.style.borderRadius=(36*(1-k2))+"px";zo.style.padding=(10*(1-k2))+"px";zo.style.opacity=t<b?1:1-cl((t-b-.1)/.25);
  const zi=$("#zimg");zi.src="as/"+ZIMG[zv];zi.style.opacity=1-cl((p-.5)/.35);const zf=$("#zfill");zf.style.background=BG[SECT.find(x=>x[0]==zv)[3]];zf.style.opacity=cl((p-.7)/.25)}
}''')

rep('<div id="a_box" style="position:absolute;left:250px;top:30px;width:440px">${svgBox("a_bs",440)}','<div id="a_box" style="position:absolute;left:170px;top:20px;width:600px">${svgBox("a_bs",600)}')
rep('bx.style.left="250px";','bx.style.left="170px";')
rep('heroBox(cl((lt-.3)/.6),eo((lt-.2)/.4))','heroBox(cl((lt-.3)/.6),eo((lt-.2)/.4),0,0,"a")')
rep('heroBox(cl((lt-.4)/.6),1,cl(1-(lt-.2)/.6))','heroBox(cl((lt-.4)/.6),1,cl(1-(lt-.2)/.6),0,"a")')
rep('heroBox(cl((lt-.4)/.5),1,cl((lt-.3)/.3)*(1-cl((lt-.7)/.3)))','heroBox(cl((lt-.4)/.5),1,cl((lt-.3)/.3)*(1-cl((lt-.7)/.3)),0,"i")')
open('/home/claude/v5/reel5.html', 'w', encoding='utf-8').write(src)
print('ok', len(src))
