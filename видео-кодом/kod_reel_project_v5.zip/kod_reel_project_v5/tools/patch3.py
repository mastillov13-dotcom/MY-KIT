import re
p = '/home/claude/v5/reel5.html'
src = open(p, encoding='utf-8').read()

def rep(old, new, cnt=1):
    global src
    assert src.count(old) == cnt, (src.count(old), old[:90])
    src = src.replace(old, new)

def chunk(start, end, new):
    global src
    a = src.index(start); b = src.index(end, a)
    src = src[:a] + new + src[b:]

# ---------- цвета и сетка как в референсе ----------
rep("</style>", """#stage{--bg:#ECECE5;--g1:rgba(20,20,20,.055);background-image:linear-gradient(var(--g1) 1px,transparent 1px),linear-gradient(90deg,var(--g1) 1px,transparent 1px)!important;background-size:10px 10px,10px 10px!important}
#stage.dark{--bg:#11110E;--g1:rgba(255,255,255,.05)}
#stage.orange{--bg:#F54513;--g1:rgba(255,255,255,.11)}
#title{font-weight:700!important;letter-spacing:-1px!important}
#pxc{position:absolute;left:0;top:0;width:1080px;height:1920px;pointer-events:none;z-index:15}
</style>""")
rep('const BG={"":"#FFFFFF",dark:"#121212",orange:"#E8452C"}', 'const BG={"":"#ECECE5",dark:"#11110E",orange:"#F54513"}')
rep("#myth{position:absolute;left:220px;top:1330px", "#myth{position:absolute;left:300px;top:1330px")

# ---------- без смахов и влёта в телефон ----------
rep("if(sx[0]>0&&!ZB[sx[0]]&&t-bound<.25){", "if(false){")
rep("if(nextSec&&!ZB[nextSec[0]]&&SC[nextSec[0]].s-t<.28){", "if(false){")
rep("ZB={3:'#fan3',7:'#e_ph'}", "ZB={}")
rep("if(prev&&prev!==cur&&lt<.3&&SECT.every(x=>x[0]!==i)){", "if(prev&&prev!==cur&&lt<.3){")
rep("P.style.filter=\"none\";P.style.transform=`translate(${-560*k}px,${700*k}px) scale(${1-.85*k}) rotate(${-25*k}deg)`;",
    "P.style.filter=`blur(${k*4}px)`;P.style.transform=`translate(${56*k}px,${58*k}px) scale(${1-.9*k}) rotate(${-25*k}deg)`;")
rep("if(prev!==cur){tilt(C0,lt,0,.42)}", "if(prev!==cur){(EMG.has(i)?emerge:tilt)(C0,lt,0,.45)}")
rep("const tilt=(el,lt,at=0,dur=.45,extra=\"\")=>{", "const tilt=(el,lt,at=0,dur=.45,extra=\"\")=>{el.style.transformOrigin=\"50% 50%\";")
rep("PRESS=null;\n let kbk=0;", "PRESS=null;TNOW=t;\n let kbk=0;")
rep("let curBeat=-1,PRESS=null;", "let curBeat=-1,PRESS=null,TNOW=0;")

# терминал правее, чтобы не лез на папку в углу
rep('id="a_term" style="left:200px;top:610px', 'id="a_term" style="left:290px;top:610px')
rep('id="b_term" style="left:200px;top:610px', 'id="b_term" style="left:290px;top:610px')

# ---------- субтитры: мельче, без акцентных слов ----------
rep('let k=key;if(w.startsWith("*")){k=true;key=true;w=w.slice(1)}if(w.endsWith("*")){w=w.slice(0,-1);key=false}', 'let k=false;w=w.replace(/\\*/g,"");')
rep("let f=74;", "let f=58;")

# ---------- миниатюры монтажки без видео-кадров ----------
rep('${R.slice(0,8).map(r=>`<img src="as/${r}.jpg" style="width:92px;height:62px;object-fit:cover;border:2px solid #141414;border-radius:6px">`).join("")}',
    '${["#E8452C","r8","#2B59D9","#141414","r10","#d6d2ca","#ffb39f","#8A6B4E"].map(c=>c[0]=="#"?`<div style="width:92px;height:62px;border:2px solid #141414;border-radius:6px;background:${c};position:relative;flex:none"><i style="position:absolute;left:12px;top:14px;width:26px;height:26px;border-radius:50%;background:rgba(255,255,255,.55)"></i></div>`:`<img src="as/${c}.jpg" style="width:92px;height:62px;object-fit:cover;border:2px solid #141414;border-radius:6px">`).join("")}')

# ---------- canvas для пикселей ----------
rep('<svg id="face" viewBox="0 0 797 900"></svg></div>', '<svg id="face" viewBox="0 0 797 900"></svg></div>\n <canvas id="pxc" width="1080" height="1920"></canvas>')

# ---------- телефоны в папке: живые экраны ----------
rep('<image href="as/${imgs[j]}.jpg" x="7" y="7" width="${w-14}" height="${h-14}" preserveAspectRatio="xMidYMid slice" clip-path="url(#${big?\'pcb\':\'pcs\'}${U})"/>',
    '<g clip-path="url(#${big?\'pcb\':\'pcs\'}${U})">${phoneArt([0,6,2][j],w-14,h-14,TNOW).replace("<svg ",\'<svg x="7" y="7" \')}</g>')

# ---------- фан-карточки: живые экраны ----------
rep('<div class="scr"><img src="as/${R[j]}.jpg"></div></div>`).join(""));', '<div class="scr"></div></div>`).join(""));')

# ---------- баннер: новые тезисы + автоподгон ширины ----------
chunk("const KW={", "let curKW=null;", '''const KW={0:["ВИДЕО БЕЗ КАМЕРЫ",0],1:["РЕЖИССЁР — КОД",1],3:["ПРОЩЕ, ЧЕМ КАЖЕТСЯ",3],4:["СТРОКА В ВИДЕО",4],5:["СТРОКА В ВИДЕО",4],6:["КОНВЕЙЕР БЕЗ ТЕБЯ",6],7:["ВКУС, А НЕ ШАБЛОН",7],8:["ВСЁ ДВИЖЕТСЯ",8],9:["ШТАТ НЕ НУЖЕН",9],10:["ДВА ФАЙЛА — И ВСЁ",10],11:["ДАЛЬШЕ — САМО",11],12:["ЗАБЕРИ СТАРТ",12]};
''')
rep('+`<div id="kwu"></div>`}\n', '+`<div id="kwu"></div>`;kw.style.fontSize="84px";let fz=84;while(kw.scrollWidth>870&&fz>48){fz-=4;kw.style.fontSize=fz+"px"}}\n')

# ---------- новая траектория папки + пульсы ----------
chunk("const KF=[", "let HERO=", '''const KF=[[0,540,950,560,0],[.35,540,940,560,0],[1.0,540,940,560,1],[2.84,540,940,560,1],[3.3,470,900,440,1],[4.2,470,900,440,1],[4.95,150,1300,300,1],[5.5,150,1300,300,1],[5.9,150,1300,300,0],[60,150,1300,300,0]];
''')
chunk("function heroUpd(", "const KW={", r'''const GCH=SC.map((s,k)=>k>=2&&GRP[k]!==GRP[k-1]),EMG=new Set([3,6,8,10,12]);
const emerge=(el,lt,at=0,dur=.45)=>{const k=eb((lt-at)/dur);el.style.transformOrigin="150px 670px";el.style.opacity=cl((lt-at)/.1);el.style.transform=`scale(${.12+.88*k})`;el.style.filter=`blur(${(1-cl(k))*5}px)`};
function heroUpd(t,i,lt,kbk){
 let a=KF[0],b=KF[1];for(let k=0;k<KF.length-1;k++){if(t>=KF[k][0]&&t<KF[k+1][0]){a=KF[k];b=KF[k+1];break}if(t>=KF[KF.length-1][0]){a=b=KF[KF.length-1]}}
 const u=b[0]>a[0]?cl((t-a[0])/(b[0]-a[0])):1,e=eio(u),L=(k)=>a[k]+(b[k]-a[k])*e;
 let x=L(1),y=L(2),W=L(3),open=L(4),glow=0;
 if(t>=2.84&&t<3.5)glow=1-(t-2.84)/.66;
 if(GCH[i]){const s=lt<.3?eo(lt/.3):1-cl((lt-.3)/.4);open=Math.max(open,.8*s);glow=Math.max(glow,s)}
 if(i==11){const s=cl((lt-.25)/.2)*(1-cl((lt-.6)/.4));open=Math.max(open,.9*s);glow=Math.max(glow,s)}
 const wob=t<1.0?Math.sin(t*28)*Math.max(0,1-t/.9)*2.4:0,fl=Math.sin(t*2)*5,rot=wob+Math.sin(t*1.3)*(t>5?2:.8);
 const h=$("#hero"),H=W*480/460;HERO={x,y,w:W};
 h.style.width=W+"px";h.style.height=H+"px";h.style.left=(x-W/2)+"px";h.style.top=(y-H/2)+"px";h.style.transform=`translateY(${fl}px) rotate(${rot}deg)`;
 h.style.opacity=1-kbk;
 h.innerHTML=FOL(open,glow,1,"h",(i==2&&lt>.12)?0:1);
}
''')

# ---------- живые экраны телефонов + пиксели ----------
NEW = r'''
/* ===== экраны телефонов (SVG, анимируются от t) ===== */
const rnd=(a,b)=>{const x=Math.sin(a*127.1+b*311.7)*43758.5453;return x-Math.floor(x)};
const esc=s=>s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const fmt=n=>String(n).replace(/\B(?=(\d{3})+(?!\d))/g," ");
function phoneArt(k,w,h,t){const fs=w/14.5;let s="",bg="#141414";
 if(k==0){const L=["R.scene('хук', c => {","  R.text('не ИИ')","  R.type(prompt)","  R.fan(folder)","  R.render('mp4')","})","// 1080x1920 · 30fps","R.voice('Леонид')","R.sfx.pop()"],n=Math.floor((t%5)*18);
  s=`<rect width="${w}" height="${h*.07}" fill="#222"/><circle cx="${w*.08}" cy="${h*.035}" r="${w*.025}" fill="#E8452C"/>`;
  L.forEach((ln,q)=>{const c=Math.max(0,Math.min(ln.length,n-q*8));s+=`<text x="${w*.07}" y="${h*.13+q*fs*2}" style="font:500 ${fs}px J;fill:${q%3==0?'#ff8a6b':'#cfd2c8'}">${esc(ln.slice(0,c))}</text>`});
  const cq=Math.min(L.length-1,Math.floor(n/8));if((t*2)%1<.5)s+=`<rect x="${w*.07+Math.min(L[cq].length,Math.max(0,n-cq*8))*fs*.6}" y="${h*.13+cq*fs*2-fs}" width="${fs*.55}" height="${fs*1.15}" fill="#E8452C"/>`}
 else if(k==1){bg="#F5F3EE";s=`<text x="${w*.08}" y="${h*.09}" style="font:500 ${fs}px J;fill:#141414">голос · Леонид</text><circle cx="${w*.9}" cy="${h*.075}" r="${fs*.4}" fill="#E8452C"/>`;
  const nB=14,bw=w*.8/nB;for(let j=0;j<nB;j++){const a=AMP[Math.min(AMP.length-1,Math.max(0,Math.floor(t*30)-j*2))]||0,bh=h*.04+a*h*.34;s+=`<rect x="${w*.1+j*bw}" y="${h*.46-bh/2}" width="${bw*.62}" height="${bh}" rx="${bw*.25}" fill="#E8452C" stroke="#141414" stroke-width="1.5"/>`}
  s+=`<text x="${w*.08}" y="${h*.74}" style="font:800 ${fs*1.7}px M;fill:#141414">0:${String(Math.floor(t%60)).padStart(2,"0")}</text><rect x="${w*.08}" y="${h*.82}" width="${w*.84}" height="6" rx="3" fill="#d6d2ca"/><rect x="${w*.08}" y="${h*.82}" width="${((t*.2)%1)*w*.84}" height="6" rx="3" fill="#E8452C"/>`}
 else if(k==2){bg="#E8452C";const W=["ШРИФТЫ","ГРАФИКА","ЖИВОЕ","КОД"],p=t*1.6,wd=W[Math.floor(p)%4],f=p%1,sc=.55+.45*eb(f/.4),fsz=Math.min(w*.21,w*.86/(wd.length*.66));
  s=`<text x="${w*.08}" y="${h*.08}" style="font:500 ${fs*.9}px J;fill:#fff;opacity:.8">kinetic · v3</text><g transform="translate(${w/2} ${h*.5}) scale(${sc})"><text text-anchor="middle" dy=".35em" style="font:800 ${fsz}px M;fill:#fff">${wd}</text></g><rect x="${w*.1}" y="${h*.66}" width="${w*.8*eo(f/.5)}" height="7" fill="#141414"/>`}
 else if(k==3){bg="#fff";s=`<text x="${w*.08}" y="${h*.08}" style="font:500 ${fs}px J;fill:#141414">МОНТАЖ</text><text x="${w*.92}" y="${h*.08}" text-anchor="end" style="font:500 ${fs}px J;fill:#E8452C">00:${String(Math.floor((t*3)%60)).padStart(2,"0")}</text>`;
  for(let q=0;q<6;q++){let x=w*.06;for(let c=0;c<5;c++){const wl=(.1+.2*rnd(q*3.7,c))*w;if(x+wl>w*.95)break;s+=`<rect x="${x}" y="${h*.15+q*h*.095}" width="${wl}" height="${h*.07}" rx="5" fill="${(q+c)%3==0?'#E8452C':((q+c)%2?'#141414':'#d6d2ca')}"/>`;x+=wl+6}}
  const px=w*.06+((t*.25)%1)*w*.88;s+=`<rect x="${px}" y="${h*.11}" width="3" height="${h*.66}" fill="#E8452C"/><polygon points="${px-6},${h*.1} ${px+9},${h*.1} ${px+1.5},${h*.12}" fill="#E8452C"/>`}
 else if(k==5){s=`<text x="${w*.08}" y="${h*.09}" style="font:500 ${fs}px J;fill:#9a978f">просмотры</text><text x="${w*.08}" y="${h*.22}" style="font:800 ${fs*2.1}px M;fill:#fff">${fmt(Math.floor(cl(((t*.6)%3)/2)*72000))}</text>`;
  for(let q=0;q<6;q++){const g=cl(((t*.7)%3.2)-q*.18);s+=`<rect x="${w*.08+q*w*.15}" y="${h*.85-h*.5*(.2+.8*g)}" width="${w*.11}" height="${h*.5*(.2+.8*g)}" rx="4" fill="${q==5?'#E8452C':'#3a3a36'}"/>`}}
 else{const im=k==6?"r8":"r10";s=`<defs><linearGradient id="gdp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".75"/></linearGradient></defs><image href="as/${im}.jpg" x="0" y="0" width="${w}" height="${h}" preserveAspectRatio="xMidYMid slice"/><rect y="${h*.5}" width="${w}" height="${h*.5}" fill="url(#gdp)"/>`;
  const q=eb(((t*1.2)%1.4)/.35);s+=`<g transform="translate(${w/2} ${h*.84}) scale(${.6+.4*Math.min(1.1,q)})"><rect x="${-w*.3}" y="${-fs*1.2}" width="${w*.6}" height="${fs*2.2}" rx="${fs*.5}" fill="#fff"/><text text-anchor="middle" dy=".3em" style="font:800 ${fs*1.15}px M;fill:#141414">СУБТИТРЫ</text></g><rect x="${w*.08}" y="${h*.94}" width="${((t*.25)%1)*w*.84}" height="5" rx="2.5" fill="#E8452C"/>`}
 return `<svg viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" style="display:block"><rect width="${w}" height="${h}" fill="${bg}"/>${s}</svg>`}
const FK=[6,0,3,1,2,5,7];

/* ===== пиксели рядом с персонажем на эмоциях ===== */
const EV=[];SC.forEach((s,k)=>{if(k==0||s.p!==SC[k-1].p){if(s.p!=="talk")EV.push({t:s.s+.05,n:16})}if(["win","guns","wave","fingerUp","shock"].includes(s.p))EV.push({t:s.s+1.15,n:7})});
function pxUpd(t,i,lt,kbk){const c=$("#pxc"),x=c.getContext("2d");x.clearRect(0,0,1080,1920);
 const cls=st.className,pal=cls=="orange"?["#fff","#141414","#ffd2c4"]:cls=="dark"?["#E8452C","#ffb39f","#2B59D9","#F1EEE7"]:["#E8452C","#2B59D9","#141414","#ffb39f"];
 const hx=819+Math.sin(t*1.15)*14,hy=1406+Math.sin(t*2.3)*5+kbk*360;
 EV.forEach((e,ei)=>{const age=t-e.t;if(age<0||age>.85)return;
  for(let n=0;n<e.n;n++){const r1=rnd(ei,n),r2=rnd(ei+7,n),r3=rnd(ei+13,n),ang=-Math.PI*1.08+r1*Math.PI*1.16,dist=130+r2*45+(40+r3*95)*eo(age/.7);
   let px=hx+Math.cos(ang)*dist*1.08,py=hy+Math.sin(ang)*dist*.95-10;px=Math.round(px/6)*6;py=Math.round(py/6)*6;
   const sz=(8+Math.floor(r3*3)*4)*(1-cl((age-.35)/.5)*.85);x.globalAlpha=1-cl((age-.45)/.4);x.fillStyle=pal[n%pal.length];x.fillRect(px,py,sz,sz)}});x.globalAlpha=1}

/* ===== веер: новая траектория + живые экраны ===== */
B[2]=(lt,t)=>{const S={x:HERO.x,y:HERO.y-40-630},P={x:540,y:1170-630},R0=300;
 for(let j=0;j<7;j++){const c=$("#fan"+j),a=(-54+18*j)*Math.PI/180,s=eb((lt-.04-j*.065)/.5),sk=cl(s),sa=Math.max(0,s);
  const ex=P.x+Math.sin(a)*R0,ey=P.y-Math.cos(a)*R0,cx=S.x+(ex-S.x)*sa,cy=S.y+(ey-S.y)*sa-130*Math.sin(Math.PI*cl(sa))+(lt>.7?Math.sin(t*2+j)*4:0);
  c.style.left=(cx-100)+"px";c.style.top=(cy-178)+"px";c.style.zIndex=10-Math.abs(j-3);
  c.style.opacity=cl((lt-.04-j*.065)/.05);c.style.filter=`blur(${(1-sk)*4}px)`;
  c.style.transform=`rotate(${a*180/Math.PI*sa+(1-sk)*(j%2?170:-170)+(lt>.7?Math.sin(t*1.5+j)*1.2:0)}deg) scale(${.35+.65*sa})`;
  if(c.style.opacity>0)c.querySelector(".scr").innerHTML=phoneArt(FK[j],174,330,t)}
 tilt($("#b_term"),lt,.45,.3);$("#b_cur").style.opacity=(t*2%1)<.5?1:0;};
/* сцена 11: карточки влетают в папку в углу */
B[11]=(lt,t)=>{const k=eo(lt/.45);$("#i_cA").style.transform=`translate(${-20*k}px,${510*k}px) scale(${1-.85*k}) rotate(${20*k}deg)`;$("#i_cB").style.transform=`translate(${-620*k}px,${510*k}px) scale(${1-.85*k}) rotate(${-20*k}deg)`;
 $("#i_cA").style.opacity=$("#i_cB").style.opacity=1-cl((lt-.4)/.08);$("#i_cA").style.filter=$("#i_cB").style.filter=`blur(${Math.sin(k*3.14)*5}px)`};
'''
rep("window.seek=seek;", NEW + "window.seek=seek;")
rep("heroUpd(t,i,lt,kbk);kwUpd(t,i,lt);", "heroUpd(t,i,lt,kbk);kwUpd(t,i,lt);pxUpd(t,i,lt,kbk);")
open(p, 'w', encoding='utf-8').write(src)
print('ok', len(src))
