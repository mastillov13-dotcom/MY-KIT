# kod_reel_project_v5
- reel5.html: вся анимация, seek(t) покадрово; рендер: PAGE=reel5.html node render.js video out.mp4 | stills 1.5,9
- tools/: patch.py -> patch2.py -> patch3.py собирают reel5.html из reel4_src.html (история правок). Дальше правим reel5.html напрямую.
- take1_p.wav, words_raw.txt, timing.json, anim.json: голос Леонида и тайминги
- mix.py: звук, пути SFX в motion_vo_kit_v1/sfx_library (поправить L)
