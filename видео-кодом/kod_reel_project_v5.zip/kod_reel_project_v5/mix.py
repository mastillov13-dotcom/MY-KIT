import json,subprocess,sys
L='/home/claude/kitsrc/motion_vo_kit_v1/sfx_library/'
a=lambda n:L+'alex_pack/'+n; r=lambda n:L+'apple_reel_pack/'+n; u=lambda n:L+'ui_pack/'+n
ST=json.load(open('timing.json'))['ST'];E=[]
wh=[a('whoosh_1.mp3'),a('fast_whoosh.mp3'),a('whoosh_2.mp3'),a('whoosh_4.mp3')]
for i,s in enumerate(ST):
    if i in (3,7,9,12): E.append((max(0,s-0.28),a('whoosh_5.mp3'),-9));E.append((s,a('pixel_shot.mp3'),-14))
    elif i: E.append((max(0,s-0.05),wh[i%4],-15))
b=lambda i,o,f,g=-9:E.append((ST[i]+o,f,g))
b(0,0,a('pop.mp3'),-8);b(0,.05,a('bass_1.mp3'),-12);b(0,1.0,r('ar_04_window_pop.wav'));b(0,1.75,r('ar_11_strike.wav'),-6);b(0,2.05,a('hit_2.mp3'),-7)
b(1,0,a('whoosh_3.mp3'),-10);b(1,.55,r('ar_02_card_slide.wav'),-9);b(1,.6,a('keyboard.mp3'),-17);b(1,1.1,r('ar_10_icon_pop.wav'))
b(2,.15,r('ar_02_card_slide.wav'),-7);b(2,.5,r('ar_08_button_appear.wav'),-10)
for k in range(3): b(3,.3+k*.3,r('ar_06_error.wav'),-9)
b(4,0,r('ar_04_window_pop.wav'))
b(5,0,a('keyboard.mp3'),-16);b(5,1.0,r('ar_10_icon_pop.wav'),-7);b(5,2.2,u('ui_03.mp3'),-11)
b(6,0,r('ar_04_window_pop.wav'))
for o in (.7,1.5,2.3): b(6,o,r('ar_05_progress_tick.wav'),-8)
b(6,2.4,r('ar_09_installed_ok.wav'),-7)
b(7,.1,r('ar_07_timeline_build.wav'),-8)
for j in range(6): b(8,.15+j*.35,u(f'ui_0{j+1}.mp3'),-13)
b(9,.2,r('ar_02_card_slide.wav'),-8);b(9,.55,r('ar_02_card_slide.wav'),-9)
b(10,0,a('whoosh_3.mp3'),-10);b(10,.05,r('ar_10_icon_pop.wav'));b(10,.23,r('ar_10_icon_pop.wav'))
b(11,0,r('ar_01_icon_morph.wav'),-8);b(11,.4,a('pop.mp3'),-9)
b(12,0,a('hit_1.mp3'),-6);b(12,.4,a('keyboard.mp3'),-15);b(12,1.0,r('ar_12_send.wav'),-7);b(12,1.3,r('ar_09_installed_ok.wav'),-9)
for j in range(6): b(12,1.6+j*.28,r('ar_13_notification.wav'),-16)
E=[e for e in E if e[0]<30.5]
ins=['-i','take1_p.wav'];fl=[]
for k,(t,f,g) in enumerate(E):
    ins+=['-i',f];d=int(t*1000);fl.append(f'[{k+1}:a]atrim=0:1.6,aresample=48000,aformat=channel_layouts=stereo,volume={g}dB,adelay={d}|{d}[s{k}]')
fl.append(''.join(f'[s{k}]' for k in range(len(E)))+f'amix=inputs={len(E)}:normalize=0,volume=3dB[fx]')
fl.append('[0:a]aformat=channel_layouts=stereo,asplit=2[v][vsc];[fx][vsc]sidechaincompress=threshold=0.05:ratio=4:attack=5:release=200[duck]')
fl.append('[v][duck]amix=inputs=2:normalize=0,apad=whole_dur=30.86,loudnorm=I=-14:TP=-1.5:LRA=9,aresample=48000[out]')
subprocess.run(['ffmpeg','-v','error','-y',*ins,'-filter_complex',';'.join(fl),'-map','[out]','-t','30.86','-c:a','pcm_s16le',sys.argv[1]],check=True)
print('events',len(E))
