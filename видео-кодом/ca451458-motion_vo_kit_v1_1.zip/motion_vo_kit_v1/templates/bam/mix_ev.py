import json as _j
BAMS = _j.load(open('bams.json'))
gT = S(26) + .55; cB, cC, cC2, cE, cF, cG, cH, cI = S(8)-.12, S(14)-.12, S(22)-.1, S(42)-.12, S(59)-.12, S(69)-.12, S(75)-.05, S(83)-.1
cD = max(S(28)-.12, gT+.95)
BIG = {round(S(52)+.05, 3), round(S(69)+.05, 3), round(S(88)+.05, 3), round(S(7)+.05, 3)}
# «бам»: удар из пака + суб + короткий воздух перед ударом (засасывание)
for k, t in enumerate(BAMS):
    big = any(abs(t - b) < .02 for b in BIG)
    put('air', sweep(.18, 600, 5000, .9, 0, 0, .5), t - .18, dB(-34 if not big else -29), .1)
    X('a:hit_2' if k % 2 else 'a:hit_1', t, -19 if big else -23, at='peak', rate=1 + .03 * (k % 3))
    put('low', sub(62 if big else 70, 40, .45 if big else .3, .2), t, dB(-15 if big else -20))
# переходы сцен
for t in (S(4) - .25, cB - .2, cC - .2, cC2 - .1, cF - .1, cG - .15): put('air', sweep(.35, 400, 4000, .6, 0, 0, .5), t, dB(-31), .2)
X('a:whoosh_2', S(4) - .3, -26); X('a:whoosh_1_2', cC2 - .15, -27)
put('ui', tick(2600, .04, .6), S(3) + .45, dB(-27), .1)                         # «?» встал
# карточки вылетают
for i in (19, 20, 21): put('air', sweep(.3, 500, 3500, .5, 0, 0, .4), S(i) - .28, dB(-33), .1)
# телефон
put('ui', tick(2200, .04, .6), cC2 + .7, dB(-28), .1)
X('a:mouse_click', S(26) - .12, -23); X('a:mouse_click', gT, -22); X('u:ui_04', gT + .1, -27)
put('air', sweep(cD - gT - .2, 300, 2600, .7, 0, 0, .3), gT + .12, dB(-33), .2); put('ui', chime(), cD - .1, dB(-29), .4)
# D: три видео
put('air', sweep(.45, 400, 5000, .6, 0, 0, .5), cD - .1, dB(-30), .3)
X('u:ui_09', S(33) - .1, -27)
for k in range(3): X('u:ui_06', S(34 + k) - .05, -25, rate=1 + .07 * k); put('low', thump(120 + 15 * k, .12), S(34 + k) - .04, dB(-26), .05)
put('air', sweep(.28, 300, 6000, .7, -.4, .4, .5), cE - .28, dB(-28), .3)
# E лента
X('u:ui_01', cE + .05, -27); put('air', sweep(cF - cE, 200, 900, .3, 0, 0, .2), cE, dB(-44), .1)
X('u:ui_06', S(43) - .05, -25); X('u:ui_06', S(51) - .1, -24, rate=1.08); X('a:camera_flash', S(51) - .02, -30, cut=.4)
# F стили
for t in (S(63), max(S(65) - .05, S(63) + .42)): put('air', sweep(.38, 700, 4500, .5, .4, -.4, .5), t, dB(-33), .2)
# G мозаика
put('air', swell(.45), cG - .4, dB(-27), .4); put('air', sweep(1.0, 5000, 400, .3, 0, 0, .3), cG, dB(-33), .3)
put('air', sweep(.45, 400, 1300, .4, .4, 0, .4), S(72) - .2, dB(-41), .1); X('a:mouse_click', S(73) - .05, -22)
# H
put('air', swell(.35), cH - .5, dB(-24), .4); put('air', sweep(.4, 300, 6000, .7, 0, 0, .5), cH - .25, dB(-28), .3)
X('a:keyboard', S(77) + .12, -30, cut=.45); X('u:ui_04', S(79) - .25, -26)
# I финал
put('air', sweep(.35, 5000, 300, .5, 0, 0, .5), cI - .3, dB(-30), .3)
put('ui', shimmer(2800, 1.2), S(88) + .15, dB(-31), .6)
