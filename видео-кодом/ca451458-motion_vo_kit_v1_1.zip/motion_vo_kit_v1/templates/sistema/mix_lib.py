"""Премиальный саунд-дизайн (Apple-презентация) для ролика со шляпой.
Иерархия: 4 главных момента — многослойные акценты (суб-удар + воздушный свип + блеск + хвост реверберации);
движения — мягкие воздушные свипы по физике движения (направление, панорама); появления — тихие чистые digital-тики;
мелочь — тишина. Отдельные стемы: low / air / ui / verb; шина эффектов приседает под голос.
Пишет stems/*.wav и sfxP.wav (48 кГц, стерео)."""
import json, os, wave, subprocess, numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
import sys
SR = 48000; END = float(sys.argv[1]); N = int(END * SR)
w = json.load(open('words.json')); S = lambda i: w[i]['s']
rng = np.random.default_rng(11)
os.makedirs('stems', exist_ok=True)
BUS = {k: np.zeros((N, 2)) for k in ('low', 'air', 'ui')}
SEND = np.zeros((N, 2))                                   # посыл в реверберацию
T = lambda d: np.arange(int(d * SR)) / SR
def bp(x, lo, hi, o=2): return sosfilt(butter(o, [lo, hi], 'band', fs=SR, output='sos'), x)
def lp(x, f, o=2): return sosfilt(butter(o, f, 'low', fs=SR, output='sos'), x)
def hp(x, f, o=2): return sosfilt(butter(o, f, 'high', fs=SR, output='sos'), x)
def st(m, pan=0., width=0.):                              # моно → стерео с панорамой и лёгкой шириной
    L = m * np.sqrt(.5 * (1 - pan)); R = m * np.sqrt(.5 * (1 + pan))
    if width: d = int(width * SR); R = np.concatenate([np.zeros(d), R[:-d]]) if d else R
    return np.stack([L, R], 1)
def put(bus, a, t, g, send=0.):
    i = int(t * SR); a = a * g
    if i < 0: a = a[-i:]; i = 0
    m = min(len(a), N - i)
    if m <= 0: return
    BUS[bus][i:i + m] += a[:m]
    if send: SEND[i:i + m] += a[:m] * send
def fade(x, a=.004, r=.02):
    n = len(x); ea = int(a * SR); er = int(r * SR); e = np.ones(n)
    if ea: e[:ea] = np.linspace(0, 1, ea)
    if er: e[-er:] *= np.linspace(1, 0, er)
    return x * (e if x.ndim == 1 else e[:, None])
# ---------- палитра ----------
def sweep(d=.6, f0=300, f1=5000, peak=.6, pan0=0., pan1=0., q=.7):
    """воздушный свип: шум через движущуюся полосу, огибающая по физике движения, панорама следует за объектом"""
    n = int(d * SR); x = rng.normal(0, 1, n); t = np.arange(n) / n
    out = np.zeros(n); blk = 1024
    for s in range(0, n, blk):
        u = (s + blk / 2) / n; fc = f0 * (f1 / f0) ** u
        seg = bp(x[max(0, s - 2048):s + blk], fc / (1 + q), min(fc * (1 + q), 20000))[-min(blk, n - s):]
        out[s:s + len(seg)] = seg
    env = np.where(t < peak, (t / peak) ** 2, ((1 - t) / (1 - peak)) ** 1.6)
    out *= env; out /= np.abs(out).max() + 1e-9
    pan = np.linspace(pan0, pan1, n)
    return fade(np.stack([out * np.sqrt(.5 * (1 - pan)), out * np.sqrt(.5 * (1 + pan))], 1), .01, .05)
def swell(d=.45):                                          # обратная реверберация, втягивает в главный момент
    n = int(d * SR); x = hp(rng.normal(0, 1, n), 600) * np.exp(-np.arange(n)[::-1] / (SR * .14))
    x = lp(x, 9000) / (np.abs(x).max() + 1e-9); return fade(st(x, 0, .0007), .02, .004)
def sub(f0=62, f1=40, d=.55, click=.25):                   # контролируемый суб-удар: тон с падением, короткий хвост
    t = T(d); f = f1 + (f0 - f1) * np.exp(-t / .045); ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * (1 - np.exp(-t / .004)) * np.exp(-t / .16)
    tr = lp(rng.normal(0, 1, len(t)), 2500) * np.exp(-t / .006) * click
    x = lp(x + tr, 180, 4) * 1.0 + lp(tr, 4000) * .3
    x = x + bp(np.tanh(x / (np.abs(x).max() + 1e-9) * 3), 90, 320) * .45   # гармоники, чтобы низ читался на телефоне
    return fade(st(x / (np.abs(x).max() + 1e-9)), .001, .06)
def shimmer(base=2400, d=.9, n=5):                         # стеклянный блеск: негармоничные высокие парциалы
    t = T(d); x = np.zeros(len(t))
    for k in range(n):
        f = base * (1 + k * .618) * rng.uniform(.99, 1.01); x += np.sin(2 * np.pi * f * t + rng.uniform(0, 6)) * np.exp(-t / (.18 + .05 * k)) / (1 + k * .5)
    x *= 1 - np.exp(-t / .003); x = hp(x, 1800); return fade(st(x / (np.abs(x).max() + 1e-9), 0, .0011), .001, .1)
def tick(f=3600, d=.05, body=.5, pan=0.):                  # чистый digital-тик
    t = T(d); x = np.sin(2 * np.pi * f * t) * np.exp(-t / .0045) + np.sin(2 * np.pi * f * 1.5 * t) * np.exp(-t / .003) * .35
    x += hp(rng.normal(0, 1, len(t)), 6000) * np.exp(-t / .0012) * .4
    x += np.sin(2 * np.pi * 900 * t) * np.exp(-t / .008) * body * .4
    return fade(st(x / (np.abs(x).max() + 1e-9), pan), .0005, .01)
def sendswish(d=.24):
    t = T(d); n = len(t)
    x = rng.normal(0, 1, n); out = np.zeros(n); blk = 512
    for s0 in range(0, n, blk):
        u = (s0 + blk / 2) / n; fc = 900 * (6500 / 900) ** u
        seg = bp(x[max(0, s0 - 1024):s0 + blk], fc / 1.6, min(fc * 1.6, 20000))[-min(blk, n - s0):]; out[s0:s0 + len(seg)] = seg
    out /= np.abs(out).max() + 1e-9
    env = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 1.3
    f = 520 + 900 * (t / d) ** 1.5; ph = 2 * np.pi * np.cumsum(f) / SR
    tone = np.sin(ph) * np.exp(-((t - d * .45) / (d * .28)) ** 2)
    y = (out * .75 + tone * .45) * env
    return fade(st(y / (np.abs(y).max() + 1e-9), 0, .0006), .002, .03)
def press():                                               # нажатие физической кнопки: мягкий щелчок с корпусом
    t = T(.07); x = lp(rng.normal(0, 1, len(t)), 5000) * np.exp(-t / .003) + np.sin(2 * np.pi * 210 * t) * np.exp(-t / .018) * .8
    return fade(st(x / (np.abs(x).max() + 1e-9)), .0005, .02)
def delicate(d=.35):                                       # деликатный импакт: глухой толчок + короткий воздух
    t = T(d); x = np.sin(2 * np.pi * (95 + 60 * np.exp(-t / .02)) * t) * np.exp(-t / .07)
    x += bp(rng.normal(0, 1, len(t)), 300, 2200) * np.exp(-t / .02) * .25
    return fade(st(x / (np.abs(x).max() + 1e-9)), .001, .05)
def chime():                                               # подтверждение: два чистых тона, без «игровости»
    a = np.zeros(int(1.2 * SR))
    for f, t0, g in ((1046.5, 0, 1), (1568.0, .085, .75)):
        t = T(1.0); s = (np.sin(2 * np.pi * f * t) + .18 * np.sin(2 * np.pi * 2 * f * t)) * np.exp(-t / .32) * (1 - np.exp(-t / .002)) * g
        i = int(t0 * SR); a[i:i + len(s)] += s
    return fade(st(a / np.abs(a).max(), 0, .0009), .001, .2)
dB = lambda x: 10 ** (x / 20)
LIBS = {'a': '/home/claude/kris/kit/sfx_library/alex_pack/', 'u': '/home/claude/kris/kit/sfx_library/ui_pack/', 'r': '/home/claude/kris/kit/sfx_library/apple_reel_pack/'}
_c = {}
def snd(name, rate=1.0):
    k = (name, rate)
    if k not in _c:
        lib, n = name.split(':'); d = LIBS[lib]; f = [x for x in os.listdir(d) if x.startswith(n + '.')][0]
        a = np.frombuffer(subprocess.run(['ffmpeg', '-v', 'error', '-i', d + f, '-ac', '2', '-ar', str(SR), '-f', 's16le', '-'], capture_output=True).stdout, np.int16).astype(float).reshape(-1, 2) / 32767
        if rate != 1.0:                                   # сдвиг высоты пересэмплированием (разнообразие одинаковых действий)
            idx = np.arange(0, len(a) - 1, rate); a = np.stack([np.interp(idx, np.arange(len(a)), a[:, c]) for c in range(2)], 1)
        m = np.abs(a).max(1); on = int(np.argmax(m > m.max() * .05)); pk = int(np.argmax(m))
        _c[k] = (fade(a[on:] / (m.max() + 1e-9), .001, .03), (pk - on) / SR)
    return _c[k]
def X(name, t, db, at='onset', rate=1.0, send=.15, pan=0., cut=None):
    a, pk = snd(name, rate)
    if cut: a = fade(a[:int(cut * SR)], .001, .04)
    if pan: a = a * np.array([np.sqrt(1 - pan), np.sqrt(1 + pan)])
    put('ui', a, t - (pk if at == 'peak' else 0), dB(db), send)
def scribble(d=.3):
    t = T(d); x = bp(rng.normal(0, 1, len(t)), 2500, 7000) * (.55 + .45 * np.sin(2 * np.pi * 23 * t) ** 2)
    return fade(st(x / (np.abs(x).max() + 1e-9), .2), .01, .05)
def thump(f=110, d=.18):
    t = T(d); x = np.sin(2 * np.pi * f * t * (1 - .3 * t / d)) * np.exp(-t / .045) + bp(rng.normal(0, 1, len(t)), 300, 2400) * np.exp(-t / .006) * .4
    return fade(st(x / np.abs(x).max()), .0005, .03)
def rattle(d=.6):
    t = T(d); x = bp(rng.normal(0, 1, len(t)), 900, 3500) * (np.sin(2 * np.pi * 18 * t) > .3) * np.exp(-t / .5)
    return fade(st(x / (np.abs(x).max() + 1e-9), .3), .01, .08)
def plip(f0, d=.11, up=False):
    t = T(d); f = f0 * (1 + (.14 if up else -.14) * (1 - np.exp(-t / .02))); ph = 2 * np.pi * np.cumsum(f) / SR
    x = (np.sin(ph) + .25 * np.sin(2 * ph)) * np.exp(-t / .035) * (1 - np.exp(-t / .0015))
    return fade(st(x / (np.abs(x).max() + 1e-9), 0, .0005), .0005, .02)
