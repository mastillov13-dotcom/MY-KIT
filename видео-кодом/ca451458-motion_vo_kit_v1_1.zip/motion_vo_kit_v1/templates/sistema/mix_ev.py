def chip(freqs, step=.055, d=.05, duty=.5, g=1.0):
    """8-битный «денди»-писк: прямоугольная волна, ступеньки нот"""
    n = int((step * (len(freqs) - 1) + d) * SR); out = np.zeros(n)
    for k, f in enumerate(freqs):
        t = T(d); ph = (f * t) % 1; w = np.where(ph < duty, 1., -1.) * np.exp(-t / (d * .6))
        i = int(k * step * SR); out[i:i + len(w)] += w[:n - i]
    out = lp(out, 7000)
    return fade(st(out / (np.abs(out).max() + 1e-9) * g), .001, .01)
def crunch(d=.12):
    t = T(d); x = rng.normal(0, 1, len(t)); x = np.round(x * 3) / 3; x = bp(x, 800, 7000) * np.exp(-t / .04)
    return fade(st(x / (np.abs(x).max() + 1e-9)), .001, .01)
NOTE = lambda m: 440 * 2 ** ((m - 69) / 12)
import json as _j
BAMS = _j.load(open('bams.json')); EV = _j.load(open('ev.json'))
TB, TC, TD, TE, TF, TG, TH = S(9)-.1, S(20)-.12, S(31)-.12, S(39)-.1, S(48)-.12, S(60)-.1, S(65)-.1
BIG = {round(S(4)+.05, 3), round(S(17)+.05, 3), round(S(33)+.05, 3), round(S(70)+.05, 3)}
for k, t in enumerate(BAMS):
    big = any(abs(t - b) < .02 for b in BIG)
    put('air', sweep(.18, 600, 5000, .9, 0, 0, .5), t - .18, dB(-34 if not big else -29), .1)
    X('a:hit_2' if k % 2 else 'a:hit_1', t, -19 if big else -23, at='peak', rate=1 + .03 * (k % 3))
    put('low', sub(62 if big else 70, 40, .45 if big else .3, .2), t, dB(-15 if big else -20))
# старт: проявление из размытия
put('air', sweep(.5, 6000, 900, .5, 0, 0, .5), 0, dB(-33), .3); put('low', sub(52, 38, .7, .1), 0.02, dB(-22))
# выезд карточки / исходника, клик, ошибка рендера
for t in EV['fly']: put('air', sweep(.4, 400, 3800, .55, 0, 0, .4), t, dB(-30), .2); X('r:ar_02_card_slide', t + .05, -27, send=.05)
for t in EV['click']: X('a:mouse_click', t, -21); put('ui', press(), t, dB(-27), .02)
X('r:ar_06_error', S(19) - .02, -22, send=.1)
# рендер-прогресс тикает
for k in range(8): put('ui', tick(2400 + 90 * k, .03, .5), S(14) + .1 + k * (S(18) - S(14)) / 8, dB(-35), .02)
# таймлайн: тики блоков + сборка
for k, t in enumerate(EV['tick']): put('ui', tick(2600 + 150 * (k % 5), .035, .55), t, dB(-30), .03)
X('r:ar_07_timeline_build', S(43) - .02, -26, send=.08)
# печать в чате и отправка
for k, t in enumerate(EV['type'] + EV['type2']): X('u:ui_01', t, -31 + (k % 2), rate=1 + .05 * (k % 3), send=.02)
X('r:ar_12_send', S(64) - .02, -23, send=.1); X('r:ar_12_send', S(74) + .08, -23, send=.1)
X('r:ar_09_installed_ok', S(64) + .12, -25, send=.2)
# ===== v3: приёмы из неон-ролика =====
for k, t in enumerate(EV['glitch']):
    if any(abs(t - d) < .01 for d in EV['dissolve']): continue
    X('a:glitch_1' if k % 2 else 'a:glitch_2', t, -25, cut=.28); put('ui', crunch(), t, dB(-30), .05)
for t in EV['dissolve']:
    X('a:fast_glitch', t, -24, cut=.45); put('ui', chip([NOTE(m) for m in (84, 79, 76, 72, 67)], .045, .05), t + .1, dB(-31), .15)
    put('air', sweep(.6, 2000, 9000, .5, -.3, .3, .6), t + .08, dB(-34), .3)
for t in EV['cycle']:
    for k in range(7): put('ui', chip([NOTE(72 + (k * 5) % 12)], .05, .04), t + k * .066, dB(-33), .02)
for k, t in enumerate(EV['dots']): put('ui', chip([NOTE(64 + [0, 3, 5, 7, 10, 12][k])], .05, .07), t, dB(-30), .05)
for t in EV['bars']:
    put('low', thump(95, .2), t + .05, dB(-24), .1); put('ui', chip([NOTE(m) for m in (60, 64, 67, 72, 76)], .04, .06), t, dB(-31), .1)
for t in EV['spiral']:
    put('air', swell(.5), t - .45, dB(-26), .4); X('a:whoosh_3', t - .1, -27); put('low', sub(48, 36, 1.2, .1), t, dB(-22))
for t in EV['rings']:
    put('ui', chip([NOTE(m) for m in (60, 67, 72, 79, 84)], .07, .09), t, dB(-30), .3)
    for k in range(6): put('air', sweep(.5, 300, 2400, .5, 0, 0, .4), t + k * .16, dB(-40), .1)

# ===== v4: разрезы, зумы, слэш, схема, башня (из разбора KATANA) =====
for t in EV.get('slice', []):
    for k in range(10): put('ui', tick(2200 + 140 * k, .02, .3, pan=(-.5 if k % 2 else .5)), t - .22 + k * .012, dB(-38), .02)
    put('air', sweep(.25, 600, 7000, .7, -.5, .5, .5), t - .22, dB(-29), .2); put('air', sweep(.28, 7000, 500, .6, .5, -.5, .5), t + .04, dB(-30), .2)
    put('low', thump(85, .18), t, dB(-24), .1)
for t in EV.get('slash', []):
    put('air', sweep(.22, 900, 9000, .9, -.7, .7, .6), t - .12, dB(-26), .3); X('a:whoosh_1', t - .05, -25)
    put('ui', shimmer(4200, .35), t, dB(-31), .3)
for t in EV.get('zoom', []):
    put('air', swell(.35), t - .05, dB(-24), .4); put('air', sweep(.35, 300, 6500, .7, 0, 0, .4), t, dB(-27), .3); put('low', sub(52, 34, .6), t + .32, dB(-17))
for t in EV.get('fall', []):
    for k in range(8): put('ui', tick(3600 - 150 * k, .025, .5, pan=-.4 + .1 * k), t + k * .035 + .2, dB(-34), .03)
for t in EV.get('line', []): put('ui', sweep(.22, 1500, 6000, .6, -.6, .6, .5), t, dB(-33), .2)
for t in EV.get('node', []): put('ui', chip([NOTE(72), NOTE(79)], .05, .06), t, dB(-30), .1); put('low', thump(130, .12), t + .1, dB(-28), .05)
for t in EV.get('wire', []): put('ui', chip([NOTE(m) for m in (67, 71, 74, 79)], .04, .04), t, dB(-33), .05)
for t in EV.get('fly', []): put('air', sweep(.4, 4000, 300, .5, 0, -.6, .5), t, dB(-28), .3); X('a:whoosh_2', t, -27)
for t in EV.get('burst', []): X('a:hit_1', t, -22, at='peak'); put('air', sweep(.5, 500, 9000, .6, 0, 0, .7), t, dB(-29), .5)
for k, t in enumerate(EV.get('tower', [])): put('ui', tick(2400 + 160 * k, .03, .6), t + .2, dB(-31), .05)
for t in EV.get('ripple', []):
    for k in range(3): put('ui', chip([NOTE(84 - 5 * k)], .05, .05), t + k * .1, dB(-33), .05)

# зум в букву: втягивающий свип + удар-бас на «проходе сквозь» + короткий шорох
for t in EV.get('zl', []):
    put('air', swell(.4), t - .42, dB(-24), .4); put('air', sweep(.4, 250, 7000, .8, 0, 0, .3), t - .4, dB(-26), .3)
    put('low', sub(48, 32, .7, .25), t, dB(-15)); X('a:whoosh_3', t - .2, -28)

# ===== v3 правки: строб, штамп букв, пиксельная шторка, кинетика «режет/монтирует/анимации/скрины» =====
for t in EV.get('strobe', []):
    for k in range(3): put('ui', crunch(.05), t + k / 30, dB(-30), .02)
    put('ui', chip([NOTE(84), NOTE(72)], .033, .03), t, dB(-31), .02)
for k, t in enumerate(EV.get('stamp', [])):
    X('a:hit_2' if k % 2 else 'a:hit_1', t, -25, at='peak', rate=1 + .06 * k); put('low', sub(80 - 4 * k, 45, .22, .25), t, dB(-22))
for t in EV.get('blocks', []):
    for k in range(9): put('ui', tick(1800 + 260 * k, .025, .5, pan=-.6 + .15 * k), t + k * .022, dB(-34), .02)
    put('air', sweep(.32, 400, 6000, .6, 0, 0, .5), t, dB(-30), .2); put('air', sweep(.3, 6000, 500, .5, 0, 0, .5), t + .3, dB(-33), .2)
for t in EV.get('split', []): put('air', sweep(.3, 1200, 8000, .5, -.5, .5, .6), t, dB(-29), .2); put('ui', shimmer(3600, .3), t, dB(-33), .2)
for t in EV.get('slam', []): put('low', thump(90, .22), t, dB(-21), .1); X('a:pop', t, -27)
for t in EV.get('wave', []): put('ui', chip([NOTE(m) for m in (72, 76, 79, 84, 79, 76, 72, 76)], .06, .05), t + .3, dB(-31), .1)
for t in EV.get('shot', []): X('a:camera_flash', t, -29, cut=.35); X('r:ar_10_icon_pop', t - .18, -27, send=.05)
# белый шум в превью рендера
for t in EV.get('static', []):
    n = int(.9 * SR); x = hp(rng.normal(0, 1, n), 1500) * np.exp(-np.arange(n) / (SR * .5)); put('ui', fade(st(x / np.abs(x).max(), 0, .0008), .005, .2), t, dB(-30), .05)
# мяч: «боинг» на каждом ударе о землю; туннель в финале
for k, t in enumerate(EV.get('bounce', [])):
    put('ui', plip(520 - 60 * k, .16, True), t, dB(-26), .1); put('low', thump(140 - 15 * k, .12), t, dB(-27), .05)
for t in EV.get('tunnel', []):
    put('air', swell(.5), t - .3, dB(-28), .4); put('low', sub(46, 34, 1.4, .05), t, dB(-24)); put('air', sweep(2.2, 200, 1400, .3, 0, 0, .2), t + .1, dB(-40), .2)
