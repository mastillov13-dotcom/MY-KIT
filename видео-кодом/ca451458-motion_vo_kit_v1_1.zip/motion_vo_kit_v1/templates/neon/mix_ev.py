def chip(freqs, step=.055, d=.05, duty=.5, g=1.0):
    """8-битный «денди»-писк: прямоугольная волна, ступеньки нот"""
    n = int((step * (len(freqs) - 1) + d) * SR); out = np.zeros(n)
    for k, f in enumerate(freqs):
        t = T(d); ph = (f * t) % 1; w = np.where(ph < duty, 1., -1.) * np.exp(-t / (d * .6))
        i = int(k * step * SR); out[i:i + len(w)] += w[:n - i]
    out = lp(out, 7000)
    return fade(st(out / (np.abs(out).max() + 1e-9) * g), .001, .01)
def crunch(d=.12):
    t = T(d); x = rng.normal(0, 1, len(t)); x = np.round(x * 3) / 3; x = bp(x, 800, 7000) * np.exp(-t / .04)
    return fade(st(x / (np.abs(x).max() + 1e-9)), .001, .01)
NOTE = lambda m: 440 * 2 ** ((m - 69) / 12)
import json as _j
BAMS = _j.load(open('bams.json'))
EV = _j.load(open('ev.json'))
gT = S(26) + .55; cB, cC, cC2, cE, cF, cG, cH, cI = S(8)-.12, S(14)-.12, S(22)-.1, S(42)-.12, S(59)-.12, S(69)-.12, S(75)-.05, S(83)-.1
cD = max(S(28)-.12, gT+.95)
BIG = {round(S(52)+.05, 3), round(S(69)+.05, 3), round(S(88)+.05, 3), round(S(7)+.05, 3)}
# «бам»: удар из пака + суб + короткий воздух перед ударом (засасывание)
for k, t in enumerate(BAMS):
    big = any(abs(t - b) < .02 for b in BIG)
    put('air', sweep(.18, 600, 5000, .9, 0, 0, .5), t - .18, dB(-34 if not big else -29), .1)
    X('a:hit_2' if k % 2 else 'a:hit_1', t, -19 if big else -23, at='peak', rate=1 + .03 * (k % 3))
    put('low', sub(62 if big else 70, 40, .45 if big else .3, .2), t, dB(-15 if big else -20))
# переходы сцен
for t in (S(4) - .25, cB - .2, cC - .2, cC2 - .1, cF - .1, cG - .15): put('air', sweep(.35, 400, 4000, .6, 0, 0, .5), t, dB(-31), .2)
X('a:whoosh_2', S(4) - .3, -26); X('a:whoosh_1_2', cC2 - .15, -27)
put('ui', chip([NOTE(76), NOTE(83)], .06, .07), S(3) + .2, dB(-29), .1)   # «?» встал
put('air', sweep(.5, 6000, 900, .5, 0, 0, .5), max(0, S(0) - .05), dB(-33), .3); put('low', sub(52, 38, .7, .1), max(0, S(0)), dB(-22))   # проявление из размытия
# карточки вылетают
for i in (19, 20, 21): put('air', sweep(.3, 500, 3500, .5, 0, 0, .4), S(i) - .28, dB(-33), .1)
# телефон
put('ui', tick(2200, .04, .6), cC2 + .7, dB(-28), .1)
X('a:mouse_click', S(26) - .12, -24); X('a:mouse_click', gT, -23); put('ui', chip([NOTE(84)], .05, .04), S(26) - .12, dB(-32), .02); put('ui', chip([NOTE(79), NOTE(86)], .05, .05), gT, dB(-31), .05); X('u:ui_04', gT + .1, -27)
put('air', sweep(cD - gT - .2, 300, 2600, .7, 0, 0, .3), gT + .12, dB(-33), .2); put('ui', chime(), cD - .1, dB(-29), .4)
# D: три видео
put('air', sweep(.45, 400, 5000, .6, 0, 0, .5), cD - .1, dB(-30), .3)
X('u:ui_09', S(33) - .1, -27)
for k in range(3): X('u:ui_06', S(34 + k) - .05, -25, rate=1 + .07 * k); put('low', thump(120 + 15 * k, .12), S(34 + k) - .04, dB(-26), .05)
put('air', sweep(.28, 300, 6000, .7, -.4, .4, .5), cE - .28, dB(-28), .3)
# E лента
X('u:ui_01', cE + .05, -27); put('air', sweep(cF - cE, 200, 900, .3, 0, 0, .2), cE, dB(-44), .1)
X('u:ui_06', S(43) - .05, -25); X('u:ui_06', S(51) - .1, -24, rate=1.08); X('a:camera_flash', S(51) - .02, -30, cut=.4)
# F стили
for t in (S(63), max(S(65) - .05, S(63) + .42)): put('air', sweep(.38, 700, 4500, .5, .4, -.4, .5), t, dB(-33), .2)
# G мозаика
put('air', swell(.45), cG - .4, dB(-27), .4); put('air', sweep(1.0, 5000, 400, .3, 0, 0, .3), cG, dB(-33), .3)
put('air', sweep(.45, 400, 1300, .4, .4, 0, .4), S(72) - .2, dB(-41), .1); X('a:mouse_click', S(73) - .05, -22)
# H
put('air', swell(.35), cH - .5, dB(-24), .4); put('air', sweep(.4, 300, 6000, .7, 0, 0, .5), cH - .25, dB(-28), .3)
X('a:keyboard', S(77) + .12, -30, cut=.45); X('u:ui_04', S(79) - .25, -26)
# I финал
put('air', sweep(.35, 5000, 300, .5, 0, 0, .5), cI - .3, dB(-30), .3)
put('ui', shimmer(2800, 1.2), S(88) + .15, dB(-31), .6)

# ===== v3: приёмы из неон-ролика =====
for k, t in enumerate(EV['glitch']):
    if any(abs(t - d) < .01 for d in EV['dissolve']): continue
    X('a:glitch_1' if k % 2 else 'a:glitch_2', t, -25, cut=.28); put('ui', crunch(), t, dB(-30), .05)
for t in EV['dissolve']:
    X('a:fast_glitch', t, -24, cut=.45); put('ui', chip([NOTE(m) for m in (84, 79, 76, 72, 67)], .045, .05), t + .1, dB(-31), .15)
    put('air', sweep(.6, 2000, 9000, .5, -.3, .3, .6), t + .08, dB(-34), .3)
for t in EV['cycle']:
    for k in range(7): put('ui', chip([NOTE(72 + (k * 5) % 12)], .05, .04), t + k * .066, dB(-33), .02)
for k, t in enumerate(EV['dots']): put('ui', chip([NOTE(64 + [0, 3, 5, 7, 10, 12][k])], .05, .07), t, dB(-30), .05)
for t in EV['bars']:
    put('low', thump(95, .2), t + .05, dB(-24), .1); put('ui', chip([NOTE(m) for m in (60, 64, 67, 72, 76)], .04, .06), t, dB(-31), .1)
for t in EV['spiral']:
    put('air', swell(.5), t - .45, dB(-26), .4); X('a:whoosh_3', t - .1, -27); put('low', sub(48, 36, 1.2, .1), t, dB(-22))
for t in EV['rings']:
    put('ui', chip([NOTE(m) for m in (60, 67, 72, 79, 84)], .07, .09), t, dB(-30), .3)
    for k in range(6): put('air', sweep(.5, 300, 2400, .5, 0, 0, .4), t + k * .16, dB(-40), .1)
# «денди» на призыве: печать «тренд» по буквам и кнопка отправки
for k in range(5): put('ui', chip([NOTE(76 + 2 * k)], .05, .045), S(77) + .15 + (k + 1) * .07, dB(-31), .02)
put('ui', chip([NOTE(m) for m in (72, 76, 79, 84)], .05, .06), S(79) - .25, dB(-29), .1)
