"""Распознавание русской речи с таймингами слов (sherpa-onnx zipformer-ru), формат words_raw.txt.
Использование: python3 asr.py audio.wav [начало конец ...]  → печатает «слово,начало,конец|…» (сотые доли)"""
import sys, wave
import numpy as np
import sherpa_onnx

M = '/home/claude/asr/sherpa-onnx-zipformer-ru-2024-09-18/'
rec = sherpa_onnx.OfflineRecognizer.from_transducer(
    encoder=M + 'encoder.int8.onnx', decoder=M + 'decoder.onnx', joiner=M + 'joiner.int8.onnx',
    tokens=M + 'tokens.txt', num_threads=2, decoding_method='greedy_search')

w = wave.open(sys.argv[1])
SR = w.getframerate()
pcm = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
cuts = [float(x) for x in sys.argv[2:]] or [0, len(pcm) / SR]
out = []
for a, b in zip(cuts[:-1], cuts[1:]):
    s = rec.create_stream()
    seg = pcm[int(a * SR):int(b * SR)]
    s.accept_waveform(SR, seg)
    rec.decode_stream(s)
    r = s.result
    # склеиваем BPE-токены в слова: '▁' — начало слова
    words, cur, t0, tl = [], '', None, None
    ts = list(r.timestamps) + [len(seg) / SR]
    for i, tok in enumerate(r.tokens):
        if (tok.startswith('▁') or tok.startswith(' ')) and cur:
            words.append((cur, t0, tl)); cur = ''
        if not cur:
            t0 = ts[i]
        cur += tok.replace('▁', '').strip()
        tl = min(ts[i + 1], ts[i] + 0.6)
    if cur:
        words.append((cur, t0, tl))
    for wd, s0, s1 in words:
        out.append(f'{wd},{round((a + s0) * 100)},{round((a + s1 + .04) * 100)}')
print('|'.join(out))
