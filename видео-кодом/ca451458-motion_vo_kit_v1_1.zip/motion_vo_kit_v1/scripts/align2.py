import json, re, wave, difflib, numpy as np, sys
wav, asrf, outdir = sys.argv[1], sys.argv[2], sys.argv[3]
norm = lambda s: re.sub(r'[^а-яa-z]', '', s.lower().replace('ё', 'е'))
toks = [t for t in open(outdir + '/script.txt').read().replace('—', ' ').split() if norm(t)]
names = [re.sub(r'[^\wёЁ-]', '', t) for t in toks]; sw = [norm(t) for t in toks]
A = [(norm(a.split(',')[0]), int(a.split(',')[1]) / 100, int(a.split(',')[2]) / 100) for a in open(asrf).read().strip().split('|')]
w = wave.open(wav); SR = w.getframerate(); x = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(float) / 32768
hop = SR // 100; en = np.array([np.sqrt((x[i:i + hop] ** 2).mean()) for i in range(0, len(x) - hop, hop)]); onset = np.argmax(en > en.max() * .04) / 100
sm = difflib.SequenceMatcher(None, sw, [a[0] for a in A], autojunk=False); T = [None] * len(sw)
for op, a1, a2, b1, b2 in sm.get_opcodes():
    if op == 'equal':
        for j in range(a2 - a1): T[a1 + j] = A[b1 + j][1:]
    elif op == 'replace':
        s0, s1 = A[b1][1], A[b2 - 1][2]; L = [len(sw[k]) + 1 for k in range(a1, a2)]; c = s0
        for k, l in zip(range(a1, a2), L): d = (s1 - s0) * l / sum(L); T[k] = (c, c + d); c += d
for i in range(len(T)):
    if T[i] is None:
        n = next(T[j] for j in range(i + 1, len(T)) if T[j])
        if i == 0: T[i] = (onset, n[0])
        else: p = T[i - 1]; T[i] = (p[1], max(p[1] + .05, n[0] - .02))
# склейка: если следующее слово начинается раньше конца предыдущего — ок; первое слово начинается с onset
out = [{'i': i, 'w': names[i], 's': round(float(T[i][0]), 3), 'e': round(float(T[i][1]), 3)} for i in range(len(sw))]
json.dump(out, open(outdir + '/words.json', 'w'), ensure_ascii=False)
open(outdir + '/ap/data.js', 'w').write('window.WS=%s;window.WE=%s;' % ([o['s'] for o in out], [o['e'] for o in out]))
print(len(out), ' '.join(f"{o['i']}{o['w']}:{o['s']}" for o in out))
