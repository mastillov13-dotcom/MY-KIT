// Выгрузка времён «бам» и событий (глюк, распад, смена шрифтов, точки графика, кольца, спираль) для звука.
// Запуск: NODE_PATH=$(npm root -g) node export_ev.js /путь/к/ap/index.html  → bams.json, ev.json в текущей папке
const { chromium } = require('playwright');
(async () => { const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell' }); const p = await b.newPage();
  p.on('pageerror', e => console.log('ERR', e.message));
  await p.goto('file://' + process.argv[2]); await p.waitForTimeout(1200);
  const r = await p.evaluate(() => ({ bams: window.BAMS.map(x => +x.toFixed(3)), ev: window.EV || {} }));
  require('fs').writeFileSync('bams.json', JSON.stringify(r.bams)); require('fs').writeFileSync('ev.json', JSON.stringify(r.ev)); console.log(JSON.stringify(r)); await b.close(); })();
