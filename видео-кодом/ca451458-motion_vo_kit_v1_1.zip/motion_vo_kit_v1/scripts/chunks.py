import sys, wave, numpy as np
w = wave.open(sys.argv[1]); SR = w.getframerate(); x = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(float) / 32768
hop = int(.01 * SR); e = np.array([np.sqrt((x[i:i+hop]**2).mean()) for i in range(0, len(x) - hop, hop)])
th = max(e.max() * .03, 1e-3); sil = e < th
# середины пауз ≥ 0.2 с
gaps = []; i = 0
while i < len(sil):
    if sil[i]:
        j = i
        while j < len(sil) and sil[j]: j += 1
        if j - i >= (int(sys.argv[2]) if len(sys.argv) > 2 else 20): gaps.append(((i + j) / 2) / 100)
        i = j
    else: i += 1
dur = len(x) / SR; cuts = [0.0]
for g in gaps:
    if g - cuts[-1] > 4: cuts.append(g)
if dur - cuts[-1] < 1.5 and len(cuts) > 1: cuts.pop()
cuts.append(dur)
print(' '.join(f'{c:.2f}' for c in cuts))
