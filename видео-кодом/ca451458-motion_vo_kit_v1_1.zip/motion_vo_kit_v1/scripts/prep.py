from PIL import Image
import glob
D='/home/claude/r9/'
def sh(n): return Image.open(glob.glob(D+f'screenshot-*-{n}.jpg')[0])
def cells(im,W,H,cols,n): return [im.crop(((i%cols)*(W+10),(i//cols)*(H+10),(i%cols)*(W+10)+W,(i//cols)*(H+10)+H)) for i in range(n)]
cov=[]
for s,n in ((0,5),(1,5),(2,5),(3,5),(4,5),(5,2)): cov+=cells(sh(s),270,480,5,n)
for i,c in enumerate(cov): c.save(D+f'ap/img/p{i:02d}.jpg',quality=92)
def strip(name,parts,W,H,cols):
    fr=[]
    for s,a,n in parts: fr+=cells(sh(s),W,H,cols,a+n)[a:]
    st=Image.new('RGB',(W*12,H))
    for i,f in enumerate(fr[:12]): st.paste(f,(i*W,0))
    st.save(D+f'ap/img/{name}.jpg',quality=90); print(name,len(fr))
strip('walk',[(9,0,5),(10,0,5),(11,0,2)],270,480,5)
strip('trick',[(12,0,5),(13,0,5),(14,0,2)],270,480,5)
strip('intro',[(15,0,6),(16,0,6)],466,262,3)
strip('cover',[(17,0,6),(18,0,6)],466,262,3)
print(len(cov))
