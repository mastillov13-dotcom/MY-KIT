import wave,numpy as np,sys
def rd(p):
  w=wave.open(p);return np.frombuffer(w.readframes(w.getnframes()),np.int16).reshape(-1,2).astype(np.float32)/32768
def wr(p,a,sr=44100):
  w=wave.open(p,'wb');w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(a,-1,1)*32767).astype(np.int16).tobytes());w.close()
from scipy.signal import butter,sosfiltfilt
I=rd("inst.wav");sr=44100;N=1024;H=256;win=np.hanning(N)
I=sosfiltfilt(butter(4,180,"hp",fs=sr,output="sos"),I,axis=0).astype(np.float32)
def S(x): 
  n=1+(len(x)-N)//H;return np.stack([np.fft.rfft(x[i*H:i*H+N]*win) for i in range(n)])
def iS(X,L):
  o=np.zeros(L+N);ws=np.zeros(L+N)
  for i,f in enumerate(X): o[i*H:i*H+N]+=np.fft.irfft(f)*win;ws[i*H:i*H+N]+=win**2
  return (o/np.maximum(ws,1e-6))[:L]
EV=[l.split() for l in open(sys.argv[1]) if l.strip()]
prev=[]
for k,(t,name,dur) in enumerate(EV):
  t=float(t);dur=float(dur);a=int((t-0.04)*sr);b=a+int(dur*sr)
  # профиль музыки: медиана спектра 1.2 с до события (без него)
  ctx=I[max(0,a-int(1.2*sr)):a].mean(1);P=np.median(np.abs(S(ctx)),axis=0)
  out=[]
  for c in range(2):
    x=I[a:b,c];X=S(np.pad(x,(0,N)));M=np.abs(X);G=np.clip((M-1.3*P)/np.maximum(M,1e-9),0.06,1)
    out.append(iS(X*G,len(x)))
  y=np.stack(out,1);fl=int(0.004*sr);fo=int(0.06*sr);y[:fl]*=np.linspace(0,1,fl)[:,None];y[-fo:]*=np.linspace(1,0,fo)[:,None]
  y/=max(np.abs(y).max(),1e-6);y*=0.89
  fn=f'/home/claude/r12/sfx/{k+1:02d}_{name}.wav';wr(fn,y);prev+= [y,np.zeros((int(0.45*sr),2))]
wr('/home/claude/r12/sfx/_preview_all.wav',np.concatenate(prev))
print(len(EV))
