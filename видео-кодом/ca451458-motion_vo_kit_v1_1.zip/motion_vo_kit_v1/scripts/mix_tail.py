# ================= реверберация (короткий воздушный хвост) =================
n = int(1.1 * SR); tt = np.arange(n) / SR
ir = np.stack([rng.normal(0, 1, n), rng.normal(0, 1, n)], 1) * np.exp(-tt / .28)[:, None]
ir[:int(.018 * SR)] = 0
for c in range(2): ir[:, c] = lp(hp(ir[:, c], 350), 7000)
ir /= np.sqrt((ir ** 2).sum(0))[None, :]
VERB = np.stack([fftconvolve(SEND[:, c], ir[:, c])[:N] for c in range(2)], 1) * .5

# ================= шина: приседание под голос, мягкая полка, лимит =================
VP = sys.argv[2] if len(sys.argv) > 2 else None
v = np.zeros(N) if not VP else np.frombuffer(subprocess.run(['ffmpeg', '-v', 'error', '-i', VP, '-ac', '1', '-ar', str(SR), '-f', 's16le', '-'], capture_output=True).stdout, np.int16).astype(float) / 32767
v = np.pad(v, (0, max(0, N - len(v))))[:N]
env = np.sqrt(np.maximum(lp(v ** 2, 8), 0)); env = env / (env.max() + 1e-9)
duck = 1 - .32 * np.clip(env * 4, 0, 1)                                       # до −3,3 дБ под словами
STEMS = {'low': BUS['low'] * dB(2), 'air': BUS['air'] * duck[:, None] * dB(6), 'ui': BUS['ui'] * (1 - .15 * np.clip(env * 4, 0, 1))[:, None] * dB(0), 'verb': VERB * duck[:, None] * dB(3)}
mix = sum(STEMS.values())
mix[-int(.4 * SR):] *= np.linspace(1, 0, int(.4 * SR))[:, None]
pk = np.abs(mix).max(); g = min(1, .9 / pk)
def wr(p, a):
    f = wave.open(p, 'wb'); f.setnchannels(2); f.setsampwidth(2); f.setframerate(SR); f.writeframes((np.clip(a, -1, 1) * 32767).astype(np.int16).tobytes()); f.close()
for k, a in STEMS.items(): wr(f'stems/sfx_{k}.wav', a * g)
wr('sfx.wav', mix * g)
print('пик', round(pk, 3), 'gain', round(g, 2))

