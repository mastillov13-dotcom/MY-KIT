"""Пост-обработка голоса-эталона: паузы >0.24 c → 0.18 c (кроссфейд 10 мс), tempo 1.12, loudnorm -15, 48 кГц.
python3 vo_proc.py in.mp3 out.wav"""
import sys,subprocess,wave,numpy as np
src,dst=sys.argv[1],sys.argv[2]
subprocess.run(['ffmpeg','-v','error','-y','-i',src,'-ac','1','-ar','48000','/tmp/_vo_in.wav'],check=True)
w=wave.open('/tmp/_vo_in.wav');sr=w.getframerate();a=np.frombuffer(w.readframes(w.getnframes()),np.int16).astype(np.float32)/32768
h=int(sr*0.01);n=len(a)//h;db=20*np.log10(np.sqrt((a[:n*h].reshape(n,h)**2).mean(1))+1e-9)
sil=db<(np.percentile(db,95)-38)
# отрезки тишины
segs=[];i=0
while i<n:
  if sil[i]:
    j=i
    while j<n and sil[j]:j+=1
    segs.append((i,j));i=j
  else:i+=1
keep=0.18;xf=int(sr*0.01);out=[];pos=0
for i,j in segs:
  s,e=i*h,j*h
  if (e-s)/sr>0.24:
    if s==0: pos=e-int(0.05*sr);continue
    if e>=n*h-h: out.append(a[pos:s+int(0.25*sr)]);pos=len(a);break
    cut_a=s+int(keep/2*sr);cut_b=e-int(keep/2*sr)
    seg=a[pos:cut_a+xf].copy();out.append(seg);pos=cut_b
if pos<len(a):out.append(a[pos:])
y=out[0]
for seg in out[1:]:
  f=np.linspace(0,1,xf);y=np.concatenate([y[:-xf],y[-xf:]*(1-f)+seg[:xf]*f,seg[xf:]])
wo=wave.open('/tmp/_vo_cut.wav','wb');wo.setnchannels(1);wo.setsampwidth(2);wo.setframerate(sr);wo.writeframes((np.clip(y,-1,1)*32767).astype(np.int16).tobytes());wo.close()
subprocess.run(['ffmpeg','-v','error','-y','-i','/tmp/_vo_cut.wav','-af','rubberband=tempo=1.12:transients=crisp:formant=preserved,loudnorm=I=-15:TP=-1.5:LRA=9','-ar','48000',dst],check=True)
print('src',len(a)/sr,'cut',len(y)/sr)
