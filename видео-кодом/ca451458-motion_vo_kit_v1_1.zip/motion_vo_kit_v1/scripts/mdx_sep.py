"""Разделение на подложку (музыка+эффекты) и голос моделью UVR MDX-Net Inst_HQ_3 (onnx, без torch).
python3 mdx_sep.py in.wav out_inst.wav out_voc.wav   (вход 44.1 кГц стерео)"""
import sys, wave, numpy as np, onnxruntime as ort

NFFT, HOP, DF, DT = 6144, 1024, 3072, 256
CH = HOP * (DT - 1)  # 261120 сэмплов на кусок
WIN = (0.5 - 0.5 * np.cos(2 * np.pi * np.arange(NFFT) / NFFT)).astype(np.float32)


def rd(p):
    w = wave.open(p); n = w.getnframes(); c = w.getnchannels()
    a = np.frombuffer(w.readframes(n), np.int16).astype(np.float32) / 32768
    a = a.reshape(-1, c).T
    return (np.vstack([a, a]) if c == 1 else a), w.getframerate()


def wr(p, a, sr):
    a = np.clip(a.T, -1, 1); w = wave.open(p, 'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr)
    w.writeframes((a * 32767).astype(np.int16).tobytes()); w.close()


def stft(x):  # x [2, L] -> [2, F, T] complex, center=True (reflect), как torch.stft
    p = NFFT // 2
    x = np.pad(x, ((0, 0), (p, p)), mode='reflect')
    T = 1 + (x.shape[1] - NFFT) // HOP
    idx = np.arange(NFFT)[None, :] + HOP * np.arange(T)[:, None]
    fr = x[:, idx] * WIN  # [2, T, NFFT]
    return np.fft.rfft(fr, axis=-1).transpose(0, 2, 1)


def istft(S, L):  # S [2, F, T]
    T = S.shape[2]
    fr = np.fft.irfft(S.transpose(0, 2, 1), n=NFFT, axis=-1) * WIN
    out = np.zeros((2, NFFT + HOP * (T - 1)), np.float32); ws = np.zeros(out.shape[1], np.float32)
    for t in range(T):
        out[:, t * HOP:t * HOP + NFFT] += fr[:, t]; ws[t * HOP:t * HOP + NFFT] += WIN ** 2
    out /= np.maximum(ws, 1e-8)
    p = NFFT // 2
    return out[:, p:p + L]


sess = ort.InferenceSession('/home/claude/models/Inst_HQ_3.onnx')


def run(chunk):
    S = stft(chunk)  # [2, 3073, 256]
    X = np.stack([S[0].real, S[0].imag, S[1].real, S[1].imag])[:, :DF][None].astype(np.float32)
    Y = sess.run(None, {'input': X})[0][0]
    Z = np.zeros((2, NFFT // 2 + 1, Y.shape[2]), np.complex64)
    Z[0, :DF] = Y[0] + 1j * Y[1]; Z[1, :DF] = Y[2] + 1j * Y[3]
    return istft(Z, chunk.shape[1])


mix, sr = rd(sys.argv[1]); L = mix.shape[1]
step = CH // 2
pad = np.pad(mix, ((0, 0), (step, step + CH)))
acc = np.zeros_like(pad); wsum = np.zeros(pad.shape[1], np.float32)
fade = np.hanning(CH).astype(np.float32)
for s in range(0, pad.shape[1] - CH + 1, step):
    acc[:, s:s + CH] += run(pad[:, s:s + CH]) * fade; wsum[s:s + CH] += fade
inst = (acc / np.maximum(wsum, 1e-6))[:, step:step + L] * 1.022
wr(sys.argv[2], inst, sr); wr(sys.argv[3], mix - inst, sr)
print('ok', L / sr)
