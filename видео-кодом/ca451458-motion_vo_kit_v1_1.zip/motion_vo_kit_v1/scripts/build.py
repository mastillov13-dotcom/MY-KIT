import sys
END=float(sys.argv[1])
open('/home/claude/r13/ap/index.html','w').write(open('/home/claude/r13/tpl.html').read().replace('%END%',str(END)))
