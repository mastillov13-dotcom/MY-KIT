# kod_n3 — ролик кодом «Свой голос — без подписки» (Voicebox), 04.11.2026
Основа: reel10.html (кит v10) + слой n3. Итог: reel_n3.html, 40.4 с, 1215 кадров, голос Леонида (v4, s0.5/sim0.75).
Слой темы: главный предмет — микрофон MIC (кольца по AMP, на хуке цепь «ПОДПИСКА» лопается), палитра #E3F2EC / #0F3B36 / #FFC531, обводки тёмных карточек мятные #5BE0B0.
Петля: «Но есть один минус — скажу в конце» → карточка со шторками + флажок на шкале → раскрытие в фразе 11.
Библиотека в build/n3_blocks.py: FP (отпечаток), WAVE (волна от AMP), LOCK, slam, MIC + сцены bB…bL.
Сборка: python3 -I build/build_n3.py . timing.json (тайминги: build/est_timing.py → timing_real.py по ASR)
Рендер: PAGE=reel_n3.html node render.js video v.mp4 · Звук: python3 -I build/mix_n3.py timing.json voice_p.wav <sfx_library> mix.wav · Обложки: node build/cover.js reel_n3.html · Превью куска: node build/clip.js reel_n3.html t0 t1 out.mp4
Новый ролик: скопировать папку, заменить блоки в n3_blocks.py (THEME, SC_JS, SECT_JS, SCENES, GRP_JS, NEW_B, HERO_JS), VOICE в est_timing.py, события в mix_n3.py.
