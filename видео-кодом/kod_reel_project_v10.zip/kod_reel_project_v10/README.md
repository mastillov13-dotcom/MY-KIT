# kod_reel_project_v10 — ролик кодом с персонажем, «советник Opus» (31.10.2026)

Готовый ролик: 39.6 с, 1080x1920, 30 к/с, голос Леонида. Итоговая страница — **reel10.html**.

## Что где лежит
- **reel5.html** — движок v5: seek(t), персонаж, субтитры, механика всасывания и вылета, пиксели, поля. Это база для новых роликов, её не трогать.
- **reel6…reel10.html** — слои поверх движка, каждый собирается своим скриптом из build/.
- **build/**:
  - est_timing.py — текст озвучки (VOICE) и оценочные тайминги до прихода голоса;
  - timing_real.py — реальные тайминги из ASR и огибающая рта из wav, на выходе timing.json;
  - build6.py — сюжет: фразы SC, сцены-биты, анимации B[i], тайминги (reel5 → reel6);
  - build7.py — слой темы: палитра, главный предмет-шкала, без баннеров, субтитры над картинкой, строки интерфейса (→ reel7);
  - build8.py — хук с тряской, ростом и паром, контраст, инфографика по смыслу, финал (→ reel8);
  - build9.py — батареи вместо кругов (жёлтая — лёгкая нагрузка, красная — слив), синяя обводка тёмных карточек, фон #18213A (→ reel9);
  - build10.py — эмоции вокруг персонажа (→ reel10);
  - mix6.py — голос и 57 SFX под события сцен, сайдчейн, loudnorm −14;
  - measure.js — DOM-проверка поля слева (left < 80);
  - stills.js — стоп-кадры.
- **voice_p.wav** — голос после нормализации; **timing.json** — реальные тайминги; **mix_v10.wav** — финальный звук.
- **legacy_v5/** — голос, тайминги, mix.py и история патчей ролика v5 «розы».

## Пайплайн (NODE_PATH=$(npm root -g))
1. Озвучка: ElevenLabs (Леонид v4) в Chrome Алекса → скачать в «Загрузки» → забрать в сессию.
2. Нормализация: `ffmpeg -i take.mp3 -ac 1 -af loudnorm=I=-15:TP=-1.5:LRA=9 -ar 48000 voice_p.wav`. Ускорение ×1.12 из кита не применять, если важна длина.
3. ASR: sherpa-onnx zipformer-ru, модель берётся с GitHub k2-fsa: `chunks.py` → `asr.py` из motion_vo_kit (на 16 кГц) → `python3 -I build/timing_real.py asr.txt voice_p.wav timing.json`.
4. Сборка: `python3 -I build/build6.py . timing.json`, затем по очереди build7 … build10 с аргументом `.`.
5. Проверка: `node build/measure.js reel10.html` (допустим только пустой бокс #hero) и стоп-кадры `node build/stills.js reel10.html 1.5,9,…`.
6. Рендер: `PAGE=reel10.html node render.js video v.mp4` — 1190 кадров, около 6 минут. Запускать в фоне через nohup.
7. Звук: `python3 -I build/mix6.py timing.json voice_p.wav <motion_vo_kit_v1/sfx_library> mix.wav` → `ffmpeg -i v.mp4 -i mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -shortest`.

## Как делать следующий ролик
Берётся reel5.html как движок. Пишется свой build6 (сюжет и сцены) и свой слой темы: палитра, главный предмет, вставки. Из v10 можно брать как библиотеку функции GAUGE (шкала), BAT (батарея), emoUpd (эмоции), phoneArt2 (экраны веера). Правила записаны в скилле kod-reel-character.
