# kod_n1 — ролик кодом «Этот ролик нарисовал код / безлимит» (04.11.2026)
Основа: кит v10 из MY-KIT (движок reel5 + библиотека v10). Итог: reel_n1.html, 43.6 с, 1310 кадров, голос Леонида (v4, s0.5/sim0.75; ползунка скорости в новом интерфейсе нет).
Слой темы: главный предмет — кадр-счётчик (FRAMEC), палитра #ECE8F4 / #1A2142 / #FF6A1A, вкладки веера tabArt (сказка, мультик, объяснялка, бренд, кит), раскадровка sbArt на плёнке рендера, мини-копия ролика miniReel, петля «план разбора» + ШАГ n/5.
Сборка: python3 -I build/build_n1.py . timing.json (тайминги: build/est_timing.py → timing_real.py по ASR из vo/asrA.txt)
Рендер: PAGE=reel_n1.html node render.js video v.mp4 · Звук: python3 -I build/mix_n1.py timing.json voice_p.wav <sfx_library> mix.wav · Обложки: node build/cover.js reel_n1.html
