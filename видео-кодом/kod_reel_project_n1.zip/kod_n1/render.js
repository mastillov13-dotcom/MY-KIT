// node render.js stills 1.5,5,9  |  node render.js video out.mp4
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const path = require('path');
(async () => {
  const [mode, arg] = process.argv.slice(2);
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1080, height: 1920 } });
  await page.goto('file://' + path.resolve(__dirname, process.env.PAGE||'reel.html'));
  await page.evaluate(async () => { await Promise.all(['800 76px M','italic 500 82px P','500 24px J'].flatMap(f => [document.fonts.load(f,'Аа'),document.fonts.load(f,'Aa')])); await document.fonts.ready; });
  if (mode === 'stills') {
    for (const t of arg.split(',').map(Number)) {
      await page.evaluate(t => seek(t), t);
      await page.screenshot({ path: `still_${t}.jpg`, type: 'jpeg', quality: 80 });
    }
  } else {
    const fps = 30, total = await page.evaluate(() => TOTAL), n = Math.ceil(total * fps);
    const ff = spawn('ffmpeg', ['-y', '-v', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-i', '-',
      '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', arg]);
    for (let i = 0; i < n; i++) {
      await page.evaluate(t => seek(t), i / fps);
      const buf = await page.screenshot({ type: 'jpeg', quality: 92 });
      if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
      if (i % 300 === 0) console.log('frame', i, '/', n);
    }
    ff.stdin.end(); await new Promise(r => ff.on('close', r));
  }
  await browser.close();
})();
