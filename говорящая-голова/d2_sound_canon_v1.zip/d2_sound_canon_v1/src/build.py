import subprocess,numpy as np,sys,os,json
SR=48000; A=sys.argv[1]; B=sys.argv[2]; O=sys.argv[3]
rng=np.random.default_rng(7)
def load(p):
    r=subprocess.run(['ffmpeg','-v','error','-i',p,'-ac','1','-ar',str(SR),'-f','f32le','-'],capture_output=True); return np.frombuffer(r.stdout,np.float32).copy()
def save(name,x,lead=0.0):
    x=np.asarray(x,np.float32)
    # trim leading/trailing silence (< -60 dB rel peak), keep 5 ms
    pk=np.max(np.abs(x))+1e-9; idx=np.where(np.abs(x)>pk*10**(-60/20))[0]
    x=x[max(0,idx[0]-240):idx[-1]+2400]
    f=int(.004*SR); x[:f]*=np.linspace(0,1,f); x[-f*5:]*=np.linspace(1,0,f*5)
    x=x/np.max(np.abs(x))*10**(-1/20)
    st=np.stack([x,x],1).astype(np.float32).tobytes()
    subprocess.run(['ffmpeg','-v','error','-y','-f','f32le','-ar',str(SR),'-ac','2','-i','-','-c:a','pcm_s16le',os.path.join(O,name+'.wav')],input=st)
def rs(x,f):  # pitch/speed by resample factor f (>1 higher)
    n=int(len(x)/f); return np.interp(np.arange(n)*f,np.arange(len(x)),x).astype(np.float32)
def place(out,x,t,g=1.0):
    i=int(t*SR); out[i:i+len(x)]+=g*x[:max(0,len(out)-i)]
# 1 reverse bell: bell_2 + echo/reverb tail, reversed; stutter variant with ~7 Hz scallops
b=load(f'{A}/bell_2.wav'); tail=np.zeros(len(b)+int(1.2*SR),np.float32); tail[:len(b)]+=b
for d,g in [(.09,.5),(.17,.38),(.26,.28),(.37,.2),(.5,.13),(.66,.08)]: place(tail,b,d,g)
rb=tail[::-1].copy(); save('reverse_bell',rb)
t=np.arange(len(rb))/SR; L=len(rb)/SR
# stutter: square gates first 25%, then reversed-decay scallops at accelerating rate
env=np.ones_like(rb); per=0.13
gate=t<L*.22; env[gate]=((t[gate]%per)<per*.62).astype(np.float32)
sc=~gate; ph=((t[sc]-L*.22)%0.115)/0.115; env[sc]=0.35+0.65*ph**1.6
save('reverse_bell_stutter',rb*env)
# 2 click roll (щелчки): 12 clicks from mouse_click, ~115 ms apart
mc=load(f'{A}/mouse_click.wav'); pk=np.argmax(np.abs(mc[:int(.16*SR)])); c1=mc[max(0,pk-int(.004*SR)):pk+int(.05*SR)]
out=np.zeros(int(1.6*SR),np.float32); tt=0.0
for i in range(12):
    g=rng.uniform(.6,1.0); place(out,rs(c1,rng.uniform(.9,1.12)),tt,g); tt+=0.115*rng.uniform(.92,1.08)
save('click_roll',out)
# 3 shutter: single + burst of 9 (dense middle)
cf=load(f'{A}/camera_flash.wav'); pk=np.argmax(np.abs(cf)); sh=cf[max(0,pk-int(.012*SR)):pk+int(.09*SR)]
save('shutter_single',sh)
out=np.zeros(int(1.0*SR),np.float32); n=9
for i in range(n):
    g=0.45+0.55*np.sin(np.pi*(i+.5)/n); place(out,rs(sh,rng.uniform(.95,1.06)),0.02+i*0.078*rng.uniform(.93,1.07),g)
save('shutter_burst',out)
# 4 keyboard long ~2.4 s from keyboard.wav strokes
kb=load(f'{A}/keyboard.wav'); e=np.array([np.sqrt(np.mean(kb[i:i+240]**2)) for i in range(0,len(kb)-240,240)])
on=[i for i in range(1,len(e)) if e[i]>e.max()*.25 and e[i-1]<=e.max()*.25]
strokes=[kb[o*240-120:o*240+int(.07*SR)] for o in on]
out=np.zeros(int(2.6*SR),np.float32); tt=0.0
while tt<2.35:
    s=strokes[rng.integers(len(strokes))]; place(out,rs(s,rng.uniform(.94,1.06)),tt,rng.uniform(.55,1)); tt+=rng.choice([.09,.11,.13,.16,.24],p=[.25,.3,.25,.12,.08])
save('keyboard_long',out)
# 5 picks from car pack (trim + normalize)
for src,dst in [('cinematic_whoosh','whoosh_in_cut'),('spin_whoosh','whoosh_in_heavy'),('whistle_whoosh','whistle_swish'),('final_outro','low_boom_drama'),('hit_outro','impact_cine'),('glitch','glitch_cut'),('shutter_hit','shutter_boom')]:
    save(dst,load(f'{B}/{src}.wav'))
# copies from alex_pack used in the canon (same files, canon names)
for src,dst in [('whoosh_1','whoosh_out'),('whoosh_3','whoosh_zoom'),('whoosh_1_2','whoosh_soft'),('riser_2','riser_tension'),('chopping_riser','riser_chop'),('glitch_2','glitch_short'),('hit_2','impact_short'),('blink','ui_blink'),('notification','ui_notify'),('pop','ui_pop'),('mouse_click','click_single'),('keyboard','keyboard_short'),('whistle','whistle_tone')]:
    save(dst,load(f'{A}/{src}.wav'))
