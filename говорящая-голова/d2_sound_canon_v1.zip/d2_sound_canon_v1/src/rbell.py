import numpy as np,sys
sys.argv=['x','a','b','canon']; exec(open('scripts/build.py').read().split('# 1 reverse bell')[0])
from scipy.signal import fftconvolve
b=load('a/bell_2.wav'); n=int(1.6*SR); t=np.arange(n)/SR
ir=rng.standard_normal(n).astype(np.float32)*np.exp(-t/0.45); ir/=np.sqrt(np.sum(ir**2))
wet=fftconvolve(b,ir)[:len(b)+n]; dry=np.zeros_like(wet); dry[:len(b)]=b
x=(dry*0.8+wet*0.6/np.max(np.abs(wet))*np.max(np.abs(b)))[::-1].copy()
x=x[-int(1.7*SR):]; save('reverse_bell',x)
tt=np.arange(len(x))/SR; L=len(x)/SR
# compress swell (reference is near full-height), then stutter: gated blocks, then ~8.5 Hz scallops
e=np.sqrt(np.convolve(x**2,np.ones(2400)/2400,'same'))+1e-4; xc=x/np.maximum(e,np.max(e)*.25)
env=np.ones_like(xc); g=tt<L*.25; env[g]=((tt[g]%0.12)<0.075); s=~g; ph=((tt[s]-L*.25)%0.118)/0.118; env[s]=0.3+0.7*ph**1.5
y=xc*env*np.linspace(.55,1,len(xc)); save('reverse_bell_stutter',y)
