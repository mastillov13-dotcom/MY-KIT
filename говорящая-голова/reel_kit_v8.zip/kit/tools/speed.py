"""Доускорение готовой нарезки по кускам + доп. цветокор.
python3 speed.py <w-dir> <p-dir> <kmax> <fcap>
Куски: k_i = min(kmax, fcap / F_i), хук (кусок 0) не трогаем (в него вшит эффект).
Меняет: w/graded.mp4, w/mask.mp4, w/voice_c.wav, w/words_cut.json, w/edl.json, p/graded.mp4. Делает копии *_old."""
import json, subprocess, sys, os, shutil
W_, P_, KMAX, FCAP = sys.argv[1], sys.argv[2], float(sys.argv[3]), float(sys.argv[4])
os.chdir(W_)
FPS = 30
GRADE2 = "curves=master='0/0 0.12/0.10 0.45/0.47 0.78/0.75 1/0.92',eq=contrast=1.05:saturation=1.06,colorbalance=rm=0.015:bm=-0.015:rh=0.01:bh=-0.01"
for f in ('graded.mp4', 'mask.mp4', 'voice_c.wav', 'words_cut.json', 'edl.json'):
    if not os.path.exists(f + '.old'):
        shutil.copy(f, f + '.old')
shutil.copy('edl.json.old', 'edl.json')
edl = json.load(open('edl.json.old'))
words = json.load(open('words_cut.json.old'))
if not os.path.exists(P_ + '/graded_old.mp4'):
    shutil.copy(P_ + '/graded.mp4', P_ + '/graded_old.mp4')
pieces = []
t_new = 0.0
for i, e in enumerate(edl):
    a, b = e['out']
    nf = round((b - a) * FPS)
    k = 1.0 if i == 0 else max(1.0, min(KMAX, FCAP / e['F']))
    nf2 = nf if i == 0 else round(nf / k)
    pieces.append(dict(i=i, a=a, b=b, sf=round(a * FPS), nf=nf, k=k, nf2=nf2, A=round(t_new, 4)))
    t_new += nf2 / FPS
for p in pieces:
    print(edl[p['i']]['name'], 'k=%.3f' % p['k'], '%.2f->%.2f' % (p['b'] - p['a'], p['nf2'] / FPS))
print('total', edl[-1]['out'][1], '->', round(t_new, 3))
json.dump(pieces, open('tmap.json', 'w'))


def vgraph(srcs, grade):
    parts = []
    for p in pieces:
        s = srcs(p['i'])
        parts.append(f"[{s}:v]trim=start_frame={p['sf']}:end_frame={p['sf'] + p['nf']},setpts=(PTS-STARTPTS)/{p['k']:.5f},fps={FPS},trim=end_frame={p['nf2']},setpts=PTS-STARTPTS[v{p['i']}]")
    cat = ''.join(f"[v{p['i']}]" for p in pieces) + f"concat=n={len(pieces)}:v=1:a=0" + (',' + grade if grade else '') + '[o]'
    return ';'.join(parts) + ';' + cat


def run(inputs, graph, out, crf=14):
    open('_g.txt', 'w').write(graph)
    cmd = ['ffmpeg', '-v', 'error', '-y']
    for x in inputs:
        cmd += ['-i', x]
    cmd += ['-filter_complex_script', '_g.txt', '-map', '[o]', '-r', str(FPS), '-c:v', 'libx264', '-crf', str(crf), '-preset', 'veryfast', '-pix_fmt', 'yuv420p', out]
    subprocess.run(cmd, check=True)


# w-graded (без хука) и p-graded (хук вшит в кусок 0 из старого p/graded)
run(['graded.mp4.old'], vgraph(lambda i: 0, GRADE2), 'graded.mp4')
run([P_ + '/graded_old.mp4', 'graded.mp4.old'], vgraph(lambda i: 0 if i == 0 else 1, GRADE2), P_ + '/graded.mp4')
# маска (без цвета)
run(['mask.mp4.old'], vgraph(lambda i: 0, ''), 'mask.mp4', crf=12)
# голос
fa = []
for p in pieces:
    a, b = p['a'], p['b']
    fa.append(f"[0:a]atrim={a:.4f}:{b:.4f},asetpts=PTS-STARTPTS,atempo={p['k']:.5f},apad,atrim=0:{p['nf2'] / FPS:.4f},asetpts=PTS-STARTPTS[a{p['i']}]")
g = ';'.join(fa) + ';' + ''.join(f"[a{p['i']}]" for p in pieces) + f"concat=n={len(pieces)}:v=0:a=1[o]"
open('_ga.txt', 'w').write(g)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', 'voice_c.wav.old', '-filter_complex_script', '_ga.txt', '-map', '[o]', '-c:a', 'pcm_s16le', '-ar', '48000', 'voice_c.wav'], check=True)


def T(t):
    for p in pieces:
        if p['a'] - 1e-6 <= t < p['b'] - 1e-6:
            return p['A'] + (t - p['a']) / p['k']
    return pieces[-1]['A'] + pieces[-1]['nf2'] / FPS


json.dump([[w[0], round(T(w[1]), 4)] for w in words], open('words_cut.json', 'w'), ensure_ascii=False)
new = []
for p, e in zip(pieces, edl):
    e = dict(e); e['out'] = [p['A'], round(p['A'] + p['nf2'] / FPS, 4)]; e['F'] = round(e['F'] * p['k'], 3); new.append(e)
json.dump(new, open('edl.json', 'w'))
print('done')
