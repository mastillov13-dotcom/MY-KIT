import sys, subprocess
# python3 person.py <graded> <mask> <start> <dur> <out> [maskscale]
g,m,st,d,out=sys.argv[1:6]
ms=len(sys.argv)>6
fm=f"[1:v]trim=start={st}:duration={d},setpts=PTS-STARTPTS"+(",scale=1080:1920:flags=bicubic" if ms else "")+",format=gray[m];"+f"[0:v]trim=start={st}:duration={d},setpts=PTS-STARTPTS[v];[v][m]alphamerge[o]"
subprocess.run(['ffmpeg','-v','error','-y','-i',g,'-i',m,'-filter_complex',fm,'-map','[o]','-c:v','libvpx-vp9','-pix_fmt','yuva420p','-b:v','0','-crf','24','-auto-alt-ref','0','-r','30',out],check=True)
