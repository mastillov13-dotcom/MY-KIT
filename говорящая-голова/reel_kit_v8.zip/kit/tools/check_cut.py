"""Перепроверка нарезки после cut.py — до графики.
1) Заново распознаёт смонтированный звук по кускам и ищет мусор: угу, мм, эм, ой, блять, «закадрово» и т. п.
2) Собирает лист кадров: начало / середина / конец каждого куска — проверить взгляд (в камеру, а не в сторону/вниз),
   руки у лица, моргание на склейке.
3) Сверяет текст с ожидаемым сценарием (script.txt, если есть): лишние и пропавшие слова.
Использование: python3 check_cut.py  (в папке проекта: proj/cut.mp4, edl.json) → cut_check.txt, cut_sheet.png"""
import json, os, subprocess, sys
sys.path.insert(0, '/home/claude/asr')
JUNK = {'угу', 'мм', 'ммм', 'эм', 'э', 'ээ', 'ой', 'ага', 'блять', 'бля', 'короче', 'закадрово', 'харкнул', 'так-так'}
edl = json.load(open('edl.json'))
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', 'proj/cut.mp4', '-ac', '1', '-ar', '16000', 'chk.wav'], check=True)
cuts = [p['out'][0] for p in edl] + [edl[-1]['out'][1]]
raw = subprocess.run(['python3', '/home/claude/asr/asr.py', 'chk.wav'] + [f'{c:.3f}' for c in cuts], capture_output=True, text=True).stdout.strip()
ws = [(w, int(a) / 100) for w, a, b in (x.rsplit(',', 2) for x in raw.split('|') if x)]
out = []
for i, p in enumerate(edl):
    a, b = p['out']
    seg = [w for w, t in ws if a <= t < b]
    bad = [w for w in seg if w.lower() in JUNK]
    out.append(f"кусок {i:2d} {a:6.2f}–{b:6.2f} (исх. {p['src'][0]:.2f}) {'!! ' + ','.join(bad) if bad else '  '} | {' '.join(seg)}")
if os.path.exists('script.txt'):
    import difflib
    exp = open('script.txt', encoding='utf-8').read().lower().replace(',', ' ').replace('.', ' ').split()
    got = [w.lower() for w, t in ws]
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, exp, got).get_opcodes():
        if op != 'equal':
            out.append(f'СЦЕНАРИЙ {op}: ждали «{" ".join(exp[i1:i2])}» — в нарезке «{" ".join(got[j1:j2])}»')
open('cut_check.txt', 'w').write('\n'.join(out))
print('\n'.join(out))
# лист кадров: по 3 кадра на кусок, подпись — время
tiles = []
for i, p in enumerate(edl):
    a, b = p['out']
    for k, t in enumerate((a + .08, (a + b) / 2, b - .1)):
        f = f'/tmp/cc_{i}_{k}.png'
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{t:.2f}', '-i', 'proj/cut.mp4', '-frames:v', '1', '-vf',
                        f"crop=720:720:180:240,scale=150:150,drawtext=text='{i}·{t:.1f}':x=4:y=4:fontsize=18:fontcolor=white:box=1:boxcolor=black@0.6", f], check=True)
        tiles.append(f)
cols = 9
args = sum([['-i', f] for f in tiles], [])
layout = '|'.join(f'{(j % cols) * 150}_{(j // cols) * 150}' for j in range(len(tiles)))
subprocess.run(['ffmpeg', '-v', 'error', '-y'] + args + ['-filter_complex', f'xstack=inputs={len(tiles)}:layout={layout}:fill=black', 'cut_sheet.png'], check=True)
print('лист кадров: cut_sheet.png')
