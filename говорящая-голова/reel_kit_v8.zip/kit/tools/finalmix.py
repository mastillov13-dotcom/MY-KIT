"""Финальный микс: голос + sfx + музыка GTA с кульминации (9.88 с), музыка ~-29 LUFS в стеме.
python3 finalmix.py <w-dir> <sfx.wav> <out_mix.wav> <out_music_stem.wav>"""
import sys, os, subprocess, re, numpy as np, soundfile as sf
W_, SFX, OUT, STEM = sys.argv[1:5]
os.chdir(W_)
SR = 48000
START = 9.88
v, _ = sf.read('voice_c.wav', dtype='float32'); v = np.stack([v, v], 1) if v.ndim == 1 else v
s, _ = sf.read(SFX, dtype='float32')
TOTAL = len(v) / SR
N = int(round(TOTAL * SR))
# музыка: с удара, fade-in 30 мс, fade-out 1.2 с к концу ролика
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(START), '-t', str(TOTAL + 0.1), '-i', '/home/claude/mus/gta.wav', '-ac', '2', '-ar', str(SR), '_m.wav'], check=True)
m, _ = sf.read('_m.wav', dtype='float32'); m = m[:N]
if len(m) < N: m = np.vstack([m, np.zeros((N - len(m), 2), np.float32)])
r = subprocess.run(['ffmpeg', '-nostats', '-i', '_m.wav', '-af', 'ebur128', '-f', 'null', '-'], capture_output=True, text=True).stderr
L = float(re.findall(r'I:\s+(-?\d+\.\d+) LUFS', r)[-1])
g = 10 ** ((-29.0 - L) / 20)
m = m * g
f = int(.03 * SR); m[:f] *= np.linspace(0, 1, f)[:, None]
f = int(1.2 * SR); m[-f:] *= np.linspace(1, 0, f)[:, None]
print('music in %.1f LUFS, gain %.3f' % (L, g))
sf.write(STEM, m, SR)
mix = np.zeros((N, 2), np.float32)
mix[:len(v[:N])] += v[:N]; mix[:min(N, len(s))] += s[:N]; mix += m
sf.write('_mix_raw.wav', mix, SR)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', '_mix_raw.wav', '-af', 'loudnorm=I=-16:TP=-1.7:LRA=7', '-ar', str(SR), OUT], check=True)
r = subprocess.run(['ffmpeg', '-nostats', '-i', OUT, '-af', 'ebur128=peak=true', '-f', 'null', '-'], capture_output=True, text=True).stderr
print([l.strip() for l in r.splitlines() if 'I:' in l or 'Peak' in l][-2:])
