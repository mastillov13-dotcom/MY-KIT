import sys, json
from playwright.sync_api import sync_playwright
d=sys.argv[1]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1080,'height':1920})
    pg.goto(f'file://{d}/index.html'); pg.wait_for_timeout(1500)
    res=pg.evaluate("""()=>{
      const out=[];
      const sel='#front .ctr, #front .panel, #front .tl, #front .bt, #front .bl, #front .bs, #front .sx, #front .sc, #vs, #pay, #tm';
      document.querySelectorAll(sel).forEach(e=>{
        const nodes=[];
        if(e.classList.contains('ctr')) e.querySelectorAll('span').forEach(s=>{ if(!s.querySelector('span')) nodes.push(s)});
        else nodes.push(e);
        nodes.forEach(n=>{const r=n.getBoundingClientRect(); out.push([e.id||n.className, n.textContent.trim().slice(0,28), Math.round(r.left),Math.round(r.right),Math.round(r.top),Math.round(r.bottom)])});
      });
      return out}""")
    bad=0
    for id_,t,l,r,tp,bt in res:
        flag=''
        if l<120-2 or r>960+2: flag+=' X!'
        if tp<180 or bt>1660: flag+=' Y!'
        if tp>=900 and bt>1400: flag+=' LOW!(>1400, к субтитрам)'
        if bt>1300 and r>860+2: flag+=' BTN!(>860 у кнопок)'
        if flag: bad+=1
        print('%-8s %-28s x %4d..%4d  y %4d..%4d%s'%(id_,t,l,r,tp,bt,flag))
    print('BAD',bad)
    b.close()
