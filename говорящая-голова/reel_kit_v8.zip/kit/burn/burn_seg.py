"""Тест: надпись «100 ПРОМПТОВ» за головой сгорает — полностью кодом, без нейросетей.
Слои снизу вверх: фон (общий цветокор) → подсветка стены от огня → тень текста → текст/обугливание/пепел
→ пламя (экран) → искры → человек по маске.  python3 burn.py out.mp4
"""
import subprocess, sys
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont

SRC, MASK = '/home/claude/reel5/proj/cut.mp4', '/home/claude/reel5/mask.mp4'
T0, DUR, FPS, W, H = 0.0, 3.867, 30, 1080, 1920
N = round(DUR * FPS)
APPEAR, IGNITE = 0.86, 1.50          # абсолютное время: «100» и начало горения
ROI = 1000                            # всё горение в верхних 1000 px
rng = np.random.default_rng(7)


# ---------- текст ----------
def text_layer(txt, font, size, sx, top, cx):
    F = ImageFont.truetype(font, size)
    l, t, r, b = F.getbbox(txt)
    im = Image.new('L', (r - l + 40, b - t + 40), 0)
    ImageDraw.Draw(im).text((20 - l, 20 - t), txt, font=F, fill=255)
    a = np.array(im, np.float32) / 255
    a = cv2.resize(a, (int(a.shape[1] * sx), a.shape[0]), interpolation=cv2.INTER_AREA)
    out = np.zeros((ROI, W), np.float32)
    x0 = int(cx - a.shape[1] / 2); y0 = top - 20
    out[y0:y0 + a.shape[0], x0:x0 + a.shape[1]] = a
    return out

def fit_layer(txt, font, tw, th, top, cx):
    F = ImageFont.truetype(font, 400); l, t, r, b = F.getbbox(txt)
    im = Image.new('L', (r - l, b - t), 0); ImageDraw.Draw(im).text((-l, -t), txt, font=F, fill=255)
    a = cv2.resize(np.array(im, np.float32) / 255, (tw, th), interpolation=cv2.INTER_AREA)
    out = np.zeros((ROI, W), np.float32); x0 = int(cx - tw / 2)
    out[top:top + th, x0:x0 + tw] = a
    return out

A1 = fit_layer('100', 'alat.woff', 540, 430, 92, 548)          # шрифт как в ролике: Alumni Sans Black
A2 = fit_layer('ПРОМПТОВ', 'acyr.woff', 840, 215, 540, 540)
A = np.maximum(A1, A2)


# ---------- шум ----------
def fbm(h, w, scales=(6, 14, 34, 80), amps=(1, .5, .25, .12), seed=0, stretch=1.0):
    r = np.random.default_rng(seed); s = np.zeros((h, w), np.float32)
    for sc, am in zip(scales, amps):
        g = r.random((max(2, int(h // (sc * stretch))), max(2, w // sc))).astype(np.float32)
        s += am * cv2.resize(g, (w, h), interpolation=cv2.INTER_CUBIC)
    s -= s.min(); return s / s.max()

V = 520                                                    # скорость подъёма огня, px/с
TALL = ROI + int(V * DUR) + 50
NF1, NF2 = fbm(TALL, W, (6, 13, 28, 60), (1, .6, .35, .2), seed=1, stretch=2.6), fbm(TALL, W, (9, 22, 50), (1, .5, .25), seed=2, stretch=2.0)
NDX, NDY = fbm(TALL, W, (20, 45, 110), (1, .5, .25), seed=3), fbm(TALL, W, (20, 45, 110), (1, .5, .25), seed=4)
FLAKE = fbm(ROI, W, (2, 4, 9), (1, .6, .3), seed=5)
SPB = fbm(ROI, W, (10, 24, 50), (1, .6, .3), seed=6)
SPF = fbm(ROI, W, (2, 4), (1, .5), seed=9)
PH = fbm(ROI, W, (14, 30), (1, .5), seed=10)

# карта времени воспламенения: от верхнего края «1» и правого края «ОВ», фронт рваный
seed = np.zeros((ROI, W), np.uint8)
cv2.circle(seed, (330, 120), 30, 255, -1); cv2.circle(seed, (950, 560), 30, 255, -1); cv2.circle(seed, (760, 100), 20, 255, -1)
dist = cv2.distanceTransform(255 - seed, cv2.DIST_L2, 5)
jag = fbm(ROI, W, (18, 40, 90), (1, .6, .3), seed=8)
# верхняя строка горит сверху вниз, нижняя — снизу вверх; фронт рваный и чуть волной по ширине
yy, xx = np.mgrid[0:ROI, 0:W].astype(np.float32)
r1 = np.nonzero(A1.max(1) > .5)[0]; r2 = np.nonzero(A2.max(1) > .5)[0]
wob = (fbm(1, W, (60, 140), (1, .5), seed=13)[0] - .5)[None, :]
B1 = IGNITE + (yy - r1[0]) / 330 + wob * .35 + (jag - .5) * .30
B2 = IGNITE + .12 + (r2[-1] - yy) / 230 + wob[:, ::-1] * .35 + (jag - .5) * .30
B = np.where(A1 >= A2, B1, B2)

# ---------- цвета ----------
def lut_fire(x):
    stops = np.array([0, .18, .38, .6, .82, 1.0])
    cols = np.array([[0, 0, 0], [110, 14, 0], [215, 58, 6], [255, 118, 18], [255, 170, 55], [255, 215, 130]], np.float32)
    return np.stack([np.interp(x, stops, cols[:, c]) for c in range(3)], -1)

CREAM = np.array([238, 232, 222], np.float32); SCORCH = np.array([120, 70, 32], np.float32)
CHAR = np.array([34, 22, 16], np.float32); ASH = np.array([150, 142, 134], np.float32)
EMBER = np.array([255, 150, 40], np.float32)

kern_up = np.zeros(521, np.float32); kern_up[260:] = np.exp(-np.arange(261) / 115.0)   # тянет свет вверх
kern_up /= kern_up.sum()

sparks = []      # [x, y, vx, vy, life, age]
FB = np.zeros((ROI // 2, W // 2), np.float32)
YS, XS = np.mgrid[0:ROI // 2, 0:W // 2].astype(np.float32)
CN = fbm(ROI // 2 + 2400, W // 2, (4, 9, 20, 45), (1, .6, .35, .2), seed=11, stretch=2.2)
TX = fbm(ROI // 2 + 1200, W // 2, (12, 28, 60), (1, .5, .25), seed=12)


def smooth(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)


dec = subprocess.Popen(['ffmpeg', '-v', 'error', '-ss', str(T0), '-i', SRC, '-t', str(DUR),
                        '-vf', 'eq=contrast=1.05:saturation=0.9:gamma=0.97,colorbalance=rh=0.03:bh=-0.03:rs=-0.01:bs=0.02,vignette=angle=PI/4.2',
                        '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], stdout=subprocess.PIPE)
mcap = cv2.VideoCapture(MASK)
enc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-', '-c:v', 'libx264', '-crf', '15', '-pix_fmt', 'yuv420p', sys.argv[1]], stdin=subprocess.PIPE)

for f in range(N):
    t = T0 + f / FPS
    fr = np.frombuffer(dec.stdout.read(W * H * 3), np.uint8).reshape(H, W, 3).astype(np.float32)
    mcap.set(cv2.CAP_PROP_POS_FRAMES, round(t * FPS)); _, m = mcap.read()
    pm = cv2.GaussianBlur(cv2.resize(m[:, :, 0].astype(np.float32) / 255, (W, H), interpolation=cv2.INTER_LINEAR), (0, 0), 1.6)[..., None]
    person = fr.copy()
    bg = fr[:ROI].copy()

    # появление: снизу вверх + проявление
    k = smooth(APPEAR, APPEAR + .22, t)
    sh = int((1 - k) * 40)
    Ak = np.roll(A, sh, 0) * k
    d = t - B                                          # >0 — уже горит
    burning = (d > 0) & (Ak > .05)

    # подсветка стены и дым
    src = Ak * (smooth(-.02, .04, d) * (1 - smooth(.14, .40, d)))
    off = int(V * (t - T0))
    sl = slice(TALL - ROI - off, TALL - off)
    # симуляция огня в половинном разрешении: подъём + раскачка + рваное остывание
    sh2 = cv2.resize(src, (W // 2, ROI // 2), interpolation=cv2.INTER_AREA)
    for sub in range(2):
        g = f * 2 + sub
        cs = (g * 9) % (CN.shape[0] - ROI // 2); ts = (g * 4) % (TX.shape[0] - ROI // 2)
        cn = CN[cs:cs + ROI // 2]; tx = TX[ts:ts + ROI // 2]
        t2 = TX[(ts + 333) % (TX.shape[0] - ROI // 2):][:ROI // 2]
        sway = 2.4 * np.sin(g * 0.19 + YS * 0.025 + XS * 0.006) + 1.6 * np.sin(g * 0.43 + XS * 0.03)
        FB[:] = cv2.remap(FB, XS + (tx - .5) * 11 + sway, YS + 4.0 + 5.0 * t2, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        FB *= 1 - (0.045 + 0.30 * cn ** 2)          # быстрее остывает — языки короче
        gust = 1 + 0.5 * np.maximum(0, np.sin(g * 0.31 + XS * 0.013 + 2 * np.sin(g * 0.07)))
        fl_src = sh2 * (0.4 + 0.95 * CN[(cs + 77) % (CN.shape[0] - ROI // 2):][:ROI // 2]) * gust
        np.maximum(FB, fl_src, out=FB)
    flame = np.clip(cv2.resize(FB, (W, ROI), interpolation=cv2.INTER_CUBIC) * 1.15, 0, 1) * (0.9 + 0.1 * np.sin(t * 23))
    glow = cv2.GaussianBlur(flame, (0, 0), 90) * 2.2
    bg = 255 - (255 - bg) * (1 - np.clip(glow, 0, .6)[..., None] * np.array([1.0, .55, .25]))   # тёплый свет на стене
    smoke_src = Ak * smooth(.15, .5, d) * (1 - smooth(.9, 1.6, d))
    smoke = cv2.GaussianBlur(cv2.sepFilter2D(smoke_src, -1, np.ones(1, np.float32), kern_up), (0, 0), 14)
    smoke = np.clip(smoke * 3.2 * (0.4 + NF2[sl]), 0, .24)[..., None]
    bg = bg * (1 - smoke) + 70 * smoke

    # состояние букв
    alive = 1 - smooth(.55, 1.15, d + (FLAKE - .5) * .5)                      # пепел осыпается хлопьями
    col = np.broadcast_to(CREAM, (ROI, W, 3)).copy()
    col = col + (SCORCH - CREAM) * (smooth(-.16, 0, d) * .75)[..., None]
    col = col + (CHAR - col) * smooth(0, .12, d)[..., None]
    col = col + (ASH - col) * smooth(.35, .7, d)[..., None]
    edge = np.exp(-((d - .03) / .045) ** 2) * (d > -.02)
    flick = np.clip(0.2 + 1.1 * NF2[sl] * (0.6 + 0.4 * PH), 0, 1)
    spk = smooth(.60, .76, SPB) * (0.5 + 0.5 * SPF) * smooth(.04, .12, d) * (1 - smooth(.32, .6, d)) * flick
    col = col + (EMBER - col) * np.clip(edge * 1.2 + spk, 0, 1)[..., None]
    ta = (Ak * alive)[..., None]

    # тень
    shadow = cv2.GaussianBlur(np.roll(Ak * alive, 10, 0), (0, 0), 12)[..., None] * .5
    bg = bg * (1 - shadow)
    bg = bg * (1 - ta) + col * ta
    # пламя и искры — экраном
    fl = lut_fire(np.clip(flame, 0, 1)) + (edge * Ak)[..., None] * np.array([255, 150, 45]) * .65
    if burning.any():
        ys, xs = np.nonzero(burning & (np.abs(d - .05) < .06))
        for i in rng.choice(len(ys), min(len(ys), 3), replace=False) if len(ys) else []:
            sparks.append([xs[i], ys[i], rng.normal(0, 70), -rng.uniform(250, 650), rng.uniform(.35, .9), 0.0])
    sp = np.zeros((ROI, W, 3), np.float32)
    for s in sparks:
        x0, y0 = s[0], s[1]
        s[2] += rng.normal(0, 40); s[0] += s[2] / FPS; s[1] += s[3] / FPS; s[3] *= .97; s[5] += 1 / FPS
        a = max(0, 1 - s[5] / s[4])
        if 0 <= s[1] < ROI:
            cv2.line(sp, (int(x0), int(y0)), (int(s[0]), int(s[1])), (255 * a, 190 * a, 90 * a), 2, cv2.LINE_AA)
    sparks[:] = [s for s in sparks if s[5] < s[4]]
    sp = sp + cv2.GaussianBlur(sp, (0, 0), 4) * 1.5
    add = np.clip(fl + sp, 0, 255)
    bg = 255 - (255 - bg) * (1 - add / 255)

    out = fr.copy(); out[:ROI] = bg
    out = out * (1 - pm) + person * pm
    enc.stdin.write(np.clip(out, 0, 255).astype(np.uint8).tobytes())
    if f % 20 == 0: print('кадр', f, flush=True)
enc.stdin.close(); enc.wait(); print('готово')
