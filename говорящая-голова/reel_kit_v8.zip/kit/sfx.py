"""Свой пак звуков по категориям из референсов 2, 7, 8. Пишет sfx/*.wav (48 кГц, моно).
Пики нормированы на -3 дБ, финальную громкость задаём в монтаже."""
import os
import wave
import numpy as np
from scipy.signal import butter, sosfilt

SR = 48000
rng = np.random.default_rng(11)
os.makedirs('sfx', exist_ok=True)


def t(d):
    return np.arange(int(d * SR)) / SR


def bp_sweep(x, f0, f1, q=1.2, steps=48):
    """полосовой фильтр с плавающей частотой — основа вжухов"""
    n = len(x)
    out = np.zeros(n)
    edges = np.linspace(0, n, steps + 1).astype(int)
    for i in range(steps):
        fc = f0 * (f1 / f0) ** (i / (steps - 1))
        lo, hi = fc / (1 + 1 / q), min(fc * (1 + 1 / q), SR / 2 - 100)
        sos = butter(2, [lo, hi], 'band', fs=SR, output='sos')
        a, b = max(0, edges[i] - 2000), edges[i + 1]
        seg = sosfilt(sos, x[a:b])
        out[edges[i]:b] = seg[edges[i] - a:]
    return out


def env(n, attack, release, curve=2.0):
    e = np.ones(n)
    a = int(attack * SR)
    r = int(release * SR)
    if a:
        e[:a] = np.linspace(0, 1, a) ** curve
    if r:
        e[-r:] *= np.linspace(1, 0, r) ** curve
    return e


def save(name, x):
    x = x / (np.max(np.abs(x)) + 1e-9) * 0.7
    with wave.open(f'sfx/{name}.wav', 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((x * 32767).astype(np.int16).tobytes())


# Whoosh — пролёт/наезд: шум, частота растёт, пик в середине
n = len(t(0.42))
x = bp_sweep(rng.standard_normal(n), 350, 2600, 1.4) * env(n, 0.22, 0.2, 1.6)
save('whoosh', x)

# Swoosh — уход элемента: короче, сверху вниз
n = len(t(0.3))
x = bp_sweep(rng.standard_normal(n), 3200, 900, 1.6) * env(n, 0.05, 0.24, 1.8)
save('swoosh', x)

# Transition — склейка: вжух + мягкий удар в конце
n = len(t(0.55))
w = bp_sweep(rng.standard_normal(n), 300, 3400, 1.2) * env(n, 0.38, 0.12, 2.2)
tt = t(0.55)
hit = np.zeros(n)
k = int(0.4 * SR)
th = tt[: n - k]
hit[k:] = np.sin(2 * np.pi * (90 * th - 30 * th ** 2)) * np.exp(-th * 14)
save('transition', w * 0.8 + hit * 0.9)

# Impact — акцент: низ + короткий щелчок, без хвоста
tt = t(0.7)
f = 48 + 70 * np.exp(-tt * 25)
x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt * 7)
x += sosfilt(butter(2, 2500, 'high', fs=SR, output='sos'), rng.standard_normal(len(tt))) * np.exp(-tt * 90) * 0.35
save('impact', x)

# Low Boom — драматичный момент: глубокий, длинный
tt = t(1.8)
f = 38 + 30 * np.exp(-tt * 6)
x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt * 2.2)
x += 0.25 * np.sin(2 * np.pi * np.cumsum(f * 2) / SR) * np.exp(-tt * 3.5)
save('low_boom', x)

# Reverse Bell — начало ролика: колокол, развёрнутый назад, нарастает
tt = t(1.4)
partials = [(1, 1.0), (2.76, .5), (5.4, .3), (8.93, .16)]
bell = sum(a * np.sin(2 * np.pi * 523 * r * tt) * np.exp(-tt * (2.5 + r)) for r, a in partials)
x = bell[::-1] * env(len(tt), 0.0, 0.03, 1)
save('reverse_bell', x)

# Riser — напряжение перед раскрытием
tt = t(1.3)
f = 180 * (1 + 4 * (tt / tt[-1]) ** 2)
saw = 2 * ((np.cumsum(f) / SR) % 1) - 1
noise = bp_sweep(rng.standard_normal(len(tt)), 500, 6000, 1.0)
x = (sosfilt(butter(2, 3500, 'low', fs=SR, output='sos'), saw) * 0.5 + noise * 0.6) * (tt / tt[-1]) ** 2.2
x *= env(len(tt), 0, 0.02, 1)
save('riser', x)

# Camera Shutter — стоп-кадр, скриншот
tt = t(0.22)
x = np.zeros(len(tt))
for st, g in [(0.0, 1.0), (0.075, 0.7)]:
    k = int(st * SR)
    m = int(0.03 * SR)
    burst = rng.standard_normal(m) * np.exp(-np.arange(m) / SR * 220)
    x[k:k + m] += sosfilt(butter(2, [1800, 7000], 'band', fs=SR, output='sos'), burst) * g
save('shutter', x)

# Glitch — резкая смена темы
tt = t(0.32)
x = np.zeros(len(tt))
pos = 0
while pos < len(tt):
    m = int(rng.uniform(0.012, 0.045) * SR)
    kind = rng.integers(0, 3)
    seg_t = np.arange(m) / SR
    if kind == 0:
        seg = np.sign(np.sin(2 * np.pi * rng.uniform(200, 1400) * seg_t))
    elif kind == 1:
        seg = rng.standard_normal(m)
    else:
        seg = np.zeros(m)
    x[pos:pos + m] = seg[: len(x) - pos] * rng.uniform(0.4, 1)
    pos += m
x = np.round(x * 6) / 6
save('glitch', x * env(len(tt), 0.005, 0.05, 1))

# Sweep — плавная смена раскладки
n = len(t(0.7))
up = bp_sweep(rng.standard_normal(n), 600, 5000, 2.2) * np.sin(np.linspace(0, np.pi, n)) ** 1.5
save('sweep', up)

# Pop — появление плашки
tt = t(0.14)
f = 900 * np.exp(-tt * 18) + 380
x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt * 38)
save('pop', x)

# Air — мягкое появление прописи вместо громкого «спаркла»
tt = t(0.9)
air = sosfilt(butter(2, [3000, 9000], 'band', fs=SR, output='sos'), rng.standard_normal(len(tt)))
chime = sum(a * np.sin(2 * np.pi * f * tt) for f, a in [(1318, .5), (1976, .35), (2637, .2)]) * np.exp(-tt * 5)
x = air * np.sin(np.linspace(0, np.pi, len(tt))) ** 2 * 0.5 + chime * env(len(tt), 0.08, 0.3, 1.5) * 0.35
save('air', x)

# Tick — переключение карточки
tt = t(0.05)
x = sosfilt(butter(2, [2500, 8000], 'band', fs=SR, output='sos'), rng.standard_normal(len(tt))) * np.exp(-tt * 160)
save('tick', x)


# Key — клавиша (клавиатурный «клик» с глухим низом)
tt = t(0.09)
x = sosfilt(butter(2, [1500, 6000], 'band', fs=SR, output='sos'), rng.standard_normal(len(tt))) * np.exp(-tt * 120) * 0.7
x += np.sin(2 * np.pi * 180 * tt) * np.exp(-tt * 60)
save('key', x)

# Thock — мягкий удар-появление карточки
tt = t(0.3)
f = 140 * np.exp(-tt * 9) + 70
x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt * 16)
save('thock', x)

# Bars — шуршащий вайп полосами (несколько коротких свишей подряд)
n = len(t(0.5))
x = np.zeros(n)
for k in range(5):
    m = int(0.09 * SR)
    st = int(k * 0.08 * SR)
    seg = bp_sweep(rng.standard_normal(m), 900 + k * 300, 4000, 2.0) * np.sin(np.linspace(0, np.pi, m))
    x[st:st + m] += seg[: n - st]
save('bars', x)

# Iris — мягкое «раскрытие» (тональный подъём с воздухом)
tt = t(0.6)
f = 300 + 900 * (tt / tt[-1]) ** 1.5
x = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.35 * np.sin(np.linspace(0, np.pi, len(tt)))
x += sosfilt(butter(2, [2000, 8000], 'band', fs=SR, output='sos'), rng.standard_normal(len(tt))) * 0.25 * np.sin(np.linspace(0, np.pi, len(tt)))
save('iris', x)

# Tap — «серьёзное» появление инфографики: глухой короткий удар без писка
tt = t(0.14)
x = sosfilt(butter(2, [250, 2200], 'band', fs=SR, output='sos'), rng.standard_normal(len(tt))) * np.exp(-tt * 110) * 0.8
x += np.sin(2 * np.pi * 150 * tt) * np.exp(-tt * 45) * 0.7
save('tap', x)

# Tock — мягкий щелчок счётчика/галочки (вместо высокого «тика»)
tt = t(0.08)
x = sosfilt(butter(2, [500, 2500], 'band', fs=SR, output='sos'), rng.standard_normal(len(tt))) * np.exp(-tt * 170) * 0.6
x += np.sin(2 * np.pi * 260 * tt) * np.exp(-tt * 70) * 0.5
save('tock', x)

print(sorted(os.listdir('sfx')))
