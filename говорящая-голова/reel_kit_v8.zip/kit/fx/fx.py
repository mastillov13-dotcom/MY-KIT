"""Тесты эффектов хука на том же куске, что и огонь v4: «100 ПРОМПТОВ» за головой, Alumni Sans Black,
общий цветокор без маски, маска человека только для текста за головой.
python3 fx.py <dust|assemble|impact|glass|neon|strike|marker|smoke> out.mp4
"""
import subprocess, sys, wave
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage, signal
from scipy.spatial import cKDTree

SRC, MASK = '/home/claude/reel5/proj/cut.mp4', '/home/claude/reel5/mask.mp4'
T0, DUR, FPS, W, H, SR = 0.40, 3.2, 30, 1080, 1920, 48000
N = int(DUR * FPS)
APPEAR, HIT = 0.86, 1.50
rng = np.random.default_rng(7)
CREAM = np.array([238, 232, 222], np.float32)
CORAL = np.array([255, 92, 58], np.float32)
LAT, CYR = 'alat.woff', 'acyr.woff'


def smooth(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)


def fbm(h, w, scales, amps, seed, stretch=1.0):
    r = np.random.default_rng(seed); s = np.zeros((h, w), np.float32)
    for sc, am in zip(scales, amps):
        g = r.random((max(2, int(h // (sc * stretch))), max(2, w // sc))).astype(np.float32)
        s += am * cv2.resize(g, (w, h), interpolation=cv2.INTER_CUBIC)
    s -= s.min(); return s / s.max()


def glyph(txt, font):
    F = ImageFont.truetype(font, 400); l, t, r, b = F.getbbox(txt)
    im = Image.new('L', (r - l, b - t), 0); ImageDraw.Draw(im).text((-l, -t), txt, font=F, fill=255)
    return np.array(im, np.float32) / 255


def place(a, tw, th, top, cx):
    a = cv2.resize(a, (tw, th), interpolation=cv2.INTER_AREA)
    out = np.zeros((H, W), np.float32); x0 = int(cx - tw / 2)
    out[top:top + th, x0:x0 + tw] = a; return out


G100 = glyph('100', LAT)
SQ = 540 / (G100.shape[1] * 430 / G100.shape[0])          # то же сжатие по ширине, что у «100»


def nat(txt, font, th, top, cx):
    g = glyph(txt, font); return place(g, int(g.shape[1] * th / g.shape[0] * SQ), th, top, cx)


A1 = place(G100, 540, 430, 92, 548)
A2 = place(glyph('ПРОМПТОВ', CYR), 840, 215, 540, 540)
A = np.maximum(A1, A2)
YY, XX = np.mgrid[0:H, 0:W].astype(np.float32)


def vshift(a, off):
    off = int(round(off))
    if off == 0: return a
    out = np.zeros_like(a); n = a.shape[0]
    if abs(off) >= n: return out
    if off > 0: out[off:] = a[:n - off]
    else: out[:n + off] = a[-off:]
    return out


def over(bg, col, a):
    a = a[..., None]; return bg * (1 - a) + col * a


def screen(bg, add):
    return 255 - (255 - bg) * (1 - np.clip(add, 0, 255) / 255)


def shadow(bg, a, k=.5):
    sh = cv2.GaussianBlur(vshift(a, 10), (0, 0), 12) * k; return bg * (1 - sh[..., None])


def entry(t):
    k = smooth(APPEAR, APPEAR + .22, t); return k, int((1 - k) * 40)


def text_on(bg, a, col=CREAM, k=.5):
    return over(shadow(bg, a, k), col, a)


def splat(px, py, al, tone, blur=.8):
    """частицы → слой (альфа, яркость)"""
    ix, iy = px.astype(int), py.astype(int); ok = (ix >= 0) & (ix < W) & (iy >= 0) & (iy < H)
    cnt = np.zeros((H, W), np.float32); acc = np.zeros((H, W), np.float32)
    np.add.at(cnt, (iy[ok], ix[ok]), al[ok]); np.add.at(acc, (iy[ok], ix[ok]), (al * tone)[ok])
    cnt = cv2.GaussianBlur(cnt, (0, 0), blur); acc = cv2.GaussianBlur(acc, (0, 0), blur)
    return cnt, acc / (cnt + 1e-6)


# ---------- звук ----------
def noise(n): return rng.normal(0, 1, n)
def bp(x, lo, hi): b, a = signal.butter(2, [lo / (SR / 2), hi / (SR / 2)], 'band'); return signal.lfilter(b, a, x)
def lp(x, f): b, a = signal.butter(2, f / (SR / 2)); return signal.lfilter(b, a, x)
def hp(x, f): b, a = signal.butter(2, f / (SR / 2), 'high'); return signal.lfilter(b, a, x)
def tt(d): return np.arange(int(d * SR)) / SR


def put(buf, t_abs, x, g=1.0):
    i = int((t_abs - T0) * SR); x = np.asarray(x) * g
    if i < 0: x = x[-i:]; i = 0
    n = min(len(x), len(buf) - i)
    if n > 0: buf[i:i + n] += x[:n]


def thock():
    t = tt(.12); return np.sin(2 * np.pi * 95 * t) * np.exp(-t / .04) * .8 + noise(len(t)) * np.exp(-t / .006) * .25


def swell(d, lo, hi, up=True):
    t = tt(d); e = (t / d) ** 2 if up else np.sin(np.pi * t / d) ** 2
    return bp(noise(len(t)), lo, hi) * e


# ---------- эффекты ----------
class Base:
    def shake(self, t): return 0, 0


class Dust(Base):
    """слово рассыпается в пыль слева направо, пыль сдувает вправо-вверх"""
    def __init__(s):
        ys, xs = np.nonzero(A > .5); x0, x1 = xs.min(), xs.max()
        jag = fbm(H, W, (20, 50), (1, .5), 21)
        s.RT = HIT + (XX - x0) / (x1 - x0) * .9 + (jag - .5) * .35 + (YY > 530) * .08
        sel = (ys % 2 == 0) & (xs % 2 == 0)
        s.py, s.px = ys[sel].astype(np.float32), xs[sel].astype(np.float32); n = len(s.px)
        s.rt = s.RT[ys[sel], xs[sel]]
        s.vx = rng.uniform(120, 420, n); s.vy = rng.uniform(-260, -30, n); s.life = rng.uniform(.8, 1.7, n)
        s.ph = rng.uniform(0, 6.28, n); s.tone = rng.uniform(.72, 1.04, n)

    def frame(s, f, t, bg):
        k, sh = entry(t)
        bg = text_on(bg, vshift(A, sh) * k * smooth(0, .05, s.RT - t))
        age = t - s.rt; m = (age > 0) & (age < s.life)
        if m.any():
            ag = age[m]
            x = s.px[m] + s.vx[m] * ag + 40 * ag * ag + 35 * np.sin(ag * 3 + s.ph[m]) * ag
            y = s.py[m] + s.vy[m] * ag - 25 * ag * ag
            cnt, tone = splat(x, y, (1 - ag / s.life[m]) ** 1.3, s.tone[m])
            bg = over(bg, CREAM * tone[..., None], np.clip(cnt * 1.6, 0, 1))
        return bg

    def sound(s):
        b = np.zeros(int(DUR * SR)); put(b, APPEAR, thock())
        t = tt(1.5); e = smooth(0, .12, t) * (1 - smooth(.9, 1.5, t))
        put(b, HIT, hp(noise(len(t)), 2500) * e * .5 + bp(noise(len(t)), 200, 1200) * e * .7)
        return b


class Assemble(Base):
    """пыль слетается слева и собирается в слово"""
    def __init__(s):
        ys, xs = np.nonzero(A > .5); x0, x1 = xs.min(), xs.max()
        jag = fbm(H, W, (20, 50), (1, .5), 22)
        s.AT = .80 + (XX - x0) / (x1 - x0) * .55 + (jag - .5) * .2 + (YY > 530) * .1
        sel = (ys % 2 == 0) & (xs % 2 == 0)
        s.py, s.px = ys[sel].astype(np.float32), xs[sel].astype(np.float32); n = len(s.px)
        s.at = s.AT[ys[sel], xs[sel]]; s.D = rng.uniform(.45, .85, n)
        s.sx = s.px - rng.uniform(250, 750, n); s.sy = s.py + rng.uniform(-350, 250, n)
        s.ph = rng.uniform(0, 6.28, n); s.tone = rng.uniform(.75, 1.05, n)

    def frame(s, f, t, bg):
        bg = text_on(bg, A * smooth(0, .06, t - s.AT))
        g = A * np.exp(-np.maximum(t - s.AT, 0) / .09) * (t > s.AT)
        bg = screen(bg, cv2.GaussianBlur(g, (0, 0), 6)[..., None] * np.array([200, 180, 150]))
        u = (t - (s.at - s.D)) / s.D; m = (u > 0) & (u < 1)
        if m.any():
            e = 1 - (1 - u[m]) ** 3
            x = s.sx[m] + (s.px[m] - s.sx[m]) * e; y = s.sy[m] + (s.py[m] - s.sy[m]) * e + 40 * np.sin(np.pi * u[m]) * np.sin(s.ph[m])
            cnt, tone = splat(x, y, smooth(0, .25, u[m]), s.tone[m])
            bg = over(bg, CREAM * tone[..., None], np.clip(cnt * 1.6, 0, 1))
        return bg

    def sound(s):
        b = np.zeros(int(DUR * SR))
        put(b, .35, swell(1.0, 400, 4000)); put(b, 1.36, thock(), 1.2)
        return b


class Impact(Base):
    """слово падает сверху, врезается в стену: трещины, пыль, обломки, тряска"""
    F0, IMP = .66, .92

    def __init__(s):
        s.segs = []                                          # (время, x0, y0, x1, y1, толщина)
        seeds = [(300, 525), (800, 525), (150, 760), (935, 760), (548, 92), (260, 300), (835, 300), (560, 760)]
        def crack(x, y, ang, L, w, t0):
            d = 0
            while d < L:
                st = rng.uniform(8, 15); ang += rng.normal(0, .32)
                nx, ny = x + np.cos(ang) * st, y + np.sin(ang) * st; d += st
                s.segs.append((t0 + d / 1700, x, y, nx, ny, max(1, w * (1 - d / L) + .6)))
                if rng.random() < .07 and L - d > 60: crack(nx, ny, ang + rng.choice([-1, 1]) * rng.uniform(.5, 1.1), (L - d) * .6, w * .7, t0 + d / 1700)
                x, y = nx, ny
        for sx, sy in seeds:
            for _ in range(rng.integers(2, 4)):
                a0 = np.arctan2(sy - 420, sx - 540) + rng.normal(0, .7)
                crack(sx, sy, a0, rng.uniform(150, 420), 3.2, s.IMP)
        e = (A > .5).astype(np.uint8); edge = e - cv2.erode(e, np.ones((3, 3), np.uint8))
        ys, xs = np.nonzero(edge); bot = ys > np.percentile(ys, 30)
        i = rng.choice(np.nonzero(bot)[0], 2500); s.dx0, s.dy0 = xs[i].astype(float), ys[i].astype(float)
        s.dvx = rng.uniform(-1, 1, 2500) * rng.uniform(100, 500, 2500); s.dvy = -rng.uniform(30, 260, 2500); s.dl = rng.uniform(.6, 1.3, 2500)
        j = rng.choice(len(xs), 60); s.cx0, s.cy0 = xs[j].astype(float), ys[j].astype(float)
        s.cvx = rng.uniform(-300, 300, 60); s.cvy = -rng.uniform(100, 500, 60); s.cr = rng.integers(2, 5, 60)
        s.sh = {}

    def shake(s, t):
        if t < s.IMP: return 0, 0
        a = 18 * np.exp(-(t - s.IMP) / .10); r = np.random.default_rng(int(t * 1000))
        return r.normal(0, a), r.normal(0, a)

    def frame(s, f, t, bg):
        if t >= s.IMP:                                       # трещины на стене
            dark = np.zeros((H, W), np.float32); lite = np.zeros((H, W), np.float32)
            for ts, x0, y0, x1, y1, w in s.segs:
                if ts <= t:
                    cv2.line(dark, (int(x0), int(y0)), (int(x1), int(y1)), 1.0, int(round(w)), cv2.LINE_AA)
                    cv2.line(lite, (int(x0) + 1, int(y0) + 2), (int(x1) + 1, int(y1) + 2), 1.0, 1, cv2.LINE_AA)
            bg = over(bg, np.array([205, 185, 165], np.float32), lite * .35)
            bg = over(bg, np.array([30, 22, 18], np.float32), dark * .85)
        if t < s.F0: return bg
        u = min((t - s.F0) / (s.IMP - s.F0), 1.0)
        off = -1100 * (1 - u * u) if t < s.IMP else 16 * np.exp(-(t - s.IMP) / .07) * np.cos((t - s.IMP) * 55)
        a = vshift(A, off)
        if t < s.IMP: a = cv2.blur(a, (1, 1 + int(60 * u)))
        k = .5 + .3 * np.exp(-max(t - s.IMP, 0) / .15) * (t >= s.IMP)
        bg = text_on(bg, a, k=k)
        if t >= s.IMP:
            ag = t - s.IMP
            m = ag < s.dl
            if m.any():
                dr = np.exp(-1.5 * ag)
                x = s.dx0[m] + s.dvx[m] * ag * dr; y = s.dy0[m] + s.dvy[m] * ag * dr + 125 * ag * ag
                cnt, _ = splat(x, y, (1 - ag / s.dl[m]) * .5, np.ones(m.sum()), blur=3.5)
                bg = over(bg, np.array([185, 168, 150], np.float32), np.clip(cnt * 2.2, 0, .8))
            chips = np.zeros((H, W), np.float32)
            for i in range(60):
                x = s.cx0[i] + s.cvx[i] * ag; y = s.cy0[i] + s.cvy[i] * ag + 1000 * ag * ag
                if 0 <= x < W and 0 <= y < H: cv2.circle(chips, (int(x), int(y)), int(s.cr[i]), 1.0, -1, cv2.LINE_AA)
            bg = over(bg, np.array([70, 58, 48], np.float32), chips * .9)
        return bg

    def sound(s):
        b = np.zeros(int(DUR * SR))
        put(b, s.F0, swell(s.IMP - s.F0, 300, 3500), .8)
        t = tt(1.2); boom = np.sin(2 * np.pi * 52 * t * (1 - .15 * t)) * np.exp(-t / .35) + lp(noise(len(t)), 300) * np.exp(-t / .12) * 2
        put(b, s.IMP, boom, 1.4)
        for _ in range(40):
            c = noise(int(SR * rng.uniform(.002, .007))); put(b, s.IMP + rng.uniform(0, .25), np.diff(np.r_[0, c]), rng.uniform(.4, 1))
        for _ in range(25):
            put(b, s.IMP + rng.uniform(.2, .9), bp(noise(400), 1500, 5000) * np.exp(-np.arange(400) / 80), rng.uniform(.15, .4))
        return b


class Glass(Base):
    """надпись трескается и разлетается осколками с бликами"""
    CR, SH, C = 1.50, 1.70, np.array([548., 300.])

    def __init__(s):
        ys, xs = np.nonzero(A > .3); P = np.c_[xs, ys].astype(float)
        r = np.abs(rng.normal(0, 1, 75)) * 260; an = rng.uniform(0, 6.28, 75)
        S1 = s.C + np.c_[np.cos(an) * r, np.sin(an) * r * 1.3]
        S2 = np.c_[rng.uniform(130, 950, 30), rng.uniform(545, 750, 30)]
        S = np.r_[S1, S2]; _, lab = cKDTree(S).query(P)
        L = -np.ones((H, W), int); L[ys, xs] = lab
        cb = np.zeros((H, W), bool)
        cb[:, 1:] |= (L[:, 1:] != L[:, :-1]) & (L[:, 1:] >= 0) & (L[:, :-1] >= 0)
        cb[1:, :] |= (L[1:, :] != L[:-1, :]) & (L[1:, :] >= 0) & (L[:-1, :] >= 0)
        s.CB = cv2.dilate(cb.astype(np.float32), np.ones((2, 2), np.uint8))
        s.CT = s.CR + np.hypot(XX - s.C[0], YY - s.C[1]) / 2200
        s.shards = []
        for k in np.unique(lab):
            m = (L == k); yy, xx = np.nonzero(m)
            y0, y1, x0, x1 = yy.min(), yy.max() + 1, xx.min(), xx.max() + 1
            ca = (A * m)[y0:y1, x0:x1].astype(np.float32)
            e = (ca > .5).astype(np.uint8); edge = (e - cv2.erode(e, np.ones((3, 3), np.uint8))).astype(np.float32)
            c0 = np.array([(x0 + x1) / 2, (y0 + y1) / 2]); d = c0 - s.C; dist = np.hypot(*d) + 1
            s.shards.append(dict(ca=np.dstack([ca, edge]), o=(x0, y0), c0=c0,
                                 v=d / dist * rng.uniform(250, 800) + np.array([0, -rng.uniform(100, 300)]),
                                 w=rng.uniform(-7, 7), z=rng.uniform(0, .5), dl=dist / 3000, sh=rng.uniform(.85, 1.05), ph=rng.uniform(0, 6)))

    def frame(s, f, t, bg):
        k, sh = entry(t)
        if t < s.SH:
            bg = text_on(bg, vshift(A, sh) * k)
            if t >= s.CR:
                c = s.CB * (s.CT <= t)
                bg = over(bg, np.array([255, 255, 255], np.float32), vshift(c, 2) * .5)
                bg = over(bg, np.array([45, 42, 48], np.float32), c * .85)
                fl = np.exp(-(t - s.CR) / .06)
                g = np.exp(-((XX - s.C[0]) ** 2 + (YY - s.C[1]) ** 2) / (2 * 60 ** 2)) * fl
                bg = screen(bg, g[..., None] * 255)
            return bg
        bg = shadow(bg, A, k=.5 * (1 - smooth(s.SH, s.SH + .15, t)))
        g = np.exp(-((XX - s.C[0]) ** 2 + (YY - s.C[1]) ** 2) / (2 * 140 ** 2)) * np.exp(-(t - s.SH) / .08)
        bg = screen(bg, g[..., None] * 255)
        for sd in s.shards:
            ag = max(0.0, t - s.SH - sd['dl'])
            fade = 1 - smooth(.35, .75, ag)
            if fade <= 0: continue
            ca = sd['ca']; h, w = ca.shape[:2]; sc = 1 + sd['z'] * ag; th = sd['w'] * ag
            cn = sd['c0'] + sd['v'] * ag + np.array([0, 1200 * ag * ag])
            D = int(np.hypot(w, h) * sc) + 4
            M = cv2.getRotationMatrix2D((w / 2, h / 2), np.degrees(th), sc); M[:, 2] += (D / 2 - w / 2, D / 2 - h / 2)
            wa = cv2.warpAffine(ca, M, (D, D), flags=cv2.INTER_LINEAR)
            X0, Y0 = int(cn[0] - D / 2), int(cn[1] - D / 2)
            ax0, ay0, ax1, ay1 = max(X0, 0), max(Y0, 0), min(X0 + D, W), min(Y0 + D, H)
            if ax1 <= ax0 or ay1 <= ay0: continue
            wa = wa[ay0 - Y0:ay1 - Y0, ax0 - X0:ax1 - X0]
            al = wa[..., 0] * fade; gl = wa[..., 1] * (.5 + .5 * np.sin(th * 3 + sd['ph']))
            col = CREAM * sd['sh'] + gl[..., None] * 200
            R = bg[ay0:ay1, ax0:ax1]; bg[ay0:ay1, ax0:ax1] = R * (1 - al[..., None]) + np.clip(col, 0, 255) * al[..., None]
        return bg

    def sound(s):
        b = np.zeros(int(DUR * SR)); put(b, APPEAR, thock())
        t = tt(.05); put(b, s.CR, hp(noise(len(t)), 3000) * np.exp(-t / .008) * 1.2)
        t = tt(.8); put(b, s.SH, bp(noise(len(t)), 2000, 9000) * np.exp(-t / .18) * 1.3)
        for _ in range(45):
            d = rng.uniform(.06, .15); t = tt(d)
            put(b, s.SH + rng.uniform(0, .9), np.sin(2 * np.pi * rng.uniform(2500, 7000) * t) * np.exp(-t / (d / 4)), rng.uniform(.1, .35))
        return b


class Neon(Base):
    """неоновая вывеска: трубка по контуру букв, загорается с мерцанием, светит на стену"""
    def __init__(s):
        dt = ndimage.distance_transform_edt(A > .5)
        s.tube = (np.exp(-((dt - 11) / 3.2) ** 2) * (A > .3)).astype(np.float32)
        s.R1 = (A1 > .3).astype(np.float32); s.R2 = (A2 > .3).astype(np.float32)
        s.R3 = s.R2 * (XX > 830)

    @staticmethod
    def seq(t, ev):
        t = np.asarray(t, float); o = np.zeros_like(t)
        for a, b in ev: o = np.maximum(o, (t >= a) & (t < b))
        return o

    def L(s, t):
        hum = .94 + .06 * np.sin(2 * np.pi * 13 * np.asarray(t, float))
        l1 = s.seq(t, [(.90, .94), (1.00, 1.05), (1.12, 9)]) * hum
        l2 = s.seq(t, [(1.30, 1.33), (1.38, 1.41), (1.47, 9)]) * hum
        l3 = l2 * (1 - s.seq(t, [(1.95, 2.02), (2.08, 2.11), (2.30, 2.33)]))
        return l1, l2, l3

    def frame(s, f, t, bg):
        k, sh = entry(t)
        bg = over(bg, np.array([72, 64, 62], np.float32), s.tube * .55 * k)
        l1, l2, l3 = s.L(t)
        core = s.tube * (l1 * s.R1 + l2 * (s.R2 - s.R3) + l3 * s.R3)
        add = core[..., None] * np.array([255, 238, 228]) + cv2.GaussianBlur(core, (0, 0), 4)[..., None] * CORAL * 1.3 \
            + cv2.GaussianBlur(core, (0, 0), 14)[..., None] * CORAL * 1.0 + cv2.GaussianBlur(core, (0, 0), 45)[..., None] * CORAL * .7 \
            + cv2.GaussianBlur(core, (0, 0), 140)[..., None] * CORAL * .55
        return screen(bg, add)

    def sound(s):
        n = int(DUR * SR); t = T0 + np.arange(n) / SR
        l1, l2, l3 = s.L(t); lv = (l1 + l2 * .6 + l3 * .4) / 2
        tone = sum(np.sin(2 * np.pi * 100 * h * t) / h for h in range(1, 12))
        b = lp(tone, 2500) * lv * .25 + bp(noise(n), 3000, 8000) * lv * .03
        dl = np.diff(np.r_[0, (l1 > .5).astype(float) + (l2 > .5)])
        for i in np.nonzero(dl > 0)[0]:
            c = tt(.03); put(b, t[i], noise(len(c)) * np.exp(-c / .004) * .8 + np.sin(2 * np.pi * 70 * c) * np.exp(-c / .02) * .5)
        put(b, APPEAR, thock(), .7)
        return b


class Strike(Base):
    """«100» зачёркивается маркером и прокручивается в «3 ВЕЩИ»"""
    S0, S1, SW, SWD = 1.45, 1.72, 1.92, .22

    def __init__(s):
        s.TM = np.full((H, W), np.inf, np.float32)
        for i in range(220):
            p = i / 219; e = 1 - (1 - p) ** 2
            x = 280 + 545 * p; y = 400 - 185 * p - 20 * np.sin(p * np.pi) + rng.normal(0, 1.5)
            r = 21 * (.8 + .3 * np.sin(p * np.pi)) + rng.normal(0, 1)
            m = np.zeros((H, W), np.uint8); cv2.circle(m, (int(x), int(y)), int(r), 1, -1, cv2.LINE_AA)
            s.TM = np.where(m > 0, np.minimum(s.TM, s.S0 + e * (s.S1 - s.S0)), s.TM)
        streak = fbm(H, W, (2, 5, 12), (1, .6, .3), 31, stretch=.25)
        s.tex = (.55 + .45 * smooth(.25, .6, streak)).astype(np.float32)
        g3, gv = glyph('3', LAT), glyph('ВЕЩИ', CYR)          # «3 ВЕЩИ» одной строкой над головой
        gv = cv2.resize(gv, (int(gv.shape[1] * g3.shape[0] / gv.shape[0]), g3.shape[0]))
        gc = np.concatenate([g3, np.zeros((g3.shape[0], int(g3.shape[0] * .12)), np.float32), gv], 1)
        th = 330; s.A3 = place(gc, min(940, int(gc.shape[1] * th / gc.shape[0] * SQ)), th, 150, 540); s.AV = np.zeros_like(A)
        s.B1 = smooth(80, 110, YY) * (1 - smooth(505, 535, YY)); s.B2 = smooth(525, 548, YY) * (1 - smooth(748, 770, YY))

    def frame(s, f, t, bg):
        k, sh = entry(t)
        stk = (s.TM <= t) * s.tex
        if t < s.SW:
            a = vshift(A, sh) * k; bg = text_on(bg, a); return over(bg, CORAL, stk * .95)
        u = min((t - s.SW) / s.SWD, 1.0); e = 1 - (1 - u) ** 3
        bump = 1 + .06 * np.sin(min((t - s.SW - s.SWD) / .12, 1) * np.pi) * (t > s.SW + s.SWD)
        bl = 1 + int(70 * np.sin(np.pi * u))
        r1 = vshift(A1, 440 * e) + vshift(s.A3, -440 * (1 - e) * bump); r2 = vshift(A2, -230 * e) + vshift(s.AV, 230 * (1 - e))
        a = np.clip(cv2.blur(r1, (1, bl)) * s.B1 + cv2.blur(r2, (1, bl)) * s.B2, 0, 1)
        bg = text_on(bg, a)
        return over(bg, CORAL, cv2.blur(vshift(stk, 440 * e), (1, bl)) * s.B1 * .95)

    def sound(s):
        b = np.zeros(int(DUR * SR)); put(b, APPEAR, thock())
        t = tt(s.S1 - s.S0 + .05); sq = bp(noise(len(t)), 1500, 4200) * (1 + .6 * np.sin(2 * np.pi * 31 * t)) * smooth(0, .03, t)
        put(b, s.S0, sq, .5)
        for i in range(9):
            c = tt(.012); put(b, s.SW + i * s.SWD / 9, bp(noise(len(c)), 2000, 6000) * np.exp(-c / .003), .8)
        put(b, s.SW + s.SWD, thock(), 1.2)
        return b


class Marker(Base):
    """слово пишется маркером по стене, буква за буквой по линии штриха"""
    def __init__(s):
        from skimage.morphology import skeletonize
        from skimage.graph import MCP_Geometric
        sk = skeletonize(A > .5)
        lab, n = ndimage.label(sk, structure=np.ones((3, 3)))
        comps = []
        for k in range(1, n + 1):
            yy, xx = np.nonzero(lab == k)
            if len(yy) < 15: continue
            comps.append((1 if yy.mean() < 531 else 2, xx.mean(), yy, xx))
        comps.sort(key=lambda c: (c[0], c[1]))
        TS = np.full((H, W), np.inf, np.float32)
        s.events = []
        for row, (t0, t1) in ((1, (.70, 1.18)), (2, (1.24, 1.95))):
            cs = [c for c in comps if c[0] == row]; tot = sum(len(c[2]) for c in cs); gap = .03
            span = t1 - t0 - gap * (len(cs) - 1); cur = t0
            for _, _, yy, xx in cs:
                d = span * len(yy) / tot
                y0, x0 = yy.min(), xx.min()
                cost = np.full((yy.max() - y0 + 1, xx.max() - x0 + 1), 1e6); cost[yy - y0, xx - x0] = 1
                st = np.argmin(xx + yy)
                cum, _ = MCP_Geometric(cost).find_costs([(yy[st] - y0, xx[st] - x0)])
                o = cum[yy - y0, xx - x0]; o = o / max(o.max(), 1)
                TS[yy, xx] = cur + o * d; s.events.append((cur, d)); cur += d + gap
        _, (iy, ix) = ndimage.distance_transform_edt(~np.isfinite(TS), return_indices=True)
        s.RT = np.where(A > .05, TS[iy, ix], np.inf).astype(np.float32)
        s.tex = (.9 + .1 * fbm(H, W, (2, 6), (1, .5), 41, stretch=.3))[..., None]

    def frame(s, f, t, bg):
        a = A * smooth(0, .035, t - s.RT)
        return text_on(bg, a, CREAM * s.tex)

    def sound(s):
        b = np.zeros(int(DUR * SR))
        for st, d in s.events:
            t = tt(d); e = smooth(0, .02, t) * (1 - smooth(d - .03, d, t))
            put(b, st, (bp(noise(len(t)), 1800, 4500) * (1 + .5 * np.sin(2 * np.pi * 23 * t)) * .6 + bp(noise(len(t)), 300, 900) * .3) * e)
        return b


class Smoke(Base):
    """слово проявляется из клубов дыма, дым уходит вверх и рассеивается"""
    def __init__(s):
        h2, w2 = H // 2, W // 2
        s.S = np.zeros((h2, w2), np.float32); s.YS, s.XS = np.mgrid[0:h2, 0:w2].astype(np.float32)
        s.CN = fbm(h2 + 2400, w2, (5, 11, 24, 50), (1, .6, .35, .2), 51, stretch=1.6)
        s.TX = fbm(h2 + 1200, w2, (14, 30, 70), (1, .5, .25), 52)
        src = cv2.dilate((cv2.resize(A, (w2, h2)) > .3).astype(np.float32), np.ones((25, 25), np.uint8))
        s.src = cv2.GaussianBlur(src, (0, 0), 10)
        s.DT = fbm(H, W, (3, 7, 16), (1, .6, .3), 54)
        s.RT = 1.0 + (fbm(H, W, (16, 40), (1, .5), 53) - .5) * .45

    def frame(s, f, t, bg):
        h2 = H // 2
        for sub in range(2):
            g = f * 2 + sub
            cs = (g * 5) % (s.CN.shape[0] - h2); ts = (g * 3) % (s.TX.shape[0] - h2)
            cn = s.CN[cs:cs + h2]; tx = s.TX[ts:ts + h2]
            sway = 3 * np.sin(g * .13 + s.YS * .02)
            s.S[:] = cv2.remap(s.S, s.XS + (tx - .5) * 26 + sway, s.YS + 3.4 + 2.0 * cn, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
            s.S *= 1 - (.010 + .05 * cn ** 2)
            inten = smooth(.68, .82, t) * (1 - smooth(1.2, 1.38, t))
            puff = smooth(.5, .75, cn)
            np.maximum(s.S, s.src * puff * inten * .9, out=s.S)
        s.S[:] = cv2.GaussianBlur(s.S, (0, 0), 1.4)
        bg = text_on(bg, A * smooth(0, .28, t - s.RT))
        Sf = cv2.resize(s.S, (W, H), interpolation=cv2.INTER_CUBIC)
        sl = int(f * 6) % (H // 2)
        det = np.roll(s.DT, -sl, 0)
        dens = np.clip(Sf * 1.0, 0, 1) ** 1.2 * (.45 + .55 * det)
        b6 = cv2.GaussianBlur(Sf, (0, 0), 6); shade = np.clip(.78 + 1.2 * (b6 - vshift(b6, -8)), .55, 1.15)
        return over(bg, np.array([168, 162, 158], np.float32) * shade[..., None], np.clip(dens * .9, 0, .72))

    def sound(s):
        b = np.zeros(int(DUR * SR))
        put(b, .62, swell(1.0, 200, 2000, up=False), .9); t = tt(1.6)
        put(b, .7, lp(noise(len(t)), 150) * np.sin(np.pi * t / 1.6) ** 2 * 2.0)
        return b


FX = dict(dust=Dust, assemble=Assemble, impact=Impact, glass=Glass, neon=Neon, strike=Strike, marker=Marker, smoke=Smoke)


# ================= вторая партия =================
def comps(Ar):
    lab, n = ndimage.label(Ar > .3, structure=np.ones((3, 3))); out = []
    for k in range(1, n + 1):
        m = lab == k; ys, xs = np.nonzero(m)
        if len(ys) < 200: continue
        y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        out.append(dict(m=(Ar * m)[y0:y1, x0:x1].astype(np.float32), y0=y0, x0=x0, h=y1 - y0, w=x1 - x0, cx=(x0 + x1) / 2))
    out.sort(key=lambda c: c['cx']); return out


def paste_max(dst, src, x0, y0):
    h, w = src.shape; X0, Y0, X1, Y1 = max(x0, 0), max(y0, 0), min(x0 + w, W), min(y0 + h, H)
    if X1 > X0 and Y1 > Y0:
        dst[Y0:Y1, X0:X1] = np.maximum(dst[Y0:Y1, X0:X1], src[Y0 - y0:Y1 - y0, X0 - x0:X1 - x0])


def bolt(p0, p1, disp, lv, r):
    pts = [np.array(p0, float), np.array(p1, float)]
    for _ in range(lv):
        new = [pts[0]]
        for a, b in zip(pts[:-1], pts[1:]):
            m = (a + b) / 2; d = b - a; nrm = np.array([-d[1], d[0]]) / (np.hypot(*d) + 1e-6)
            new += [m + nrm * r.normal(0, disp), b]
        pts = new; disp *= .55
    return np.array(pts, np.int32)


class Lightning(Base):
    """буквы заряжаются: по контуру бегают разряды, в «100» бьёт молния со вспышкой"""
    TS = 1.50

    def __init__(s):
        e = (A > .5).astype(np.uint8); ys, xs = np.nonzero(e - cv2.erode(e, np.ones((3, 3), np.uint8)))
        s.E = np.c_[xs, ys]

    def shake(s, t):
        if t < s.TS: return 0, 0
        a = 9 * np.exp(-(t - s.TS) / .08); r = np.random.default_rng(int(t * 1000)); return r.normal(0, a), r.normal(0, a)

    def frame(s, f, t, bg):
        r = np.random.default_rng(f + 100)
        k, sh = entry(t); a = vshift(A, sh) * k
        ch = smooth(1.15, 1.35, t) * (1 - smooth(1.9, 2.4, t))
        col = CREAM + (np.array([205, 228, 255]) - CREAM) * ch * .6
        bg = text_on(bg, a, col)
        G = np.zeros((H, W), np.float32)
        for _ in range(int(16 * ch)):
            p = s.E[r.integers(len(s.E))]; q = p + r.normal(0, 1, 2) * r.uniform(30, 110)
            cv2.polylines(G, [bolt(p, q, 14, 4, r)], False, float(r.uniform(.5, 1)), 2, cv2.LINE_AA)
        if s.TS <= t < s.TS + .14 and f % 2 == 0:
            r2 = np.random.default_rng(5)
            main = bolt((620, -20), (548, 140), 60, 6, r2); cv2.polylines(G, [main], False, 1.0, 5, cv2.LINE_AA)
            for i in r2.choice(len(main), 5):
                cv2.polylines(G, [bolt(main[i], main[i] + r2.normal(0, 1, 2) * 160, 30, 4, r2)], False, .7, 2, cv2.LINE_AA)
        add = G[..., None] * 255 + cv2.GaussianBlur(G, (0, 0), 3)[..., None] * np.array([150, 200, 255]) * 1.5 \
            + cv2.GaussianBlur(G, (0, 0), 12)[..., None] * np.array([90, 150, 255]) * 1.2 + cv2.GaussianBlur(G, (0, 0), 40)[..., None] * np.array([60, 110, 255]) * .7 \
            + cv2.GaussianBlur(a * ch, (0, 0), 10)[..., None] * np.array([80, 140, 255]) * .5
        if t >= s.TS: add = add + np.exp(-(t - s.TS) / .07) * np.array([190, 210, 255]) * .6
        return screen(bg, add)

    def sound(s):
        b = np.zeros(int(DUR * SR)); put(b, APPEAR, thock())
        for i in range(160):
            tc = 1.15 + i * (1.2 / 160); c = tt(rng.uniform(.004, .015))
            put(b, tc, bp(noise(len(c)), 2000, 7000) * rng.uniform(0, 1) ** 2, .6 * smooth(1.15, 1.35, tc) * (1 - smooth(1.9, 2.4, tc)))
        t = tt(1.4); put(b, s.TS, hp(noise(len(t)), 900) * np.exp(-t / .03) * 2 + lp(noise(len(t)), 120) * np.exp(-t / .5) * 4)
        return b


class Melt(Base):
    """буквы плавятся и стекают вниз потёками"""
    def __init__(s):
        n1 = fbm(8, W, (30, 80), (1, .5), 61)[0]; nf = fbm(8, W, (3, 7), (1, .5), 62)[0]
        s.spd = (.25 + 1.1 * n1 + 1.8 * smooth(.72, .9, nf)).astype(np.float32)
        s.dl = ((fbm(8, W, (40, 100), (1, .5), 63)[0] - .5) * .3).astype(np.float32)

    def frame(s, f, t, bg):
        k, sh = entry(t)
        if t < HIT: return text_on(bg, vshift(A, sh) * k)
        el = np.clip(t - HIT - s.dl, 0, None); D = (520 * s.spd * el ** 1.5)[None, :]
        out = np.zeros((H, W), np.float32)
        for Ar, top, h in ((A1, 92, 430), (A2, 540, 215)):
            w = np.clip((YY - top) / h, .12, 1)
            out = np.maximum(out, cv2.remap(Ar, XX, (YY - D * w).astype(np.float32), cv2.INTER_LINEAR, borderValue=0))
        out *= 1 - smooth(450, 900, D)
        b3 = cv2.GaussianBlur(out, (0, 0), 3); hl = np.clip((b3 - vshift(b3, 5)) * 2.5, 0, 1)
        bg = text_on(bg, out, CREAM * .95)
        return screen(bg, (hl * out)[..., None] * 160)

    def sound(s):
        b = np.zeros(int(DUR * SR)); put(b, APPEAR, thock())
        t = tt(1.6); put(b, HIT, lp(noise(len(t)), 400) * (1 + .5 * np.sin(2 * np.pi * 3 * t)) * smooth(0, .2, t) * 1.5)
        for _ in range(10):
            c = tt(.07); fr = 900 * np.exp(-c / .03) + 250
            put(b, HIT + rng.uniform(.2, 1.5), np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.exp(-c / .025), rng.uniform(.3, .7))
        return b


class BlackHole(Base):
    """надпись закручивает и засасывает в точку над головой, хлопок и ударная волна"""
    P = np.array([548., 300.]); TS = HIT; TE = HIT + .6

    def __init__(s):
        s.dx, s.dy = XX - s.P[0], YY - s.P[1]; s.r = np.hypot(s.dx, s.dy); s.th = np.arctan2(s.dy, s.dx)
        ys, xs = np.nonzero(A > .5); i = rng.choice(len(xs), 1500)
        s.pr = np.hypot(xs[i] - s.P[0], ys[i] - s.P[1]); s.pa = np.arctan2(ys[i] - s.P[1], xs[i] - s.P[0])

    def warp(s, img, rs, th, bm=cv2.BORDER_REFLECT):
        return cv2.remap(img, (s.P[0] + rs * np.cos(th)).astype(np.float32), (s.P[1] + rs * np.sin(th)).astype(np.float32), cv2.INTER_LINEAR, borderMode=bm, borderValue=0)

    def frame(s, f, t, bg):
        k, sh = entry(t)
        if t < s.TS: return text_on(bg, vshift(A, sh) * k)
        u = min((t - s.TS) / (s.TE - s.TS), 1.0)
        if t < s.TE:
            pin = .35 * smooth(0, 1, u); bg = s.warp(bg, s.r * (1 + pin * np.exp(-(s.r / 260) ** 2)), s.th)
            sc = max(1 - u ** 1.6, .02); tw = 9 * u ** 2 * np.exp(-s.r / 350)
            a = s.warp(A, s.r / sc, s.th + tw, cv2.BORDER_CONSTANT)
            col = CREAM + (255 - CREAM) * u ** 2
            bg = text_on(bg, a, col, k=.5 * (1 - u))
            rr = s.pr * (1 - u) ** 1.5; an = s.pa + 6 * u ** 2 * 300 / (s.pr + 50)
            cnt, _ = splat(s.P[0] + rr * np.cos(an), s.P[1] + rr * np.sin(an), np.full(1500, u * (1 - u) * 4), np.ones(1500), 1.2)
            bg = screen(bg, np.clip(cnt, 0, 1)[..., None] * 255)
            g = np.exp(-(s.r / (30 + 60 * u)) ** 2) * u * 1.2
            return screen(bg, g[..., None] * np.array([255, 230, 210]))
        dt = t - s.TE; R = 1400 * dt
        disp = 16 * np.exp(-((s.r - R) / 40) ** 2) * np.exp(-dt / .4)
        bg = s.warp(bg, np.maximum(s.r - disp, 0), s.th)
        g = np.exp(-(s.r / 220) ** 2) * np.exp(-dt / .08) * 1.5
        return screen(bg, g[..., None] * np.array([255, 235, 220]))

    def sound(s):
        b = np.zeros(int(DUR * SR)); put(b, APPEAR, thock())
        t = tt(s.TE - s.TS); x = noise(len(t)); sw = np.zeros_like(x)
        for i, fc in enumerate(np.geomspace(200, 3000, 8)):
            seg = slice(i * len(x) // 8, (i + 1) * len(x) // 8); sw[seg] = lp(x, fc)[seg]
        put(b, s.TS, sw * (t / t[-1]) ** 2 * 3)
        c = tt(.9); put(b, s.TE, noise(len(c)) * np.exp(-c / .02) * 1.2 + np.sin(2 * np.pi * 45 * c) * np.exp(-c / .3) * 1.5)
        return b


class Laser(Base):
    """лазер выжигает слово строчкой сверху вниз: раскалённый след остывает в белый, искры"""
    ROWS = ((92, 430, .80, 1.30), (540, 215, 1.32, 1.80)); EM = (1120, -60)

    def __init__(s):
        e1 = .80 + (YY - 92) / 430 * .5; e2 = 1.32 + (YY - 540) / 215 * .48
        s.ET = np.where(A1 >= A2, e1, e2).astype(np.float32)
        xs = np.nonzero(A.max(0) > .5)[0]; s.x0, s.x1 = xs.min(), xs.max(); s.sp = []

    def frame(s, f, t, bg):
        rev = A * (s.ET <= t); heat = np.exp(-np.clip(t - s.ET, 0, None) / .15) * (s.ET <= t)
        h2 = np.clip(heat * 2 - 1, 0, 1); h1 = np.clip(heat * 2, 0, 1)
        col = CREAM + (np.array([255, 120, 30]) - CREAM) * h1[..., None]
        col = col + (np.array([255, 245, 220]) - col) * h2[..., None]
        bg = text_on(bg, rev, col)
        add = cv2.GaussianBlur(heat * rev, (0, 0), 6)[..., None] * np.array([255, 120, 40]) * 1.2
        L = np.zeros((H, W), np.float32)
        for top, h, t0, t1 in s.ROWS:
            if t0 <= t <= t1:
                yf = top + (t - t0) / (t1 - t0) * h; ph = (t * 18) % 2; tri = ph if ph < 1 else 2 - ph
                dot = (int(s.x0 + tri * (s.x1 - s.x0)), int(yf))
                cv2.line(L, s.EM, dot, .55, 2, cv2.LINE_AA); cv2.circle(L, dot, 5, 1.0, -1, cv2.LINE_AA)
                for _ in range(6): s.sp.append([dot[0], dot[1], rng.normal(0, 160), -rng.uniform(80, 420), rng.uniform(.2, .5), 0.])
        sp = np.zeros((H, W), np.float32)
        for q in s.sp:
            x0, y0 = q[0], q[1]; q[0] += q[2] / FPS; q[1] += q[3] / FPS; q[3] += 1500 / FPS; q[5] += 1 / FPS
            a = max(0, 1 - q[5] / q[4]); cv2.line(sp, (int(x0), int(y0)), (int(q[0]), int(q[1])), a, 2, cv2.LINE_AA)
        s.sp[:] = [q for q in s.sp if q[5] < q[4]]
        add = add + L[..., None] * np.array([255, 120, 90]) + cv2.GaussianBlur(L, (0, 0), 8)[..., None] * np.array([255, 60, 40]) * 1.4 \
            + (sp[..., None] + cv2.GaussianBlur(sp, (0, 0), 3)[..., None] * 1.5) * np.array([255, 200, 120])
        return screen(bg, add)

    def sound(s):
        b = np.zeros(int(DUR * SR))
        for top, h, t0, t1 in s.ROWS:
            t = tt(t1 - t0); e = smooth(0, .02, t) * (1 - smooth(t[-1] - .03, t[-1], t))
            put(b, t0, (np.sin(2 * np.pi * 2400 * t) * .25 + np.sin(2 * np.pi * 4800 * t) * .08) * (1 + .3 * np.sin(2 * np.pi * 36 * t)) * e + hp(noise(len(t)), 4000) * .3 * e)
        return b


class Paint(Base):
    """капли коралловой краски бьют в стену и растекаются по буквам, брызги, потёки"""
    DR = ((300, 250, .80), (760, 180, .88), (520, 640, .98), (880, 650, 1.05))

    def __init__(s):
        jag = fbm(H, W, (6, 15, 35), (1, .6, .3), 71)
        s.RT = np.min([td + np.hypot(XX - x, YY - y) / 550 for x, y, td in s.DR], 0) + (jag - .5) * .12
        s.dots = []
        for x, y, td in s.DR:
            for _ in range(40):
                an = rng.uniform(0, 6.28); rr = rng.uniform(40, 260)
                s.dots.append((int(x + np.cos(an) * rr), int(y + np.sin(an) * rr), int(rng.uniform(3, 14) * (1 - rr / 400)), td + rr / 1500))
        ys, xs = np.nonzero(A > .5); s.drips = []
        for xq in rng.choice(np.unique(xs), 9):
            col_y = ys[xs == xq]; s.drips.append((int(xq), int(col_y.max()), rng.uniform(80, 170), rng.uniform(5, 9), rng.uniform(1.2, 1.5)))
        s.tone = (.9 + .1 * fbm(H, W, (4, 10), (1, .5), 72))[..., None]

    def frame(s, f, t, bg):
        P = A * smooth(0, .05, t - s.RT)
        D = np.zeros((H, W), np.float32)
        for x, y, rad, td in s.dots:
            if t >= td and rad > 0: cv2.circle(D, (x, y), rad, 1.0, -1, cv2.LINE_AA)
        for x, y, L, w, t0 in s.drips:
            if t > t0:
                ln = L * smooth(0, .9, t - t0); cv2.line(D, (x, y), (x, int(y + ln)), 1.0, int(w), cv2.LINE_AA)
                cv2.circle(D, (x, int(y + ln)), int(w * .7), 1.0, -1, cv2.LINE_AA)
        P = np.maximum(P, D)
        b3 = cv2.GaussianBlur(P, (0, 0), 3); hl = np.clip((b3 - vshift(b3, 4)) * 3, 0, 1)
        bg = text_on(bg, P, CORAL * s.tone, k=.4)
        return screen(bg, (hl * P)[..., None] * 150)

    def sound(s):
        b = np.zeros(int(DUR * SR))
        for x, y, td in s.DR:
            c = tt(.15); put(b, td, lp(noise(len(c)), 900) * np.exp(-c / .035) * 2 + noise(len(c)) * np.exp(-c / .003) * .4)
        return b


class Flap(Base):
    """табло как в аэропорту: каждая буква перещёлкивает случайные символы и встаёт на место"""
    def __init__(s):
        s.cells = comps(A1) + comps(A2)
        pool = list('0123456789') + list('АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЭЮЯ')
        n1 = len(comps(A1))
        for i, c in enumerate(s.cells):
            c['stop'] = (.95 + i * .10) if i < n1 else (1.15 + (i - n1) * .07)
            nfl = int((c['stop'] - .80) / .055); seq = []
            for _ in range(nfl):
                ch = pool[rng.integers(len(pool))]; g = glyph(ch, LAT if ch.isdigit() else CYR)
                seq.append(cv2.resize(g, (c['w'], c['h']), interpolation=cv2.INTER_AREA))
            seq.append(c['m']); c['seq'] = seq

    def frame(s, f, t, bg):
        k, sh = entry(t)
        T = np.zeros((H, W), np.float32); Tx = np.zeros((H, W), np.float32)
        for c in s.cells:
            cv2.rectangle(T, (c['x0'] - 14, c['y0'] - 18 + sh), (c['x0'] + c['w'] + 14, c['y0'] + c['h'] + 18 + sh), 1.0, -1)
            seq = c['seq']; fi = (t - .80) / .055
            if fi < 0: img = seq[0]
            elif fi >= len(seq) - 1: img = seq[-1]
            else:
                i = int(fi); p = fi - i; O, Nn = seq[i], seq[i + 1]; h, w = O.shape; mid = h // 2
                img = np.zeros_like(O); img[:mid] = Nn[:mid]
                if p < .5:
                    oth = max(1, int(mid * (1 - 2 * p))); img[mid - oth:mid] = cv2.resize(O[:mid], (w, oth)) * (.6 + .4 * (1 - 2 * p))
                    img[mid:] = O[mid:]
                else:
                    img[mid:] = O[mid:]; nh = max(1, int((h - mid) * (2 * p - 1)))
                    img[mid:mid + nh] = cv2.resize(Nn[mid:], (w, nh)) * (.6 + .4 * (2 * p - 1))
            paste_max(Tx, img, c['x0'], c['y0'] + sh)
        bg = shadow(bg, T * k, k=.6)
        bg = over(bg, np.array([30, 30, 33], np.float32), T * .92 * k)
        for c in s.cells:
            y = c['y0'] + c['h'] // 2 + sh; cv2.line(bg, (c['x0'] - 14, y), (c['x0'] + c['w'] + 14, y), (12, 12, 14), 3)
        return over(bg, CREAM, Tx * k)

    def sound(s):
        b = np.zeros(int(DUR * SR))
        for c in s.cells:
            for i in range(len(c['seq']) - 1):
                cl = tt(.008); put(b, .80 + (i + 1) * .055, bp(noise(len(cl)), 1500, 5000) * np.exp(-cl / .002), rng.uniform(.25, .45))
        return b


class Drop(Base):
    """буквы падают сверху по одной и отскакивают"""
    def __init__(s):
        c1, c2 = comps(A1), comps(A2); s.cells = c1 + c2
        for i, c in enumerate(c1): c['tl'] = .92 + i * .08
        for i, c in enumerate(c2): c['tl'] = 1.18 + i * .06

    def frame(s, f, t, bg):
        T = np.zeros((H, W), np.float32)
        for c in s.cells:
            d = t - c['tl']
            if d < -.32: continue
            off = -1300 * (1 - ((d + .32) / .32) ** 2) if d < 0 else -70 * np.exp(-d / .11) * abs(np.sin(d * np.pi / .17))
            paste_max(T, c['m'], c['x0'], int(c['y0'] + off))
        return text_on(bg, T)

    def sound(s):
        b = np.zeros(int(DUR * SR))
        for c in s.cells:
            th = tt(.12); fq = rng.uniform(85, 140)
            put(b, c['tl'], np.sin(2 * np.pi * fq * th) * np.exp(-th / .05) + noise(len(th)) * np.exp(-th / .004) * .3, .8)
            put(b, c['tl'] + .17, np.sin(2 * np.pi * fq * 1.4 * th) * np.exp(-th / .03), .25)
        return b


class Flashlight(Base):
    """в комнате темно, луч фонарика проходит по стене и находит надпись, потом включается свет"""
    LON = 1.78

    def frame(s, f, t, bg):
        bg = text_on(bg, A)
        if t >= s.LON:
            lv = 1.0 if (t < s.LON + .04 or t >= s.LON + .08) else .35
            base = .18 + (1 - .18) * lv * smooth(s.LON, s.LON + .25, t + .2)
        else: base = .18
        if .62 <= t < s.LON + .2:
            cx = -150 + (t - .62) / (1.55 - .62) * 1350; cy = 380 + 60 * np.sin(t * 4)
            spot = np.exp(-((XX - cx) ** 2 + (YY - cy) ** 2) / (2 * 190 ** 2)) * (1 - smooth(s.LON, s.LON + .2, t))
        else: spot = 0
        Lm = base + (1 - base) * np.minimum(np.asarray(spot) * 1.15, 1)
        Lm = np.broadcast_to(Lm, (H, W)) if np.ndim(Lm) == 0 else Lm
        return bg * Lm[..., None] * np.array([1.0, .97, .9])

    def sound(s):
        b = np.zeros(int(DUR * SR))
        for tc in (.60, s.LON):
            c = tt(.03); put(b, tc, bp(noise(len(c)), 1000, 6000) * np.exp(-c / .004) * 1.2 + np.sin(2 * np.pi * 180 * c) * np.exp(-c / .01) * .5)
        t = tt(1.3); put(b, s.LON + .05, (np.sin(2 * np.pi * 100 * t) * .15 + np.sin(2 * np.pi * 200 * t) * .08) * smooth(0, .2, t) * (1 - smooth(1.0, 1.3, t)))
        return b


FX2 = dict(lightning=Lightning, melt=Melt, blackhole=BlackHole, laser=Laser, paint=Paint, flap=Flap, drop=Drop, flashlight=Flashlight)
FX.update(FX2)


def run(name, out):
    eff = FX[name]()
    snd = eff.sound(); snd = snd / (np.abs(snd).max() + 1e-9) * .25
    st = (np.stack([snd, snd], 1) * 32767).astype(np.int16)
    wf = wave.open(f'sfx_{name}.wav', 'wb'); wf.setnchannels(2); wf.setsampwidth(2); wf.setframerate(SR); wf.writeframes(st.tobytes()); wf.close()
    dec = subprocess.Popen(['ffmpeg', '-v', 'error', '-ss', str(T0), '-i', SRC, '-t', str(DUR),
                            '-vf', 'eq=contrast=1.05:saturation=0.9:gamma=0.97,colorbalance=rh=0.03:bh=-0.03:rs=-0.01:bs=0.02,vignette=angle=PI/4.2',
                            '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], stdout=subprocess.PIPE)
    mcap = cv2.VideoCapture(MASK)
    enc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                            '-ss', str(T0), '-t', str(DUR), '-i', SRC, '-i', f'sfx_{name}.wav',
                            '-filter_complex', '[1:a][2:a]amix=inputs=2:normalize=0[a]', '-map', '0:v', '-map', '[a]',
                            '-c:v', 'libx264', '-crf', '17', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', out], stdin=subprocess.PIPE)
    for f in range(N):
        t = T0 + f / FPS
        fr = np.frombuffer(dec.stdout.read(W * H * 3), np.uint8).reshape(H, W, 3).astype(np.float32)
        mcap.set(cv2.CAP_PROP_POS_FRAMES, round(t * FPS)); _, m = mcap.read()
        pm = cv2.GaussianBlur(cv2.resize(m[:, :, 0].astype(np.float32) / 255, (W, H)), (0, 0), 1.6)[..., None]
        o = eff.frame(f, t, fr.copy())
        o = o * (1 - pm) + fr * pm
        dx, dy = eff.shake(t)
        if dx or dy: o = cv2.warpAffine(o, np.float32([[1, 0, dx], [0, 1, dy]]), (W, H), borderMode=cv2.BORDER_REFLECT)
        enc.stdin.write(np.clip(o, 0, 255).astype(np.uint8).tobytes())
    enc.stdin.close(); enc.wait(); print(name, 'готово', flush=True)


if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2])
