"""Трансформер v3: куб над головой раскладывается по проступающему чертежу в «100 ПРОМПТОВ».
python3 fx4.py unfold out.mp4"""
import sys
import numpy as np, cv2
from scipy import ndimage
import fx
from fx import *
from fx3 import warp_piece, region

C = np.array([548., 52.])
BLUE = np.array([185, 212, 235], np.float32)


def io(u): u = float(np.clip(u, 0, 1)); return 4 * u ** 3 if u < .5 else 1 - (-2 * u + 2) ** 3 / 2
def back(u): u = float(np.clip(u, 0, 1)); c1, c3 = 1.70158, 2.70158; return 1 + c3 * (u - 1) ** 3 + c1 * (u - 1) ** 2


class Unfold(Base):
    POP, BP0, BP1 = .56, .66, 1.02

    def __init__(s):
        c1, c2 = comps(A1), comps(A2); s.pl = []
        for ci, c in enumerate(c1 + c2):
            m = c['m']; h, w = m.shape; yy, xx = np.mgrid[0:h, 0:w]
            lab = (yy > h * rng.uniform(.42, .58) + (xx - w / 2) * rng.uniform(-.1, .1)).astype(int)
            if w > 150: lab = lab * 2 + (xx > w * rng.uniform(.4, .6))
            for v in np.unique(lab[m > .3]):
                sub, ns = ndimage.label((lab == v) & (m > .3))
                for q in range(1, ns + 1):
                    qm = sub == q; yq, xq = np.nonzero(qm)
                    if len(yq) < 40: continue
                    by0, by1, bx0, bx1 = yq.min(), yq.max() + 1, xq.min(), xq.max() + 1
                    ca = (m * qm)[by0:by1, bx0:bx1].astype(np.float32)
                    e = (ca > .5).astype(np.uint8); edge = (e - cv2.erode(e, np.ones((3, 3), np.uint8))).astype(np.float32)
                    c0 = np.array([c['x0'] + (bx0 + bx1) / 2, c['y0'] + (by0 + by1) / 2])
                    s.pl.append(dict(ca=np.dstack([ca, edge]), c0=c0, row=1 if ci < len(c1) else 2, ph=rng.uniform(0, 6),
                                     r0=float(rng.choice([-90, 90, 180])), ov=rng.choice([-1, 1]) * 14))
        r1 = sorted([p for p in s.pl if p['row'] == 1], key=lambda p: abs(p['c0'][0] - C[0]))
        r2 = sorted([p for p in s.pl if p['row'] == 2], key=lambda p: abs(p['c0'][0] - C[0]))
        for i, p in enumerate(r1): p['TL'] = 1.10 + i * .035
        for i, p in enumerate(r2): p['TL'] = 1.30 + i * .022
        s.TALL = max(p['TL'] for p in s.pl) + .02
        cs, _ = cv2.findContours((A > .5).astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        s.cont = [c[:, 0, :] for c in cs if len(c) > 30]
        s.guides = [((20, 92), (1060, 92)), ((20, 522), (1060, 522)), ((20, 540), (1060, 540)), ((20, 755), (1060, 755)), ((548, 40), (548, 800))]

    def pose(s, p, t):
        A_, B_, Cc = .13, .13, .08
        t0 = p['TL'] - A_ - B_ - Cc
        if t < t0: return None
        d = t - t0; mid = np.array([p['c0'][0], C[1]])
        if d < A_:
            e = io(d / A_); return C + (mid - C) * e, p['r0'], .3 + .4 * e, 0.0, 1.0
        pre = p['c0'] + np.array([0, p['ov']])
        if d < A_ + B_:
            e = io((d - A_) / B_); return mid + (pre - mid) * e, p['r0'] * (1 - e), .7 + .3 * e, 0.0, 1 - .5 * e
        if d < A_ + B_ + Cc:
            e = back((d - A_ - B_) / Cc); return pre + (p['c0'] - pre) * e, 0.0, 1.0, 0.0, .5 * (1 - e)
        return p['c0'], 0.0, 1.0, d - A_ - B_ - Cc, 0.0

    def cube(s, bg, t):
        if t < s.POP: return bg
        out = [p for p in s.pl if t >= p['TL'] - .34]
        rem = 1 - len(out) / len(s.pl)
        sz = 96 * back((t - s.POP) / .14) * (.3 + .7 * rem ** .7) * (1 - smooth(.0, .12, -rem + .12)) * (1 - smooth(s.TALL - .25, s.TALL - .12, t))
        if sz < 2: return bg
        bob = 4 * np.sin((t - s.POP) * 9) * (rem > .99)
        x, y, h2, dp = C[0], C[1] + bob, sz / 2, sz * .28
        front = np.array([[x - h2, y - h2], [x + h2, y - h2], [x + h2, y + h2], [x - h2, y + h2]], np.int32)
        top = np.array([[x - h2, y - h2], [x - h2 + dp, y - h2 - dp], [x + h2 + dp, y - h2 - dp], [x + h2, y - h2]], np.int32)
        side = np.array([[x + h2, y - h2], [x + h2 + dp, y - h2 - dp], [x + h2 + dp, y + h2 - dp], [x + h2, y + h2]], np.int32)
        sh = np.zeros((H, W), np.float32); cv2.fillPoly(sh, [front + [14, 20], side + [14, 20]], 1.0, cv2.LINE_AA)
        bg = bg * (1 - cv2.GaussianBlur(sh, (0, 0), 10)[..., None] * .45)
        for poly, col in ((side, CREAM * .62), (top, CREAM * 1.02), (front, CREAM * .9)):
            m = np.zeros((H, W), np.float32); cv2.fillPoly(m, [poly], 1.0, cv2.LINE_AA); bg = over(bg, np.clip(col, 0, 255), m)
        ln = np.zeros((H, W), np.float32)
        for poly in (front, top, side): cv2.polylines(ln, [poly], True, 1.0, 2, cv2.LINE_AA)
        cv2.line(ln, (int(x - h2 * .6), int(y)), (int(x + h2 * .6), int(y)), .6, 2, cv2.LINE_AA)
        return over(bg, np.array([70, 64, 60], np.float32), ln * .8)

    def frame(s, f, t, bg):
        fade = 1 - smooth(s.TALL + .05, s.TALL + .4, t)
        if t >= s.BP0 and fade > 0:
            u = smooth(s.BP0, s.BP1, t); L = np.zeros((H, W), np.float32); G = np.zeros((H, W), np.float32)
            for c in s.cont:
                n = int(len(c) * u)
                if n > 2: cv2.polylines(L, [c[:n].astype(np.int32)], False, 1.0, 2, cv2.LINE_AA)
            for (a, b) in s.guides:
                a, b = np.array(a, float), np.array(b, float); e = a + (b - a) * smooth(s.BP0 - .04, s.BP1 - .1, t)
                L_ = np.hypot(*(e - a)); k = 0
                while k < L_:
                    p0 = a + (b - a) / np.hypot(*(b - a)) * k; p1 = a + (b - a) / np.hypot(*(b - a)) * min(k + 14, L_)
                    cv2.line(G, tuple(p0.astype(int)), tuple(p1.astype(int)), 1.0, 1, cv2.LINE_AA); k += 24
                for q in (a, e): cv2.line(G, (int(q[0]) - 6, int(q[1]) - 6), (int(q[0]) + 6, int(q[1]) + 6), 1.0, 1, cv2.LINE_AA)
            bg = over(bg, BLUE, L * .6 * fade)
            bg = screen(bg, cv2.GaussianBlur(L, (0, 0), 3)[..., None] * BLUE * .25 * fade)
        items = []; Acv = np.zeros((H, W), np.float32); rails = np.zeros((H, W), np.float32)
        for p in s.pl:
            ps = s.pose(p, t)
            if ps is None: continue
            pos, rot, sc, since, depth = ps
            if since < .25:
                a_ = 1 - smooth(0, .12, since); cv2.line(rails, tuple(C.astype(int)), (int(pos[0]), int(C[1])), a_, 1, cv2.LINE_AA)
                cv2.line(rails, (int(pos[0]), int(C[1])), (int(pos[0]), int(pos[1])), a_, 1, cv2.LINE_AA)
            wa, D = warp_piece(p['ca'], rot, sc); rg = region(pos[0], pos[1], D)
            if rg is None: continue
            ax0, ay0, ax1, ay1, ox, oy = rg; wa = wa[oy:oy + ay1 - ay0, ox:ox + ax1 - ax0]
            Acv[ay0:ay1, ax0:ax1] = np.maximum(Acv[ay0:ay1, ax0:ax1], wa[..., 0])
            items.append((rg, wa, rot, since, p['ph'], depth))
        solid = smooth(s.TALL, s.TALL + .12, t)
        bg = shadow(bg, np.maximum(Acv * (1 - solid), A * solid))
        bg = over(bg, BLUE, rails * .25)
        for (ax0, ay0, ax1, ay1, _, _), wa, rot, since, ph, depth in items:
            al = wa[..., 0] * (1 - solid); ed = wa[..., 1]; moving = since <= 0
            th = int(3 + 9 * depth)
            side = cv2.warpAffine(wa[..., 0], np.float32([[1, 0, th * .6], [0, 1, th]]), (al.shape[1], al.shape[0]))
            sa = np.clip(side - wa[..., 0], 0, 1) * (1 - solid)
            R = bg[ay0:ay1, ax0:ax1]; R = R * (1 - sa[..., None]) + np.array([118, 110, 102]) * sa[..., None]
            b = (.8 + .2 * np.cos(np.radians(rot) * 2 + ph)) if moving else (.9 + .1 * smooth(0, .25, since))
            col = CREAM * b + (ed * 60 * moving)[..., None]
            col = col * (1 - .55 * (ed * (1 - smooth(.05, .35, since)) * (not moving))[..., None])
            bg[ay0:ay1, ax0:ax1] = R * (1 - al[..., None]) + np.clip(col, 0, 255) * al[..., None]
        if solid > 0:
            bg = over(bg, CREAM, A * solid)
            xs = -200 + (t - s.TALL - .08) / .45 * 1500
            sw = np.exp(-((XX - xs - (YY - 400) * .45) / 45) ** 2) * A * (s.TALL + .08 < t < s.TALL + .6)
            bg = screen(bg, sw[..., None] * 170)
        return s.cube(bg, t)

    def sound(s):
        n = int(DUR * SR); b = np.zeros(n); tm = T0 + np.arange(n) / SR; fl = np.zeros(n)
        c = tt(.14); put(b, s.POP, np.sin(2 * np.pi * 110 * c) * np.exp(-c / .05) + noise(len(c)) * np.exp(-c / .006) * .3, 1.1)
        t_ = tt(s.BP1 - s.BP0); put(b, s.BP0, bp(noise(len(t_)), 3000, 8000) * (1 + .5 * np.sin(2 * np.pi * 14 * t_)) * .12)
        for p in s.pl:
            t0 = p['TL'] - .34; fl += (tm >= t0) & (tm < p['TL'] - .08)
            c = tt(.03); put(b, p['TL'], bp(noise(len(c)), 1800, 6000) * np.exp(-c / .004) + np.sin(2 * np.pi * 150 * c) * np.exp(-c / .012) * .7, rng.uniform(.2, .38))
        ph = np.cumsum(150 + 10 * fl) / SR * 2 * np.pi
        b += lp(np.sign(np.sin(ph)) * .5 + np.sin(2 * ph) * .3, 1600) * np.clip(fl / 14, 0, 1) * .22
        c = tt(.2); put(b, s.TALL, np.sin(2 * np.pi * 80 * c) * np.exp(-c / .06) * 1.2 + bp(noise(len(c)), 500, 2000) * np.exp(-c / .02) * .5)
        c = tt(.8); put(b, s.TALL + .1, (np.sin(2 * np.pi * 2600 * c) + .6 * np.sin(2 * np.pi * 3900 * c)) * np.exp(-c / .25) * .25)
        return b


fx.FX['unfold'] = Unfold
if __name__ == '__main__':
    fx.run(sys.argv[1], sys.argv[2])
