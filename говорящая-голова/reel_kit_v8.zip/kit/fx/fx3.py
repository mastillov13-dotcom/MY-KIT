"""Финалисты хука, доводка до уровня огня v4.  python3 fx3.py <dust2|trans|slice|marker2|light2|flap2|flash2> out.mp4"""
import sys
import numpy as np, cv2
from scipy import ndimage
from scipy.spatial import cKDTree
import fx
from fx import *


def curl_field(seed, scales=(60, 140, 300), amps=(1, .6, .35)):
    psi = cv2.GaussianBlur(fbm(H, W, scales, amps, seed), (0, 0), 3)
    gy, gx = np.gradient(psi); vx, vy = gy, -gx; m = np.sqrt(vx ** 2 + vy ** 2).max()
    return (vx / m).astype(np.float32), (vy / m).astype(np.float32)


def warp_piece(ca, ang_deg, sc):
    h, w = ca.shape[:2]; D = int(np.hypot(w, h) * sc) + 4
    M = cv2.getRotationMatrix2D((w / 2, h / 2), ang_deg, sc); M[:, 2] += (D / 2 - w / 2, D / 2 - h / 2)
    return cv2.warpAffine(ca, M, (D, D), flags=cv2.INTER_LINEAR), D


def region(cx, cy, D):
    X0, Y0 = int(cx - D / 2), int(cy - D / 2)
    ax0, ay0, ax1, ay1 = max(X0, 0), max(Y0, 0), min(X0 + D, W), min(Y0 + D, H)
    if ax1 <= ax0 or ay1 <= ay0: return None
    return (ax0, ay0, ax1, ay1, ax0 - X0, ay0 - Y0)


# =================== 2. ПЫЛЬ ===================
class Dust2(Base):
    def __init__(s):
        ys, xs = np.nonzero(A > .5); x0, x1 = xs.min(), xs.max()
        jag = fbm(H, W, (14, 40, 90), (1, .6, .3), 81)
        s.RT = (HIT + (XX - x0) / (x1 - x0) * .95 + (jag - .5) * .40 + (YY > 530) * .06).astype(np.float32)
        s.grain = fbm(H, W, (2, 4), (1, .5), 82)
        sel = (ys % 2 == 0) & (xs % 2 == 0)
        s.x, s.y = xs[sel].astype(np.float32), ys[sel].astype(np.float32); n = len(s.x)
        s.rt = s.RT[ys[sel], xs[sel]] + rng.uniform(0, .05, n)
        r = rng.random(n); s.cls = np.where(r < .04, 2, np.where(r < .38, 1, 0))
        s.vx = rng.normal(0, 30, n).astype(np.float32); s.vy = rng.normal(-10, 30, n).astype(np.float32)
        s.life = np.where(s.cls == 2, rng.uniform(.9, 1.4, n), np.where(s.cls == 1, rng.uniform(.9, 1.7, n), rng.uniform(1.1, 2.2, n)))
        s.tone = np.where(s.cls == 2, rng.uniform(.5, .8, n), rng.uniform(.7, 1.02, n))
        s.cr = rng.uniform(2, 4.5, n)
        s.CX, s.CY = curl_field(83); s.haze = np.zeros((H // 4, W // 4), np.float32)

    def frame(s, f, t, bg):
        k, sh = entry(t)
        edge = s.RT - t + (s.grain - .5) * .07
        a = vshift(A, sh) * k * smooth(0, .05, edge)
        dark = 1 - .16 * (1 - smooth(0, .12, edge)) * (edge > 0)
        bg = text_on(bg, a, CREAM * dark[..., None])
        dt = 1 / FPS; i = np.nonzero(t >= s.rt)[0]
        if len(i):
            age = t - s.rt[i]; c = s.cls[i]
            ix = np.clip(s.x[i].astype(int), 0, W - 1); iy = np.clip(s.y[i].astype(int), 0, H - 1); off = int(t * 60) % H
            cx = s.CX[(iy + off) % H, ix]; cy = s.CY[(iy + off) % H, ix]
            wind = np.where(c == 2, 120, np.where(c == 1, 430, 680)) * smooth(0, .25, age)
            turb = np.where(c == 2, 140, np.where(c == 1, 380, 580))
            grav = np.where(c == 2, 950, np.where(c == 1, 170, -40))
            drag = np.where(c == 2, .8, np.where(c == 1, 3.0, 4.2))
            tvx = wind + cx * turb; tvy = -140 * (c == 0) - 60 * (c == 1) + cy * turb
            s.vx[i] += (tvx - s.vx[i]) * drag * dt; s.vy[i] += ((tvy - s.vy[i]) * drag + grav) * dt
            s.x[i] += s.vx[i] * dt; s.y[i] += s.vy[i] * dt
            al = np.clip(1 - age / s.life[i], 0, 1) ** 1.2
            for cl, bl, g in ((0, 1.3, .8), (1, .8, 1.4)):
                m = (c == cl) & (al > 0)
                if m.any():
                    cnt, tone = splat(s.x[i][m], s.y[i][m], al[m], s.tone[i][m], bl)
                    bg = over(bg, CREAM * tone[..., None], np.clip(cnt * g, 0, 1))
            m = np.nonzero((c == 2) & (al > 0))[0]
            if len(m):
                ch = np.zeros((H, W), np.float32); tn = np.zeros((H, W), np.float32)
                for j in m:
                    p = (int(s.x[i][j]), int(s.y[i][j])); rr = max(1, int(s.cr[i][j] * (.6 + .4 * al[j])))
                    cv2.circle(ch, p, rr, float(al[j]), -1, cv2.LINE_AA); cv2.circle(tn, p, rr, float(s.tone[i][j]), -1, cv2.LINE_AA)
                bg = over(bg, CREAM * np.clip(tn, .4, 1)[..., None], np.clip(ch, 0, 1))
            m = (c == 0) & (al > 0)
            hz = np.zeros_like(s.haze)
            np.add.at(hz, (np.clip((s.y[i][m] / 4).astype(int), 0, H // 4 - 1), np.clip((s.x[i][m] / 4).astype(int), 0, W // 4 - 1)), al[m] * .015)
            s.haze = s.haze * .94 + cv2.GaussianBlur(hz, (0, 0), 6)
        return over(bg, np.array([205, 196, 186], np.float32), np.clip(cv2.resize(s.haze, (W, H)), 0, .2))

    def sound(s):
        b = np.zeros(int(DUR * SR)); put(b, APPEAR, thock())
        t = tt(1.7); e = smooth(0, .15, t) * (1 - smooth(1.0, 1.7, t))
        put(b, HIT, hp(noise(len(t)), 2500) * e * .5 + bp(noise(len(t)), 200, 1200) * e * .6)
        for _ in range(30):
            c = tt(.02); put(b, HIT + rng.uniform(.05, 1.2), lp(noise(len(c)), 1500) * np.exp(-c / .005), rng.uniform(.1, .3))
        return b


# =================== 3. ТРАНСФОРМЕР ===================
class Trans(Base):
    """буквы собираются из крупных панелей: выезжают по осям, доворачиваются шагами по 90°, защёлкиваются"""
    def __init__(s):
        c1, c2 = comps(A1), comps(A2); s.pl = []
        for ci, c in enumerate(c1 + c2):
            m = c['m']; h, w = m.shape; yy, xx = np.mgrid[0:h, 0:w]; lab = np.zeros((h, w), np.int64)
            cuts = [(rng.uniform(-.12, .12), .5 + rng.uniform(-.15, .15), 'h')] + [(rng.uniform(-.12, .12), rng.uniform(.25, .75), rng.choice(['h', 'v']))]
            for sl, pos, kind in cuts:
                if kind == 'h': side = (yy - (pos * h + sl * (xx - w / 2))) > 0
                else: side = (xx - (pos * w + sl * (yy - h / 2))) > 0
                lab = lab * 2 + side
            base = (.88 + ci * .09) if ci < len(c1) else (1.18 + (ci - len(c1)) * .06)
            for j, v in enumerate(np.unique(lab[m > .3])):
                sub, ns = ndimage.label((lab == v) & (m > .3))
                for q in range(1, ns + 1):
                    qm = sub == q; yq, xq = np.nonzero(qm)
                    if len(yq) < 30: continue
                    by0, by1, bx0, bx1 = yq.min(), yq.max() + 1, xq.min(), xq.max() + 1
                    ca = (m * qm)[by0:by1, bx0:bx1].astype(np.float32)
                    e = (ca > .5).astype(np.uint8); edge = (e - cv2.erode(e, np.ones((3, 3), np.uint8))).astype(np.float32)
                    c0 = np.array([c['x0'] + (bx0 + bx1) / 2, c['y0'] + (by0 + by1) / 2])
                    ax = rng.choice([0, 1]); sgn = rng.choice([-1, 1])
                    p1 = c0 + (np.array([sgn * rng.uniform(260, 520), rng.uniform(-60, 60)]) if ax == 0 else np.array([rng.uniform(-60, 60), sgn * rng.uniform(260, 480)]))
                    p0 = p1 + (np.array([0, rng.choice([-1, 1]) * rng.uniform(120, 260)]) if ax == 0 else np.array([rng.choice([-1, 1]) * rng.uniform(120, 260), 0]))
                    TL = base + j * .035 + rng.uniform(-.02, .02)
                    s.pl.append(dict(ca=np.dstack([ca, edge]), c0=c0, TL=TL, p0=p0, p1=p1, r0=float(rng.choice([-180, -90, 90, 180])), ph=rng.uniform(0, 6), s0=rng.uniform(.6, .8)))

    @staticmethod
    def io(u): u = np.clip(u, 0, 1); return 4 * u ** 3 if u < .5 else 1 - (-2 * u + 2) ** 3 / 2

    def pose(s, p, t):
        A_, B_, C_ = .16, .16, .10                           # въезд, доворот+сдвиг, защёлка
        t0 = p['TL'] - A_ - B_ - C_
        if t < t0: return None
        d = t - t0
        if d < A_:
            e = s.io(d / A_); return p['p0'] + (p['p1'] - p['p0']) * e, p['r0'], p['s0'] + (1 - p['s0']) * .5 * e, 0.0, 1.0
        if d < A_ + B_:
            e = s.io((d - A_) / B_); pre = p['c0'] + (p['p1'] - p['c0']) * .08
            return p['p1'] + (pre - p['p1']) * e, p['r0'] * (1 - e), p['s0'] + (1 - p['s0']) * (.5 + .5 * e), 0.0, 1.0 - .4 * e
        if d < A_ + B_ + C_:
            u = (d - A_ - B_) / C_; c1, c3 = 1.70158, 2.70158; e = 1 + c3 * (u - 1) ** 3 + c1 * (u - 1) ** 2
            pre = p['c0'] + (p['p1'] - p['c0']) * .08; return pre + (p['c0'] - pre) * e, 0.0, 1.0, 0.0, .6 * (1 - e)
        return p['c0'], 0.0, 1.0, d - A_ - B_ - C_, 0.0

    def frame(s, f, t, bg):
        items = []; Acv = np.zeros((H, W), np.float32)
        for p in s.pl:
            ps = s.pose(p, t)
            if ps is None: continue
            pos, rot, sc, since, depth = ps
            wa, D = warp_piece(p['ca'], rot, sc); rg = region(pos[0], pos[1], D)
            if rg is None: continue
            ax0, ay0, ax1, ay1, ox, oy = rg; wa = wa[oy:oy + ay1 - ay0, ox:ox + ax1 - ax0]
            Acv[ay0:ay1, ax0:ax1] = np.maximum(Acv[ay0:ay1, ax0:ax1], wa[..., 0])
            items.append((rg, wa, rot, since, p['ph'], depth))
        bg = shadow(bg, Acv)
        for (ax0, ay0, ax1, ay1, _, _), wa, rot, since, ph, depth in items:
            al = wa[..., 0]; ed = wa[..., 1]; moving = since <= 0
            th = int(3 + 9 * depth)                          # толщина панели (боковая грань)
            if th > 0:
                side = cv2.warpAffine(al, np.float32([[1, 0, th * .6], [0, 1, th]]), (al.shape[1], al.shape[0]))
                sa = np.clip(side - al, 0, 1)
                R = bg[ay0:ay1, ax0:ax1]; bg[ay0:ay1, ax0:ax1] = R * (1 - sa[..., None]) + np.array([120, 112, 104]) * sa[..., None]
            b = (.8 + .2 * np.cos(np.radians(rot) * 2 + ph)) if moving else (.88 + .12 * smooth(0, .3, since))
            sweep = np.exp(-((np.arange(al.shape[1])[None, :] - (al.shape[1] * (2 * since / .3 - .5))) / 18) ** 2) * (0 < since < .35)
            col = CREAM * b + (ed * 60 * moving)[..., None] + (sweep * 70)[..., None]
            seam = ed * (1 - smooth(.08, .45, since)) * (not moving)
            col = col * (1 - .6 * seam[..., None])
            R = bg[ay0:ay1, ax0:ax1]; bg[ay0:ay1, ax0:ax1] = R * (1 - al[..., None]) + np.clip(col, 0, 255) * al[..., None]
        return bg

    def sound(s):
        n = int(DUR * SR); b = np.zeros(n); tm = T0 + np.arange(n) / SR; fl = np.zeros(n)
        for p in s.pl:
            t0 = p['TL'] - .42; fl += (tm >= t0) & (tm < p['TL'] - .10)
            c = tt(.03); put(b, p['TL'], bp(noise(len(c)), 1800, 6000) * np.exp(-c / .004) + np.sin(2 * np.pi * 150 * c) * np.exp(-c / .012) * .7, rng.uniform(.2, .4))
            c = tt(.02); put(b, p['TL'] - .26, bp(noise(len(c)), 900, 3000) * np.exp(-c / .005), .15)
        ph = np.cumsum(140 + 14 * fl) / SR * 2 * np.pi
        b += lp(np.sign(np.sin(ph)) * .5 + np.sin(2 * ph) * .3, 1600) * np.clip(fl / 20, 0, 1) * .22
        return b


# =================== 7. РАЗРЕЗ → 3 ВЕЩИ ===================
class Slice(Base):
    S0, S1, SP, SW, SWD = 1.42, 1.54, 1.56, 1.88, .22
    p0, p1 = np.array([230., 425.]), np.array([870., 198.])

    def __init__(s):
        d = s.p1 - s.p0; s.u = d / np.hypot(*d); s.n = np.array([-s.u[1], s.u[0]])
        sd = (XX - s.p0[0]) * s.n[0] + (YY - s.p0[1]) * s.n[1]
        s.top = (A1 * (sd < 0)).astype(np.float32); s.bot = (A1 * (sd >= 0)).astype(np.float32)
        g3, gv = glyph('3', LAT), glyph('ВЕЩИ', CYR)
        gv = cv2.resize(gv, (int(gv.shape[1] * g3.shape[0] / gv.shape[0]), g3.shape[0]))
        gc = np.concatenate([g3, np.zeros((g3.shape[0], int(g3.shape[0] * .12)), np.float32), gv], 1)
        th = 330; s.A3 = place(gc, min(940, int(gc.shape[1] * th / gc.shape[0] * SQ)), th, 150, 540)
        s.B1 = smooth(80, 110, YY) * (1 - smooth(505, 535, YY)); s.B2 = smooth(525, 548, YY) * (1 - smooth(748, 770, YY))

    def bar(s, q0, q1, th):
        m = np.zeros((H, W), np.float32); a = s.p0 + (s.p1 - s.p0) * q0; b = s.p0 + (s.p1 - s.p0) * q1
        poly = np.array([a + s.n * th, b + s.n * th, b - s.n * th, a - s.n * th], np.int32)
        cv2.fillPoly(m, [poly], 1.0, cv2.LINE_AA); return m

    @staticmethod
    def mv(img, dx, dy): return cv2.warpAffine(img, np.float32([[1, 0, dx], [0, 1, dy]]), (W, H))

    def frame(s, f, t, bg):
        k, sh = entry(t)
        if t < s.SP:
            bg = text_on(bg, vshift(A, sh) * k)
            if t >= s.S0:
                q = 1 - (1 - smooth(s.S0, s.S1, t)) ** 2
                bg = over(bg, CORAL, s.bar(0, q, 10))
                tip = s.p0 + (s.p1 - s.p0) * q
                g = np.exp(-((XX - tip[0]) ** 2 + (YY - tip[1]) ** 2) / (2 * 22 ** 2)) * (t < s.S1 + .02)
                bg = screen(bg, g[..., None] * 255)
            return bg
        e = smooth(s.SP, s.SP + .16, t); g = max(t - s.SP - .08, 0)
        fade = 1 - smooth(s.SP + .18, s.SP + .40, t)
        tp = s.mv(s.top, -s.u[0] * 46 * e - 30 * g, -s.u[1] * 46 * e + 1500 * g * g * .8) * fade
        bt = s.mv(s.bot, s.u[0] * 46 * e + 20 * g, s.u[1] * 46 * e + 1500 * g * g) * fade
        if t < s.SW:
            r2 = A2; r1 = np.maximum(tp, bt)
        else:
            u = min((t - s.SW) / s.SWD, 1.0); ee = 1 - (1 - u) ** 3
            bump = 1 + .06 * np.sin(min((t - s.SW - s.SWD) / .12, 1) * np.pi) * (t > s.SW + s.SWD)
            bl = 1 + int(70 * np.sin(np.pi * u))
            r1 = cv2.blur(vshift(s.A3, -440 * (1 - ee) * bump), (1, bl)) * s.B1
            r2 = cv2.blur(vshift(A2, -230 * ee), (1, bl)) * s.B2
        bg = text_on(bg, np.clip(np.maximum(r1, r2), 0, 1))
        v = smooth(s.SP, s.SP + .16, t)
        if v < 1: bg = over(bg, CORAL, s.bar(.5 * v, 1 - .5 * v, 10 * (1 - v)) * (1 - v))
        fl = np.exp(-(t - s.SP) / .05)
        if fl > .02: bg = screen(bg, (s.bar(0, 1, 2) * fl)[..., None] * 255)
        return bg

    def sound(s):
        b = np.zeros(int(DUR * SR)); put(b, APPEAR, thock())
        t = tt(.14); put(b, s.S0, hp(noise(len(t)), 3500) * (t / t[-1]) * 1.2)
        t = tt(.6); put(b, s.SP, np.sin(2 * np.pi * 3200 * t) * np.exp(-t / .18) * .5 + noise(len(t)) * np.exp(-t / .01) * .6)
        put(b, s.SP + .1, swell(.3, 300, 2500, up=False), .6)
        for i in range(9):
            c = tt(.012); put(b, s.SW + i * s.SWD / 9, bp(noise(len(c)), 2000, 6000) * np.exp(-c / .003), .8)
        put(b, s.SW + s.SWD, thock(), 1.2)
        return b


# =================== 8. МАРКЕР ===================
def trace_paths(sk):
    pts = set(zip(*np.nonzero(sk)))
    def nb(p):
        y, x = p; return [(y + a, x + b) for a in (-1, 0, 1) for b in (-1, 0, 1) if (a or b) and (y + a, x + b) in pts]
    deg = {p: len(nb(p)) for p in pts}; used = set(); paths = []
    while len(used) < len(pts):
        free = [p for p in pts if p not in used]
        ends = [p for p in free if deg[p] == 1 or len([q for q in nb(p) if q not in used]) <= 1]
        st = min(ends or free, key=lambda p: (p[0] + .3 * p[1]))
        path = [st]; used.add(st); cur, prev = st, None
        while True:
            nx = [q for q in nb(cur) if q not in used]
            if not nx: break
            if prev is not None and len(nx) > 1:
                d = (cur[0] - prev[0], cur[1] - prev[1]); nx.sort(key=lambda q: -((q[0] - cur[0]) * d[0] + (q[1] - cur[1]) * d[1]))
            prev, cur = cur, nx[0]; path.append(cur); used.add(cur)
            if deg[cur] >= 3 and len(path) > 6: break
        if len(path) >= 8: paths.append(np.array(path, float))
    return paths


def smooth_path(p, sp=2.5):
    if len(p) > 9:
        k = np.ones(7) / 7; p = np.c_[np.convolve(np.pad(p[:, 0], 3, 'edge'), k, 'valid'), np.convolve(np.pad(p[:, 1], 3, 'edge'), k, 'valid')]
    d = np.r_[0, np.cumsum(np.hypot(*np.diff(p, axis=0).T))]
    if d[-1] < 1: return p
    q = np.linspace(0, d[-1], max(2, int(d[-1] / sp)))
    return np.c_[np.interp(q, d, p[:, 0]), np.interp(q, d, p[:, 1])]


class Marker2(Base):
    ROWS = ((1, .72, 1.24), (2, 1.30, 2.00))

    def __init__(s):
        from skimage.morphology import skeletonize
        dtm = ndimage.distance_transform_edt(A > .5)
        s.strokes = []
        for row, t0, t1 in s.ROWS:
            cells = comps(A1 if row == 1 else A2); items = []
            for c in cells:
                sk = skeletonize(c['m'] > .5); ps = trace_paths(sk)
                ps.sort(key=lambda p: (p[:, 0].min() // 40, p[:, 1].min()))
                ang = np.radians(rng.uniform(-2.5, 2.5)); offs = rng.normal(0, 4, 2); ctr = np.array([c['h'] / 2, c['w'] / 2])
                R = np.array([[np.cos(ang), -np.sin(ang)], [np.sin(ang), np.cos(ang)]])
                for p in ps:
                    if abs(p[-1, 0] - p[0, 0]) > abs(p[-1, 1] - p[0, 1]):
                        if p[0, 0] > p[-1, 0]: p = p[::-1]
                    elif p[0, 1] > p[-1, 1]: p = p[::-1]
                    gy, gx = (p[:, 0] + c['y0']).astype(int), (p[:, 1] + c['x0']).astype(int)
                    rad = dtm[np.clip(gy, 0, H - 1), np.clip(gx, 0, W - 1)] * 1.05
                    q = (p - ctr) @ R.T + ctr + offs + [c['y0'], c['x0']]
                    q = smooth_path(q); rq = np.interp(np.linspace(0, 1, len(q)), np.linspace(0, 1, len(rad)), rad)
                    nrm = np.gradient(q, axis=0); nrm = np.c_[-nrm[:, 1], nrm[:, 0]] / (np.hypot(*nrm.T)[:, None] + 1e-6)
                    q = q + nrm * (fbm(2, len(q) + 8, (12, 30), (1, .5), int(rng.integers(1e6)))[0, :len(q), None] - .5) * 3
                    items.append(dict(p=q, r=rq, L=len(q)))
                items.append('LETTER')
            nat_t = sum(it['L'] for it in items if it != 'LETTER') / 1.0
            gaps = sum((rng.uniform(.02, .045) if it != 'LETTER' else rng.uniform(.035, .07)) for it in items)
            sc = (t1 - t0 - gaps) / nat_t; cur = t0
            for it in items:
                if it == 'LETTER': cur += rng.uniform(.035, .07); continue
                d = it['L'] * sc; it['t0'] = cur; it['d'] = d; cur += d + rng.uniform(.02, .045)
                tau = np.linspace(0, 1, it['L']); it['ts'] = cur - d - rng.uniform(.02, .045) * 0 + 0
                it['tt'] = it['t0'] + d * np.interp(tau, tau - np.sin(2 * np.pi * tau) / (2 * np.pi), tau)
                pr = .86 + .14 * np.sin(np.pi * tau) + rng.normal(0, .03, it['L'])
                it['r'] = it['r'] * pr; s.strokes.append(it)
        s.D = np.zeros((H, W), np.float32); s.last = -1.0
        s.disk = {r: cv2.circle(np.zeros((2 * r + 3, 2 * r + 3), np.float32), (r + 1, r + 1), r, 1.0, -1, cv2.LINE_AA) for r in range(1, 60)}
        s.tex = (.84 + .16 * fbm(H, W, (2, 5), (1, .5), 91, stretch=.35))

    def tip(s, t):
        st = s.strokes
        for i, it in enumerate(st):
            if it['t0'] <= t <= it['t0'] + it['d']:
                j = np.searchsorted(it['tt'], t); return it['p'][min(j, it['L'] - 1)][::-1], 0.0
            nxt = st[i + 1] if i + 1 < len(st) else None
            if nxt and it['t0'] + it['d'] < t < nxt['t0']:
                u = (t - it['t0'] - it['d']) / (nxt['t0'] - it['t0'] - it['d'])
                a, b = it['p'][-1][::-1], nxt['p'][0][::-1]; return a + (b - a) * u, np.sin(np.pi * u)
        if t < st[0]['t0']:
            u = smooth(.55, st[0]['t0'], t); a = np.array([1180., -120.]); return a + (st[0]['p'][0][::-1] - a) * u, 1 - u
        u = smooth(st[-1]['t0'] + st[-1]['d'], st[-1]['t0'] + st[-1]['d'] + .35, t); a = st[-1]['p'][-1][::-1]
        return a + (np.array([1180., -120.]) - a) * u, u

    def frame(s, f, t, bg):
        for it in s.strokes:
            m = (it['tt'] > s.last) & (it['tt'] <= t)
            for j in np.nonzero(m)[0]:
                y, x = it['p'][j]; r = int(np.clip(round(it['r'][j]), 1, 59)); kd = s.disk[r]
                y0, x0 = int(y) - r - 1, int(x) - r - 1
                if 0 <= y0 and 0 <= x0 and y0 + kd.shape[0] < H and x0 + kd.shape[1] < W:
                    s.D[y0:y0 + kd.shape[0], x0:x0 + kd.shape[1]] += kd * .45
        s.last = t
        a = (1 - np.exp(-2.4 * s.D)) * s.tex
        bg = text_on(bg, a, CREAM * (.97 + .03 * s.tex[..., None]))
        (tx, ty), lift = s.tip(t)
        if -50 < tx < W + 200:
            body = np.zeros((H, W), np.float32); dx, dy = 90, -150
            shd = np.zeros((H, W), np.float32); so = 22 + 35 * lift
            cv2.line(shd, (int(tx + so), int(ty + so)), (int(tx + so + dx), int(ty + so + dy)), 1.0, 30, cv2.LINE_AA)
            bg = bg * (1 - cv2.GaussianBlur(shd, (0, 0), 9)[..., None] * .35)
            cv2.line(body, (int(tx + 6), int(ty - 10)), (int(tx + dx), int(ty + dy)), 1.0, 30, cv2.LINE_AA)
            bg = over(bg, np.array([38, 38, 44], np.float32), body)
            hl = np.zeros((H, W), np.float32); cv2.line(hl, (int(tx + 2), int(ty - 18)), (int(tx + dx - 8), int(ty + dy - 6)), 1.0, 4, cv2.LINE_AA)
            bg = over(bg, np.array([120, 120, 130], np.float32), hl * .6)
            tp = np.zeros((H, W), np.float32); cv2.circle(tp, (int(tx), int(ty)), 9, 1.0, -1, cv2.LINE_AA)
            bg = over(bg, CREAM, tp)
        return bg

    def sound(s):
        b = np.zeros(int(DUR * SR))
        for it in s.strokes:
            t = tt(it['d']); e = np.sin(np.pi * np.clip(t / it['d'], 0, 1)) ** .7
            put(b, it['t0'], (bp(noise(len(t)), 1800, 4500) * (1 + .4 * np.sin(2 * np.pi * rng.uniform(18, 30) * t)) * .55 + bp(noise(len(t)), 300, 900) * .3) * e)
            c = tt(.01); put(b, it['t0'], bp(noise(len(c)), 1000, 4000) * np.exp(-c / .002), .3)
        return b


# =================== 10. МОЛНИЯ ===================
def fractal(p0, p1, r, depth=0, inten=1.0, out=None):
    out = [] if out is None else out
    L = np.hypot(*(np.array(p1) - p0)); pts = bolt(p0, p1, L * .16, 7 - depth, r).astype(float)
    out.append((pts.astype(np.int32), max(1, 5 - 2 * depth), inten))
    if depth < 2:
        for i in r.choice(len(pts) - 2, r.integers(2, 6 - depth), replace=False):
            d = pts[min(i + 3, len(pts) - 1)] - pts[i]; a = np.arctan2(d[1], d[0]) + r.choice([-1, 1]) * r.uniform(.35, .9)
            ln = L * r.uniform(.15, .4) * (1 - i / len(pts))
            fractal(pts[i], pts[i] + ln * np.array([np.cos(a), np.sin(a)]), r, depth + 1, inten * .55, out)
    return out


class Light2(Base):
    P = np.array([600., 290.])
    FR = {0: 1.0, 1: .85, 3: .5, 4: 1.0, 6: .35}

    def __init__(s):
        e = (A > .5).astype(np.uint8); ys, xs = np.nonzero(e - cv2.erode(e, np.ones((3, 3), np.uint8)))
        s.E = np.c_[xs, ys].astype(float); s.kd = cKDTree(s.E)
        s.TS = HIT; s.AG = np.zeros((H, W), np.float32)
        sc = fbm(H, W, (8, 20, 45), (1, .6, .3), 101)
        d = np.hypot(XX - s.P[0], YY - s.P[1])
        s.SC = (np.clip((1 - d / 200) * 1.6 + (sc - .5) * 1.2, 0, 1) * (A > .3)).astype(np.float32)
        s.sp = []; s.sm = np.zeros((H // 2, W // 2), np.float32); s.YS, s.XS = np.mgrid[0:H // 2, 0:W // 2].astype(np.float32)
        s.CN = fbm(H // 2 + 2400, W // 2, (5, 11, 24), (1, .6, .35), 102, stretch=1.6)

    def strike(s, f):
        idx = f - round((s.TS - T0) * FPS); return s.FR.get(idx, 0.0)

    def shake(s, t):
        f = round((t - T0) * FPS); a = sum(9 * v * np.exp(-max(0, (f - (round((s.TS - T0) * FPS) + i))) / 2.5) for i, v in s.FR.items() if f >= round((s.TS - T0) * FPS) + i)
        if a <= .2: return 0, 0
        r = np.random.default_rng(f); return r.normal(0, a), r.normal(0, a)

    def frame(s, f, t, bg):
        r = np.random.default_rng(f + 300)
        k, sh = entry(t); a = vshift(A, sh) * k
        ch = smooth(1.05, 1.45, t) * (t < s.TS) + (t >= s.TS) * .35 * (1 - smooth(s.TS + .2, s.TS + .7, t))
        flick = .75 + .25 * r.random()
        col = CREAM + (np.array([200, 225, 255]) - CREAM) * ch * .6 * flick
        sc = s.SC * smooth(s.TS, s.TS + .05, t)
        col = col * (1 - .7 * sc[..., None]) + np.array([20, 14, 10]) * .7 * sc[..., None]
        bg = text_on(bg, a, col)
        G = np.zeros((H, W), np.float32)
        for _ in range(int(26 * ch * (.6 + .8 * r.random()))):
            p = s.E[r.integers(len(s.E))]
            if r.random() < .7:
                cand = s.kd.query_ball_point(p, 160); q = s.E[cand[r.integers(len(cand))]] if cand else p + r.normal(0, 60, 2)
            else: q = p + r.normal(0, 1, 2) * r.uniform(40, 140)
            if np.hypot(*(q - p)) < 25: continue
            for pts, w, it in fractal(p, q, r, 2, r.uniform(.4, 1)): cv2.polylines(G, [pts], False, it, 1 if w < 3 else 2, cv2.LINE_AA)
        v = s.strike(f)
        if v > 0:
            rr = np.random.default_rng(11 + (f % 2))
            for pts, w, it in fractal(np.array([660., -30.]), s.P, rr): cv2.polylines(G, [pts], False, it * v, w + 1, cv2.LINE_AA)
            for _ in range(int(120 * v)): s.sp.append([s.P[0], s.P[1], r.normal(0, 380), -r.uniform(100, 700), r.uniform(.3, .9), 0.])
        s.AG = np.maximum(s.AG * .62, G * (v > 0))
        Gt = np.maximum(G, s.AG * .7)
        sp = np.zeros((H, W), np.float32)
        for q in s.sp:
            x0, y0 = q[0], q[1]; q[0] += q[2] / FPS; q[1] += q[3] / FPS; q[3] += 1400 / FPS; q[5] += 1 / FPS
            cv2.line(sp, (int(x0), int(y0)), (int(q[0]), int(q[1])), max(0, 1 - q[5] / q[4]), 2, cv2.LINE_AA)
        s.sp[:] = [q for q in s.sp if q[5] < q[4]]
        add = Gt[..., None] * 255 + cv2.GaussianBlur(Gt, (0, 0), 3)[..., None] * np.array([150, 195, 255]) * 1.6 \
            + cv2.GaussianBlur(Gt, (0, 0), 12)[..., None] * np.array([95, 140, 255]) * 1.3 + cv2.GaussianBlur(Gt, (0, 0), 45)[..., None] * np.array([70, 100, 255]) * .9 \
            + cv2.GaussianBlur(a * ch * flick, (0, 0), 10)[..., None] * np.array([80, 140, 255]) * .55 \
            + (sp[..., None] + cv2.GaussianBlur(sp, (0, 0), 3)[..., None] * 1.4) * np.array([255, 210, 150])
        if v > .6: add = add + (v - .4) * (np.array([150, 170, 230]) * .28 + (1 - YY / H)[..., None] * np.array([60, 70, 110]) * .6)
        bg = screen(bg, add)
        if t >= s.TS:
            h2 = H // 2
            for sub in range(2):
                g = f * 2 + sub; cs = (g * 5) % (s.CN.shape[0] - h2); cn = s.CN[cs:cs + h2]
                s.sm[:] = cv2.remap(s.sm, s.XS + (cn - .5) * 14, s.YS + 2.4 + 1.5 * cn, cv2.INTER_LINEAR, borderValue=0)
                s.sm *= 1 - (.015 + .05 * cn ** 2)
                src = cv2.GaussianBlur(cv2.resize(sc, (W // 2, h2)), (0, 0), 3) * smooth(.45, .8, cn) * (1 - smooth(s.TS + .4, s.TS + 1.0, t))
                np.maximum(s.sm, src * .7, out=s.sm)
            dens = cv2.GaussianBlur(np.clip(cv2.resize(s.sm, (W, H)), 0, 1), (0, 0), 4)
            bg = over(bg, np.array([120, 118, 120], np.float32), np.clip(dens * .6, 0, .35))
        return bg

    def sound(s):
        b = np.zeros(int(DUR * SR)); put(b, APPEAR, thock())
        tc = 1.05
        while tc < 2.2:
            c = tt(rng.uniform(.003, .02)); lvl = smooth(1.05, 1.45, tc) * (tc < s.TS) + (tc >= s.TS) * .6 * (1 - smooth(s.TS + .2, s.TS + .7, tc))
            put(b, tc, bp(noise(len(c)), 1500, 8000) * rng.uniform(0, 1) ** 1.5, .7 * lvl); tc += rng.exponential(.012)
        for i, v in s.FR.items():
            t = tt(.25); put(b, s.TS + i / FPS, hp(noise(len(t)), 700) * np.exp(-t / .025) * 2.2 * v)
        t = tt(1.6); put(b, s.TS, lp(noise(len(t)), 130) * np.exp(-t / .6) * smooth(0, .05, t) * 5)
        return b


# =================== 15. ТАБЛО ===================
class Flap2(Base):
    def __init__(s):
        pool = list('0123456789') + list('АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЭЮЯ')
        c1, c2 = comps(A1), comps(A2); s.cells = []
        for ci, c in enumerate(c1 + c2):
            TW, TH = c['w'] + 32, c['h'] + 40
            tile = np.zeros((TH, TW, 3), np.float32); yy = np.arange(TH)[:, None]
            tile[:] = np.where(yy < TH // 2, 40 - 8 * yy / TH, 31 - 10 * (yy - TH / 2) / TH)[..., None] * np.array([1, 1, 1.08])
            tile += (fbm(TH, TW, (3, 8), (1, .5), 200 + ci)[..., None] - .5) * 6
            tile[1:3] += 22
            ta = np.zeros((TH, TW), np.float32); cv2.rectangle(ta, (2, 2), (TW - 3, TH - 3), 1.0, -1); ta = cv2.GaussianBlur(ta, (0, 0), 1.5)
            n = (8 + ci * 2) if ci < len(c1) else (9 + (ci - len(c1)))
            seq = []
            for j in range(n):
                ch = pool[rng.integers(len(pool))]; g = cv2.resize(glyph(ch, LAT if ch.isdigit() else CYR), (c['w'], c['h']), interpolation=cv2.INTER_AREA)
                seq.append(g)
            seq.append(c['m'])
            imgs = []
            for g in seq:
                im = tile.copy(); oy, ox = 20 + rng.integers(-1, 2), 16 + rng.integers(-1, 2)
                gg = np.zeros((TH, TW), np.float32); gg[oy:oy + c['h'], ox:ox + c['w']] = g
                im = im * (1 - gg[..., None]) + CREAM * gg[..., None]
                im[TH // 2 - 2:TH // 2 + 2] *= .25
                imgs.append(np.dstack([im, ta]))
            iv = [.055] * (len(imgs) - 4) + [.075, .095, .125]
            ts = [.80 + rng.uniform(0, .06)]
            for x in iv: ts.append(ts[-1] + x)
            s.cells.append(dict(imgs=imgs, ts=ts, x=c['x0'] - 16 + rng.integers(-2, 3), y=c['y0'] - 20 + rng.integers(-2, 3), TW=TW, TH=TH))

    @staticmethod
    def half_warp(img, top, th, TW, TH):
        m = TH // 2; ext = .15 * np.sin(th)
        if top:
            src = np.float32([[0, 0], [TW, 0], [TW, m], [0, m]]); hgt = m * np.cos(th)
            dst = np.float32([[-TW * ext / 2, m - hgt], [TW * (1 + ext / 2), m - hgt], [TW, m], [0, m]])
            part = img[:m]
        else:
            src = np.float32([[0, 0], [TW, 0], [TW, TH - m], [0, TH - m]]); hgt = (TH - m) * abs(np.cos(th))
            dst = np.float32([[0, m], [TW, m], [TW * (1 + ext / 2), m + hgt], [-TW * ext / 2, m + hgt]])
            part = img[m:]
        Mp = cv2.getPerspectiveTransform(src, dst)
        return cv2.warpPerspective(part, Mp, (TW, TH), flags=cv2.INTER_LINEAR)

    def cell_img(s, c, t):
        imgs, ts = c['imgs'], c['ts']; TW, TH = c['TW'], c['TH']; m = TH // 2
        i = int(np.searchsorted(ts, t, 'right')) - 1
        if i < 0: return imgs[0]
        if i >= len(imgs) - 1: return imgs[-1]
        p = (t - ts[i]) / .05
        O, Nn = imgs[i], imgs[i + 1]
        if p >= 1: return Nn if i + 1 < len(imgs) else O
        th = p * np.pi; out = np.zeros_like(O); out[:m] = Nn[:m]; out[m:] = O[m:]
        if th < np.pi / 2:
            fl = s.half_warp(O, True, th, TW, TH); fl[..., :3] *= .55 + .45 * np.cos(th)
        else:
            fl = s.half_warp(Nn, False, th, TW, TH); fl[..., :3] *= .55 + .45 * abs(np.cos(th))
            out[m:, :, :3] *= 1 - .5 * np.sin(th)
        a = fl[..., 3:4]; out[..., :3] = out[..., :3] * (1 - a) + fl[..., :3] * a; out[..., 3] = np.maximum(out[..., 3], fl[..., 3])
        return out

    def frame(s, f, t, bg):
        k, sh = entry(t)
        Ts = np.zeros((H, W), np.float32); parts = []
        for c in s.cells:
            im = s.cell_img(c, t); y = c['y'] + sh; x = c['x']
            Ts[y:y + c['TH'], x:x + c['TW']] = np.maximum(Ts[y:y + c['TH'], x:x + c['TW']], im[..., 3])
            parts.append((x, y, im))
        bg = shadow(bg, Ts * k, k=.65)
        for x, y, im in parts:
            R = bg[y:y + im.shape[0], x:x + im.shape[1]]; a = im[..., 3:4] * k
            bg[y:y + im.shape[0], x:x + im.shape[1]] = R * (1 - a) + im[..., :3] * a
        return bg

    def sound(s):
        b = np.zeros(int(DUR * SR))
        for c in s.cells:
            for j, tc in enumerate(c['ts'][:len(c['imgs']) - 1]):
                last = j == len(c['imgs']) - 2
                cl = tt(.012); put(b, tc + .045, bp(noise(len(cl)), 2000, 6500) * np.exp(-cl / .0025), rng.uniform(.25, .45) * (1.6 if last else 1))
                bd = tt(.03); put(b, tc + .045, bp(noise(len(bd)), 250, 900) * np.exp(-bd / .008), .35 * (1.8 if last else 1))
        return b


# =================== 17. ФОНАРИК ===================
class Flash2(Base):
    LON = 1.80
    KEYS = np.array([(.50, -260, 720), (.82, 230, 380), (1.06, 500, 300), (1.24, 610, 300), (1.50, 850, 640), (1.80, 1010, 620), (2.1, 1300, 600)])

    def __init__(s):
        s.dx, s.dy = rng.uniform(0, W, 500), rng.uniform(0, 1150, 500); s.dph = rng.uniform(0, 6.28, 500)
        s.rows = [(A1, np.array([548., 307.])), (A2, np.array([540., 647.]))]

    def pos(s, t):
        K = s.KEYS; t = np.clip(t, K[0, 0], K[-1, 0]); i = min(max(np.searchsorted(K[:, 0], t) - 1, 0), len(K) - 2)
        p = [K[max(i - 1, 0), 1:], K[i, 1:], K[i + 1, 1:], K[min(i + 2, len(K) - 1), 1:]]
        u = (t - K[i, 0]) / (K[i + 1, 0] - K[i, 0])
        return .5 * ((2 * p[1]) + (-p[0] + p[2]) * u + (2 * p[0] - 5 * p[1] + 4 * p[2] - p[3]) * u * u + (-p[0] + 3 * p[1] - 3 * p[2] + p[3]) * u ** 3)

    def room(s, t):
        d = t - s.LON
        if d < 0: return 0.0
        if d < .067: return .9
        if d < .133: return .2
        if d < .167: return .8
        if d < .233: return .25
        return min(1.0, .7 + .3 * smooth(.233, .40, d)) * (.985 + .015 * np.sin(t * 2 * np.pi * 50))

    def frame(s, f, t, bg):
        lr = s.room(t); on = 1 - smooth(s.LON, s.LON + .25, t)
        c = s.pos(t) + np.array([4 * np.sin(t * 17) + 3 * np.sin(t * 23.7), 3 * np.sin(t * 19.3)])
        r = np.sqrt(((XX - c[0]) / 1.12) ** 2 + (YY - c[1]) ** 2)
        spot = (.55 * np.exp(-(r / 85) ** 2) + .8 * (1 - smooth(170, 255, r)) + .12 * np.exp(-((r - 300) / 30) ** 2)) * on
        for Ar, cen in s.rows:
            v = cen - c; dist = np.hypot(*v); off = v / (dist + 1) * min(34, 8 + dist * .05)
            shd = cv2.GaussianBlur(cv2.warpAffine(Ar, np.float32([[1, 0, off[0]], [0, 1, off[1]]]), (W, H)), (0, 0), 3)
            si = float(np.clip((.55 * np.exp(-(np.hypot(*((cen - c) / [1.12, 1])) / 85) ** 2) + .8 * (1 - smooth(170, 255, np.hypot(*((cen - c) / [1.12, 1]))))) * on, 0, 1))
            bg = bg * (1 - (shd * .7 * max(si, .25))[..., None])
        bg = shadow(bg, A, k=.5 * lr)
        bg = over(bg, CREAM, A)
        base = .14 + .86 * lr
        Lm = base + (1 - base) * np.clip(spot, 0, 1.3)
        tint = np.array([1.0, .97, .9]) * (1 - lr) + np.array([1.0, 1.0, 1.0]) * lr
        bg = bg * Lm[..., None] * tint
        px = s.dx + 8 * np.sin(t * .8 + s.dph); py = s.dy + 6 * np.sin(t * .6 + s.dph * 1.3) - 10 * t
        ix, iy = np.clip(px.astype(int), 0, W - 1), np.clip(py.astype(int), 0, H - 1)
        cnt, _ = splat(px, py, np.clip(spot[iy, ix], 0, 1) * .9, np.ones(500), 1.1)
        return screen(bg, np.clip(cnt, 0, 1)[..., None] * 200)

    def sound(s):
        b = np.zeros(int(DUR * SR))
        c = tt(.03); put(b, .46, bp(noise(len(c)), 1000, 6000) * np.exp(-c / .004) * 1.2 + np.sin(2 * np.pi * 180 * c) * np.exp(-c / .01) * .5)
        put(b, s.LON - .02, bp(noise(len(c)), 800, 5000) * np.exp(-c / .005) * 1.4)
        for dt_ in (0, .133, .233):
            p = tt(.06); put(b, s.LON + dt_, np.sin(2 * np.pi * 4200 * p) * np.exp(-p / .012) * .4)
        t = tt(1.0); put(b, s.LON + .25, (np.sin(2 * np.pi * 100 * t) * .12 + np.sin(2 * np.pi * 200 * t) * .06) * smooth(0, .2, t))
        return b


FX3 = dict(dust2=Dust2, trans=Trans, slice=Slice, marker2=Marker2, light2=Light2, flap2=Flap2, flash2=Flash2)
fx.FX.update(FX3)

if __name__ == '__main__':
    fx.run(sys.argv[1], sys.argv[2])
