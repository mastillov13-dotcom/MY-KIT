"""Цветокоррекция «мягкий свет + отделение от фона» (по референсу Леха_видос1).

Человек вырезается маской (u2net_human_seg), дальше:
  фон  — темнее (−0,7 EV), чуть менее насыщенный и холоднее: уходит назад, как в референсе;
  человек — мягкий ключевой свет: подняты тени, мягкий скат светов, лёгкое свечение, тёплая кожа;
  общее — мягкая плёночная кривая и виньетка.
Использование: python3 grade.py in.mp4 out.mp4 [--preview t1,t2,... out.jpg] [--strength 1.0]
"""
import subprocess
import sys

import cv2
import numpy as np
import onnxruntime as ort

MODEL = '/home/claude/models/u2net_human_seg.onnx'
sess = ort.InferenceSession(MODEL, providers=['CPUExecutionProvider'])
P = dict(bg_ev=-0.95, bg_sat=0.78, bg_cool=0.05, sub_lift=0.10, sub_warm=0.03, glow=0.14, vign=0.28)


def mask_of(rgb):
    x = cv2.resize(rgb, (320, 320), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    x = (x - [0.485, 0.456, 0.406]) / [0.229, 0.224, 0.225]
    m = sess.run(None, {'input.1': x.transpose(2, 0, 1)[None].astype(np.float32)})[0][0, 0]
    m = (m - m.min()) / (m.max() - m.min() + 1e-6)
    m = cv2.resize(m, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_LINEAR)
    m = np.clip((m - 0.35) / 0.4, 0, 1)
    m = cv2.erode(m, np.ones((5, 5), np.uint8))           # без ореола: край маски внутрь
    return cv2.GaussianBlur(m, (0, 0), 4)


_VIG = {}


def vignette(h, w, k):
    if (h, w, k) not in _VIG:
        yy, xx = np.mgrid[0:h, 0:w]
        r = np.sqrt(((xx - w / 2) / (w / 2)) ** 2 + ((yy - h * 0.42) / (h / 2)) ** 2)
        _VIG[(h, w, k)] = (1 - P['vign'] * k * np.clip(r - 0.55, 0, 1) ** 1.5)[..., None].astype(np.float32)
    return _VIG[(h, w, k)]


def grade(rgb, m, k=1.0):
    f = rgb.astype(np.float32) / 255
    lin = f ** 2.2
    # фон
    bg = lin * (2 ** (P['bg_ev'] * k))
    g = bg.mean(axis=2, keepdims=True)
    bg = g + (bg - g) * (1 - (1 - P['bg_sat']) * k)
    bg = bg * np.array([1 - P['bg_cool'] * k, 1, 1 + P['bg_cool'] * 0.6 * k])
    # человек: мягкий ключ
    lum = lin.mean(axis=2, keepdims=True)
    sub = lin * (1 + P['sub_lift'] * k * (1 - np.clip(lum * 1.6, 0, 1)))   # подъём только теней и полутонов (лицо)
    sub = sub / (1 + sub * 0.45 * k) * (1 + 0.45 * k * 0.55)              # мягкий скат светов (белая футболка не горит)
    sub = sub * np.array([1 + P['sub_warm'] * k, 1 + P['sub_warm'] * 0.4 * k, 1 - P['sub_warm'] * 0.5 * k])
    out = sub * m[..., None] + bg * (1 - m[..., None])
    out = np.clip(out, 0, 1) ** (1 / 2.2)
    # мягкое свечение светов (как рассеянный свет)
    hi = np.clip((out - 0.6) / 0.4, 0, 1)
    small = cv2.resize(hi, (hi.shape[1] // 4, hi.shape[0] // 4), interpolation=cv2.INTER_AREA)
    glow = cv2.resize(cv2.GaussianBlur(small, (0, 0), 6), (hi.shape[1], hi.shape[0]), interpolation=cv2.INTER_LINEAR)
    out = 1 - (1 - out) * (1 - glow * P['glow'] * k)
    # тени чуть приподняты, контраст мягче (плёночная кривая)
    out = 0.03 + out * 0.95
    out = out + 0.06 * k * np.sin(np.pi * out) * (out - 0.5)
    # виньетка
    out = out * vignette(out.shape[0], out.shape[1], k)
    return (np.clip(out, 0, 1) * 255 + 0.5).astype(np.uint8)


def frames(path, w, h, ss=None):
    cmd = ['ffmpeg', '-v', 'error'] + (['-ss', str(ss)] if ss is not None else []) + ['-i', path, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-']
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    while True:
        b = p.stdout.read(w * h * 3)
        if len(b) < w * h * 3:
            break
        yield np.frombuffer(b, np.uint8).reshape(h, w, 3)
        if ss is not None:
            p.kill(); break


def main():
    src, dst = sys.argv[1], sys.argv[2]
    k = float(sys.argv[sys.argv.index('--strength') + 1]) if '--strength' in sys.argv else 1.0
    w, h = map(int, subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v', '-show_entries',
                                             'stream=width,height', '-of', 'csv=p=0', src]).decode().split(','))
    if '--preview' in sys.argv:
        ts = [float(t) for t in sys.argv[sys.argv.index('--preview') + 1].split(',')]
        rows = []
        for t in ts:
            f = next(frames(src, w, h, t))
            g = grade(f, mask_of(f), k)
            rows.append(np.hstack([cv2.resize(f, (w // 3, h // 3)), cv2.resize(g, (w // 3, h // 3))]))
        cv2.imwrite(dst, cv2.cvtColor(np.hstack(rows), cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 90])
        return
    fps = subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v', '-show_entries', 'stream=r_frame_rate',
                                   '-of', 'csv=p=0', src]).decode().strip()
    enc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{w}x{h}', '-r', fps, '-i', '-',
                            '-i', src, '-map', '0:v', '-map', '1:a', '-c:v', 'libx264', '-crf', '16', '-preset', 'medium',
                            '-g', '30', '-pix_fmt', 'yuv420p', '-c:a', 'copy', dst], stdin=subprocess.PIPE)
    prev = None
    for i, f in enumerate(frames(src, w, h)):
        m = mask_of(f) if i % 2 == 0 or prev is None else prev      # маска через кадр + сглаживание во времени
        m = m if prev is None else 0.6 * m + 0.4 * prev
        prev = m
        enc.stdin.write(grade(f, m, k).tobytes())
    enc.stdin.close(); enc.wait()


main()
