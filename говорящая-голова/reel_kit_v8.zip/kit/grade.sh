#!/bin/sh
# Цветокоррекция по маске + слой «человек с прозрачностью».
# Использование: sh grade.sh cut.mp4 mask.mp4 graded.mp4 person.webm
# Фон: −0,95 EV, насыщенность 0,78, прохладнее. Человек: мягкий подъём теней и мягкий скат светов, чуть теплее.
IN=$1; MASK=$2; OUT=$3; PERSON=$4
ffmpeg -v error -y -i "$IN" -i "$MASK" -filter_complex "\
[1:v]scale=1080:1920:flags=bicubic,format=gray,gblur=sigma=3,split[m1][m2];\
[0:v]format=gbrp,split[a][b];\
[a]exposure=exposure=-0.95,eq=saturation=0.78,colorbalance=rs=-0.04:gs=-0.01:bs=0.03:rm=-0.03:bm=0.02,format=gbrp[bg];\
[b]curves=all='0/0.03 0.25/0.29 0.6/0.63 0.85/0.85 1/0.95',colorbalance=rm=0.02:gm=0.005:bm=-0.015,format=gbrp[fg];\
[m1]format=gbrp[mm];\
[bg][fg][mm]maskedmerge,vignette=angle=PI/5:mode=forward,format=yuv420p,split[o1][o2];\
[o2]format=yuva420p[oa];[m2]format=gray[ma];[oa][ma]alphamerge[p]" \
 -map "[o1]" -map 0:a -c:v libx264 -crf 16 -preset medium -g 30 -pix_fmt yuv420p -c:a copy "$OUT" \
 -map "[p]" -an -c:v libvpx-vp9 -pix_fmt yuva420p -b:v 5M -deadline realtime -cpu-used 8 -row-mt 1 -threads 2 "$PERSON"
