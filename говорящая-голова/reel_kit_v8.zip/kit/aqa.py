"""Сравнение громкости рендера и нарезки окнами 0.25 с: голос не пропал, эффекты не громче голоса."""
import subprocess, sys, numpy as np
def pcm(f):
    r = subprocess.run(['ffmpeg', '-v', 'error', '-i', f, '-ac', '1', '-ar', '16000', '-f', 's16le', '-'], capture_output=True).stdout
    return np.frombuffer(r, np.int16).astype(np.float32) / 32768
a, b = pcm('proj/cut.mp4'), pcm(sys.argv[1])
n = min(len(a), len(b)) // 4000
db = lambda x: 20 * np.log10(np.sqrt(np.mean(x ** 2)) + 1e-6)
lost, loud = [], []
for i in range(n):
    x, y = a[i*4000:(i+1)*4000], b[i*4000:(i+1)*4000]
    da, dbb = db(x), db(y)
    if da > -30 and dbb < da - 4: lost.append((i * .25, round(da, 1), round(dbb, 1)))
    if dbb > da + 4: loud.append((i * .25, round(da, 1), round(dbb, 1)))
print('voice lost:', lost); print('louder +4dB:', loud)
