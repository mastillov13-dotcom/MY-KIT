"""Данные для монтажа: подписи (фраза до 5 слов в 2 строки), окна без подписей,
слова промпта для чата, склейки. Использование: python3 build_data.py <проект> <hide.json>"""
import json
import sys

proj, hide_path = sys.argv[1], sys.argv[2]
cfg = json.load(open(hide_path, encoding='utf-8'))
edl = json.load(open('edl.json'))
words = json.load(open('words.json', encoding='utf-8'))
TOTAL = edl[-1]['out'][1]
HIDE = cfg['hide']
ACCENT = set(cfg['accent'])
SHORT = {'к', 'в', 'и', 'с', 'на', 'не', 'за', 'от', 'из', 'у', 'но', 'или', 'вы', 'тем', 'чем', 'что', 'как', 'а', 'о', 'для', 'без', 'его'}


def hidden(t):
    return any(a <= t < b for a, b in HIDE)


vis = [w for w in words if not hidden(w['s'])]
groups, cur = [], []
for i, w in enumerate(vis):
    cur.append(w)
    nxt = vis[i + 1] if i + 1 < len(vis) else None
    chars = sum(len(x['w']) for x in cur) + len(cur) - 1
    punct = w['w'][-1] in '.,?!»'
    gap = nxt is None or nxt['s'] - w['e'] > 0.35 or hidden((w['e'] + nxt['s']) / 2)
    nxt_chars = chars + 1 + len(nxt['w']) if nxt else 99
    limit = 36 if nxt and nxt['w'][-1] in '.,?!' else 28
    maxw = 5
    if cfg.get('mode') == 'short':
        limit, maxw = 17, 3
    if gap or (punct and chars >= (6 if maxw == 3 else 9)) or len(cur) == maxw or nxt_chars > limit:
        carry = []
        while len(cur) > 1 and not punct and not gap and cur[-1]['w'].lower() in SHORT:
            carry.insert(0, cur.pop())
        groups.append(cur)
        cur = carry
if cur:
    groups.append(cur)


def two_lines(g):
    if cfg.get('mode') == 'short':
        return [g]
    total = sum(len(x['w']) for x in g) + len(g) - 1
    if len(g) == 1 or total <= 14:
        return [g]
    best, bk = None, 1
    for k in range(1, len(g)):
        a = sum(len(x['w']) for x in g[:k]) + k - 1
        b = total - a - 1
        score = abs(a - b) + (40 if max(a, b) > 18 else 0) + (6 if g[k - 1]['w'].lower() in SHORT else 0)
        if best is None or score < best:
            best, bk = score, k
    return [g[:bk], g[bk:]]


caps = []
for i, g in enumerate(groups):
    nxt_s = groups[i + 1][0]['s'] if i + 1 < len(groups) else TOTAL
    end = min(nxt_s, g[-1]['e'] + 0.5)
    for a, b in HIDE:
        if g[0]['s'] < a < end:
            end = a
    caps.append({'s': round(g[0]['s'] - 0.03, 3), 'e': round(end - 0.02, 3),
                 'lines': [[{'t': x['w'].strip('«»'), 'a': x['w'] in ACCENT, 's': x['s']} for x in ln] for ln in two_lines(g)]})

caps = [c for c in caps if c['e'] - c['s'] >= 0.18]
pa, pb = cfg['prompt']
data = {'total': TOTAL, 'captions': caps,
        'prompt': [{'t': w['w'], 's': w['s']} for w in words if pa <= w['s'] < pb],
        'cuts': [p['out'][0] for p in edl[1:]],
        'w': {f"{w['w']}#{k}": w['s'] for k, w in enumerate(words)}}
open(f'{proj}/data.js', 'w', encoding='utf-8').write('window.REEL = ' + json.dumps(data, ensure_ascii=False) + ';\n')
for c in caps:
    print(f"{c['s']:6.2f}-{c['e']:6.2f}", ' / '.join(' '.join(('*' if w['a'] else '') + w['t'] for w in ln) for ln in c['lines']))
print('cuts', data['cuts'])
