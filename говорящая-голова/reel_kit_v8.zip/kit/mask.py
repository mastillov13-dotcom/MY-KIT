"""Маска человека для всего ролика — быстро.

Нейросеть (u2net_human_seg) считает маску на каждом 3-м кадре в малом разрешении,
между ними маска плавно интерполируется. Результат — серое видео-маска 540×960.
Дальше всё делает ffmpeg (grade.sh): цветокоррекция по маске и слой «человек с прозрачностью»
для текста и графики за спиной.

Использование: python3 mask.py cut.mp4 mask.mp4 [шаг=3]
"""
import subprocess
import sys

import cv2
import numpy as np
import onnxruntime as ort

src, dst = sys.argv[1], sys.argv[2]
STEP = int(sys.argv[3]) if len(sys.argv) > 3 else 3
W, H = 540, 960
sess = ort.InferenceSession('/home/claude/models/u2net_human_seg.onnx', providers=['CPUExecutionProvider'])


def infer(rgb):
    x = cv2.resize(rgb, (320, 320), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    x = (x - [0.485, 0.456, 0.406]) / [0.229, 0.224, 0.225]
    m = sess.run(None, {'input.1': x.transpose(2, 0, 1)[None].astype(np.float32)})[0][0, 0]
    m = (m - m.min()) / (m.max() - m.min() + 1e-6)
    m = cv2.resize(m, (W, H), interpolation=cv2.INTER_LINEAR)
    m = np.clip((m - 0.35) / 0.4, 0, 1)
    return cv2.erode(m, np.ones((3, 3), np.uint8))          # край маски чуть внутрь: без ореола


dec = subprocess.Popen(['ffmpeg', '-v', 'error', '-i', src, '-vf', f'scale={W}:{H}', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'],
                       stdout=subprocess.PIPE)
frames = []
while True:
    b = dec.stdout.read(W * H * 3)
    if len(b) < W * H * 3:
        break
    frames.append(np.frombuffer(b, np.uint8).reshape(H, W, 3))
n = len(frames)
keys = list(range(0, n, STEP)) + ([n - 1] if (n - 1) % STEP else [])
km = {}
for i, k in enumerate(keys):
    km[k] = infer(frames[k])
    if i % 50 == 0:
        print(f'маска: {i}/{len(keys)}', flush=True)
fps = subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v', '-show_entries', 'stream=r_frame_rate',
                               '-of', 'csv=p=0', src]).decode().strip()
enc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'gray', '-s', f'{W}x{H}', '-r', fps, '-i', '-',
                        '-c:v', 'libx264', '-crf', '8', '-pix_fmt', 'yuv420p', dst], stdin=subprocess.PIPE)
for f in range(n):
    a = max(k for k in keys if k <= f)
    b = min(k for k in keys if k >= f)
    m = km[a] if a == b else km[a] + (km[b] - km[a]) * (f - a) / (b - a)
    enc.stdin.write((np.clip(m, 0, 1) * 255).astype(np.uint8).tobytes())
enc.stdin.close(); enc.wait()
print('готово:', n, 'кадров,', len(keys), 'расчётов маски')
