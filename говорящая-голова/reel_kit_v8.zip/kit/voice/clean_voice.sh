#!/bin/bash
# Чистка голоса v2 (зафиксирована 17.10): ОДИН проход по несжатым кускам нарезки (parts/*.mkv),
# склейка ВМЕСТЕ с видео (иначе синхрон уезжает), затем выравнивание по дорожке cut.mp4.
# Использование: bash clean_voice.sh <папка с parts/> <выход.wav>
P=$1; OUT=$2; N=$(ls $P/parts/p*.mkv | wc -l); D=$(dirname "$0")
ins=""; fc=""; cc=""
for i in $(seq 0 $((N-1))); do f=$(printf "%s/parts/p%02d.mkv" $P $i); ins="$ins -i $f"; fc="$fc[$i:v]setpts=N/30/TB[v$i];[$i:a]asetpts=N/SR/TB[a$i];"; cc="$cc[v$i][a$i]"; done
AF="highpass=f=75,arnndn=m=$D/sh.rnnn:mix=0.9,equalizer=f=130:t=o:w=1:g=3,equalizer=f=350:t=o:w=1:g=-4.5,equalizer=f=650:t=o:w=1:g=-2,equalizer=f=3000:t=o:w=1.2:g=3.5,highshelf=f=8000:g=2,deesser=i=0.5,acompressor=threshold=-22dB:ratio=3:attack=6:release=90:makeup=2,agate=threshold=0.008:ratio=2:attack=5:release=120,loudnorm=I=-16:TP=-1.5:LRA=7"
ffmpeg -v error -y $ins -filter_complex "${fc}${cc}concat=n=$N:v=1:a=1[vv][c];[vv]nullsink;[c]$AF[o]" -map "[o]" -ar 48000 -ac 1 "$OUT"
# дальше: сравнить сдвиг с cut.mp4 (кросс-корреляция) и при необходимости adelay; проверить провалы > 20 мс и последнее слово
