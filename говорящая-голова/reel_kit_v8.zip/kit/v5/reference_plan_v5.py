import json
w = json.load(open('words.json', encoding='utf-8'))
W = lambda k: [x['s'] for i, x in enumerate(w) if f"{x['w']}#{i}" == k][0]
edl = json.load(open('edl.json')); C = [q['out'][0] for q in edl[1:]]; TOTAL = edl[-1]['out'][1]
S = []; a = lambda f, t, v: S.append([f'sfx/{f}.wav', round(t, 2), v])
a('fire', .40, 1.0); a('whoosh', 0.0, .09); a('impact', .03, .08)               # хук: огонь + вылет заголовка
for c in C: a('click', c - .02, .14)                                              # щелчок мыши на склейках
a('whoosh', C[0] - .08, .09); a('low_boom', C[0], .1); a('thock', W('Промпт#12') - .05, .09)
for k in ['понятное#14', 'задание#15', 'для#16']: a('key', W(k), .08)
a('whoosh', W('задание#15') - .12, .04)
a('thock', W('магическая#19') - .06, .08); a('air', W('магическая#19') - .08, .05)
a('key', W('и#21') - .1, .1); a('strike', W('и#21') - .1, .1); a('sweep', W('и#21') - .1, .03)
a('tap', W('язык#24') - .1, .07); a('air', W('язык#24') - .12, .05); a('whoosh', W('специальный#23') - .12, .05); a('impact', W('специальный#23') - .02, .06)
a('key', W('программистов.#25') + .05, .1); a('strike', W('программистов.#25') + .05, .1)
a('whoosh', C[2] - .08, .08); a('low_boom', C[2], .11); a('impact', W('три#30') - .05, .07); a('scribble', W('вещи:#31'), .09)
for k in ['что#32', 'что#34', 'в#38']: a('swoosh', W(k) - .1, .06); a('thock', W(k) + .1, .09)
a('swoosh', C[3] - .3, .06); a('swoosh', C[3], .06); a('thock', C[3] + .1, .09); a('key', W('«Напиши#46'), .07); a('strike', W('письмо».#47') + .3, .1)
a('swoosh', W('Хороший:#48') - .12, .05); a('swoosh', W('Хороший:#48'), .06); a('scribble', W('Хороший:#48') + .2, .08)
for x in w:
    if 16.75 <= x['s'] < 22.9: a('key', x['s'], .06)
for k in ['ситуацию,#72', 'задачу#73', 'стиль.#76']: a('tap', W(k) - .1, .08); a('scribble', W(k) - .06, .08)
a('whoosh', C[8] - .08, .1); a('low_boom', C[8], .09); a('air', W('понятнее#78') - .05, .06); a('scribble', W('задачу,#81') - .05, .09)
a('whoosh', W('тем#82') - .12, .05); a('impact', W('тем#82') - .02, .06); a('whoosh', W('меньше#83') - .15, .06); a('thock', W('меньше#83') + .1, .1)
a('whoosh', C[9] - .1, .08); a('low_boom', C[9], .09); a('scribble', W('Сохраните#88'), .09); a('air', W('формулу:#90') - .05, .06)
for k in ['контекст,#91', 'задача,#92', 'формат.#93']: a('thock', W(k) - .02, .12); a('impact', W(k) - .04, .06)
a('swoosh', W('Напишите#94') - .12, .06); a('tap', W('Напишите#94') - .02, .07)
for i in range(8): a('key', W('«шаблон»,#95') - .05 + i * .055, .07)
a('scribble', W('отправлю#96'), .1); a('swoosh', W('для#98') - .08, .05); a('whoosh', W('первого#99') - .12, .05); a('impact', W('первого#99') - .02, .05)
json.dump({'total': TOTAL, 'music': 0.09, 'tpl': 'tplR5.html', 'sfx': S}, open('plan_r5.json', 'w'))
print(len(S))
