"""Звук v5 по схеме v4 (понравилась): вылеты — swoosh+thock, текст за спиной — air, рукопись — scribble,
зачёркивание — strike, склейки — щелчок мыши, большие смены — whoosh+низ. Печать — тихие клавиши."""
import json, wave
import numpy as np
w = json.load(open('words.json', encoding='utf-8')); edl = json.load(open('edl.json'))
C = [p['out'][0] for p in edl[1:]]; TOTAL = edl[-1]['out'][1]
W = lambda k: [x['s'] for i, x in enumerate(w) if f"{x['w']}#{i}" == k][0]
SR = 48000; N = int((TOTAL + .1) * SR); mix = np.zeros((N, 2)); cache = {}; rng = np.random.default_rng(3)
def load(n):
    f = wave.open(f'projR/sfx/{n}.wav'); a = np.frombuffer(f.readframes(f.getnframes()), np.int16).astype(float) / 32767
    a = a.reshape(-1, f.getnchannels()); sr = f.getframerate()
    if a.shape[1] == 1: a = np.repeat(a, 2, 1)
    if sr != SR: idx = np.arange(0, len(a), sr / SR).astype(int); a = a[idx[idx < len(a)]]
    return a
def put(n, t, g):
    if n not in cache: cache[n] = load(n)
    a = cache[n] * g; i = int(t * SR)
    if i < 0: a = a[-i:]; i = 0
    m = min(len(a), N - i)
    if m > 0: mix[i:i + m] += a[:m]
fly = lambda t, g=1: (put('swoosh', t - .04, .07 * g), put('thock', t + .12, .09 * g))
put('fire', .40, 1.0)
for i in range(3): put('swoosh', .0 + i * .16, .08); put('thock', .1 + i * .16, .08)
for c in C: put('click', c - .02, .16)
for c in (C[0], C[2], C[8], C[9]): put('whoosh', c - .1, .09); put('low_boom', c, .09)
fly(W('Промпт#12') - .05)
put('air', W('магическая#19') - .08, .06); fly(W('магическая#19') + .35, .8)
put('strike', W('и#21') - .1, .12); put('air', W('язык#24') - .12, .06)
put('whoosh', W('специальный#23') - .12, .06); put('impact', W('специальный#23') - .02, .05)
put('strike', W('программистов.#25') + .05, .12)
put('air', W('три#30') - .08, .06); put('scribble', W('вещи:#31') - .02, .11)
for k in ['что#32', 'что#34', 'в#38']: fly(W(k) - .05)
fly(C[3]); fly(C[3] + .42, .8); put('strike', W('письмо».#47') + .3, .13)
fly(W('Хороший:#48')); put('scribble', W('Хороший:#48') + .36, .09); put('swoosh', W('Хороший:#48') + .46, .05)
for k in ['ситуацию,#72', 'задачу#73', 'стиль.#76']: put('scribble', W(k) - .06, .09)
put('swoosh', C[8] - .26, .07)
put('air', W('понятнее#78') - .05, .06); put('scribble', W('задачу,#81') - .05, .1)
put('whoosh', W('тем#82') - .12, .06); put('impact', W('тем#82') - .02, .05)
fly(W('меньше#83') - .3, .8); put('whoosh', W('меньше#83') + .06, .06); put('thock', W('меньше#83') + .25, .1)
put('scribble', W('Сохраните#88'), .1); put('air', W('формулу:#90') - .05, .06)
for k in ['контекст,#91', 'задача,#92', 'формат.#93']: put('thock', W(k) - .02, .12); put('impact', W(k) - .04, .06)
put('swoosh', W('Напишите#94') - .12, .06); fly(W('Напишите#94') - .02, .8)
put('scribble', W('отправлю#96'), .1); put('swoosh', W('для#98') - .08, .05)
put('whoosh', W('первого#99') - .12, .05); put('impact', W('первого#99') - .02, .05)
from scipy.signal import resample
def variant(n, k):                                   # тон ±5 %, как в пресете daktilo
    key = f'{n}@{k:.3f}'
    if key not in cache:
        base = load(n); L = int(len(base) / k); cache[key] = np.stack([resample(base[:, c], L) for c in range(2)], 1)
    return key
def hit(t, g):
    for nm, dt, gg in (('dk_keydown', 0, 1.0), ('dk_keyup', rng.uniform(.055, .09), .45)):
        k = variant(nm, float(rng.choice([.95, .975, 1.0, 1.025, 1.05])))
        a_ = cache[k] * g * gg * rng.uniform(.9, 1.1); i = int((t + dt) * SR); m = min(len(a_), N - i)
        if m > 0: mix[i:i + m] += a_[:m]
def typew(t, n, span, g=.15):
    """живой темп: ~11 ударов/с, неровные интервалы; если времени мало — ударов меньше, чем букв"""
    k = max(1, min(n, int(span / .07)))
    ts = np.cumsum(rng.uniform(.065, .11, k)); ts = ts / ts[-1] * span * (k - 1) / max(k, 1)
    for x in ts: hit(t + x, g)
def typed_word(k, nxt=None):
    t = W(k); n = len(k.split('#')[0].strip('«».,:'))
    span = min(.09 * n, ((W(nxt) if nxt else t + .5) - t) * .85); typew(t, n, span)
# машинка Алекса подложкой: кусок живой печати нужной длины, со своим ритмом, мягкие края
bed = load('tw_bed')
def put_bed(t0, d, g=.2):
    out = np.zeros((int(d * SR), 2)); pos = int(rng.uniform(0, .6) * SR); i = 0
    while i < len(out):
        take = min(len(out) - i, len(bed) - pos - int(.1 * SR))
        if take <= 0: pos = int(rng.uniform(0, .4) * SR); continue
        out[i:i + take] += bed[pos:pos + take]; i += take; pos = int(rng.uniform(0, .4) * SR)
    f = int(.02 * SR); out[:f] *= np.linspace(0, 1, f)[:, None]; out[-f:] *= np.linspace(1, 0, f)[:, None]
    j = int(t0 * SR); m = min(len(out), N - j); mix[j:j + m] += out[:m] * g
put_bed(W('понятное#14') - .02, W('нейросети.#17') + .55 - W('понятное#14'))
put_bed(W('«Напиши#46') - .03, .4)
put_bed(W('«Мне#49') - .02, W('тоне».#66') + .5 - W('«Мне#49'))
put_bed(W('«шаблон»,#95') - .05, .5, .22)
f = wave.open('/home/claude/reel5/projR/music.wav'); mu = np.frombuffer(f.readframes(f.getnframes()), np.int16).astype(float).reshape(-1, f.getnchannels()) / 32767
if mu.shape[1] == 1: mu = np.repeat(mu, 2, 1)
m = min(len(mu), N); mix[:m] += mu[:m] * .09
mix[-int(.5 * SR):] *= np.linspace(1, 0, int(.5 * SR))[:, None]
mix = mix / max(np.abs(mix).max(), 1) * .98
f = wave.open('mix5e.wav', 'wb'); f.setnchannels(2); f.setsampwidth(2); f.setframerate(SR); f.writeframes((mix * 32767).astype(np.int16).tobytes()); f.close()
print('ok', round(np.abs(mix).max(), 2))
