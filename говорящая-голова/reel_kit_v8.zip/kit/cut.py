"""Нарезка дублей для стиля D2.

Что делает:
  1. режет выбранные дубли и убирает внутренние паузы ≥ 0,3 с;
  2. выравнивает тембр и громкость каждого дубля под общий план звука
     (глухой дубль «вытягивается» эквалайзером, тихий подтягивается по громкости);
  3. сдвигает края дублей в тишину и проверяет, что ни одно слово не срезано;
  4. склеивает куски кадр в кадр: звук и картинка не расходятся;
  5. пересчитывает тайминги слов на смонтированную дорожку.

Вход (в папке запуска):
  takes.json   {"src": "src.mov", "takes": [[начало, конец, "метка"], ...]}
  words_raw.txt  слова распознавания «слово,начало,конец|…» (сотые доли секунды исходника)
Выход: proj/cut.mp4, edl.json, words.json, voice_report.txt

Использование: python3 cut.py [--check-only]
"""
import json
import os
import subprocess
import sys

import numpy as np

CFG = json.load(open('takes.json', encoding='utf-8'))
SRC, TAKES = CFG['src'], [tuple(t) for t in CFG['takes']]
PAD, MIN_GAP, FPS = 0.07, 0.30, 30
BANDS = [200, 350, 650, 1000, 2000, 4000, 8000]   # полосы для сравнения тембра, Гц
EQ_LIMIT, EQ_THRESHOLD = 8.0, 2.5                  # дБ: не правим больше ±8, не трогаем отличия < 2,5


def pcm(s, d, sr=48000):
    r = subprocess.run(['ffmpeg', '-v', 'error', '-ss', f'{s:.3f}', '-t', f'{d:.3f}', '-i', SRC,
                        '-ac', '1', '-ar', str(sr), '-f', 's16le', '-'], capture_output=True).stdout
    return np.frombuffer(r, np.int16).astype(float) / 32768


def db(x):
    return 20 * np.log10(np.sqrt(np.mean(x ** 2)) + 1e-9)


# ---------- 0. тишины исходника ----------
if not os.path.exists('silences.txt'):
    out = subprocess.run(['ffmpeg', '-i', SRC, '-af', 'silencedetect=n=-35dB:d=0.3', '-f', 'null', '-'],
                         capture_output=True, text=True).stderr
    st = [float(l.split('silence_start: ')[1]) for l in out.splitlines() if 'silence_start' in l]
    en = [float(l.split('silence_end: ')[1].split()[0]) for l in out.splitlines() if 'silence_end' in l]
    open('silences.txt', 'w').write('\n'.join(f'{a:.2f}-{b:.2f} ({b - a:.2f})' for a, b in zip(st, en)))
sil = [tuple(map(float, l.split()[0].split('-'))) for l in open('silences.txt')]

# ---------- 1. края дублей и склеек: не режем слова ----------
# Граница считается «в тишине», только когда звук ниже −52 дБ (настоящая тишина, а не хвост слова −40…−50 дБ:
# после нормализации громкости хвост становится слышен, и обрезанный хвост звучит как срезанное слово).
# Каждый край сдвигается наружу до настоящей тишины. После последнего слова ролика — ещё 0,6 с тишины:
# конец видео плееры «съедают», последнему слову нужен воздух.
raw = [it.rsplit(',', 2) for it in open('words_raw.txt', encoding='utf-8').read().strip().split('|')]
words_src = [(w, int(a) / 100, int(b) / 100) for w, a, b in raw]
SIL_DB, LAST_TAIL = -52, 0.6
_all = subprocess.run(['ffmpeg', '-v', 'error', '-i', SRC, '-ac', '1', '-ar', '16000', '-f', 's16le', '-'],
                      capture_output=True).stdout
A = np.frombuffer(_all, np.int16).astype(float) / 32768


def lvl(a, b):
    x = A[max(0, int(a * 16000)):max(0, int(b * 16000))]
    return db(x) if len(x) else -120


def floor_at(x):                    # шум комнаты рядом с точкой: 10-й перцентиль уровней ±1,5 с
    v = [lvl(t, t + 0.05) for t in np.arange(max(0, x - 1.5), x + 1.5, 0.05)]
    return float(np.percentile(v, 10)) if v else -70


def thr_at(x):                      # тишина = ниже −52 дБ или не громче шума комнаты +6 дБ
    return max(SIL_DB, floor_at(x) + 6)


def quiet_after(x, limit):          # первая точка ≥ x, после которой 50 мс тишины
    y, th = x, thr_at(x)
    while y < limit:
        if lvl(y, y + 0.05) < th:
            return y
        y += 0.01
    return None


def quiet_before(x, limit):         # первая точка ≤ x, перед которой 50 мс тишины
    y, th = x, thr_at(x)
    while y > limit:
        if lvl(y - 0.05, y) < th:
            return y
        y -= 0.01
    return None


def softest(a, b):                  # запасной вариант: самая тихая точка между словами
    ts = np.arange(a, max(a + 0.011, b), 0.01)
    return float(min(ts, key=lambda t: lvl(t - 0.015, t + 0.015)))


problems, notes, fixed = [], [], []
for i, (s, e, lab) in enumerate(TAKES):
    s0, e0 = s, e
    nxt = min([w[1] for w in words_src if w[1] > e0 + 0.02], default=1e9)   # следующее слово исходника
    prv = max([w[2] for w in words_src if w[2] < s0 - 0.02], default=-1e9)  # предыдущее слово исходника
    q = quiet_after(e0 - 0.02, min(e0 + 0.5, nxt - 0.06))
    if q is None:                   # слова идут подряд: режем в самой тихой точке перед следующим звуком
        e = softest(e0, min(e0 + 0.3, nxt - 0.06))
        notes.append(f'{lab}: конец по самой тихой точке {e:.2f} ({lvl(e - 0.015, e + 0.015):.0f} дБ)')
    else:
        e = max(e0, q + 0.03)
    q = quiet_before(s0 + 0.02, max(s0 - 0.4, prv + 0.06))
    if q is None:
        s = softest(max(s0 - 0.3, prv + 0.06), s0)
        notes.append(f'{lab}: начало по самой тихой точке {s:.2f} ({lvl(s - 0.015, s + 0.015):.0f} дБ)')
    else:
        s = min(s0, q - 0.02)
    if i == len(TAKES) - 1:         # последний дубль: воздух после последнего слова
        tail = min(e + LAST_TAIL, nxt - 0.1)
        if lvl(e, tail) < SIL_DB + 4:
            e = tail
        else:
            problems.append(f'{lab}: после последнего слова нет {LAST_TAIL} с тишины')
    if abs(s - s0) > 0.005 or abs(e - e0) > 0.005:
        notes.append(f'{lab}: {s0:.2f}–{e0:.2f} → {s:.2f}–{e:.2f}')
    fixed.append((s, e, lab))
TAKES = fixed

# ---------- 2. куски: внутренние паузы убираем, но хвосты слов у пауз сохраняем; длина кратна кадру ----------
pieces = []
for s, e, lab in TAKES:
    cur = s
    for a, b in sil:
        if a > s and b < e and b - a >= MIN_GAP:
            ea = quiet_after(a, min(a + 0.3, b - 0.05)) or a + PAD          # конец куска — где хвост затих
            sb = quiet_before(b, max(b - 0.3, ea + 0.05)) or b - PAD        # начало следующего — до атаки
            if sb - ea < 0.1:                                               # пауза слишком короткая — не режем
                continue
            pieces.append((cur, ea + 0.03, lab))
            cur = sb - 0.02
    pieces.append((cur, e, lab))
pieces = [(s, s + np.ceil((e - s) * FPS - 1e-6) / FPS, lab) for s, e, lab in pieces]   # вверх: хвост не теряем

for s, e, lab in pieces:
    for edge, name, (a, b) in ((s, 'начало', (s - 0.03, s)), (e, 'конец', (e, e + 0.03))):   # что ОСТАЛОСЬ за краем куска
        if lvl(a, b) > max(-45, thr_at(edge) + 4):
            problems.append(f'{lab}: {name} куска {edge:.2f} с на звуке ({lvl(a, b):.0f} дБ) — за краем остаётся звук, проверь, не режется ли слово')
print('КРАЯ СДВИНУТЫ ДО ТИШИНЫ:', '; '.join(notes) if notes else 'нет')
print('ПРОВЕРКА СЛОВ:', 'всё чисто' if not problems else '')
for p in problems:
    print('  !', p)
if '--check-only' in sys.argv:
    sys.exit(0)


# ---------- 3. общий план звука: тембр и громкость каждого дубля ----------
def profile(x, sr=48000):
    n = 4096
    fr = [x[i:i + n] * np.hanning(n) for i in range(0, len(x) - n, n // 2)]
    fr = [f for f in fr if np.sqrt(np.mean(f ** 2)) > 0.01]            # только кадры с речью
    P = np.mean([np.abs(np.fft.rfft(f)) ** 2 for f in fr], axis=0)
    q = np.fft.rfftfreq(n, 1 / sr)
    bands = np.array([10 * np.log10(P[(q >= b / 1.41) & (q < b * 1.41)].mean()) for b in BANDS])
    loud = 20 * np.log10(np.median([np.sqrt(np.mean(f ** 2)) for f in fr]))
    return bands - bands.mean(), loud


labels = list(dict.fromkeys(l for _, _, l in TAKES))
prof = {}
for lab in labels:
    x = np.concatenate([pcm(s, e - s) for s, e, l in pieces if l == lab])
    prof[lab] = profile(x)
ref_shape = np.median([prof[l][0] for l in labels], axis=0)
ref_loud = float(np.median([prof[l][1] for l in labels]))
EQ, report = {}, []
for lab in labels:
    dev = prof[lab][0] - ref_shape
    parts = [f'equalizer=f={b}:t=o:w=1:g={-np.clip(d, -EQ_LIMIT, EQ_LIMIT):.1f}'
             for b, d in zip(BANDS, dev) if abs(d) >= EQ_THRESHOLD]
    gain = float(np.clip(ref_loud - prof[lab][1], -6, 9))
    if abs(gain) >= 1.5:
        parts.append(f'volume={gain:.1f}dB')
    EQ[lab] = (','.join(parts) + ',') if parts else ''
    report.append(f'{lab:10s} тембр {np.round(dev, 1).tolist()}  громкость {gain:+.1f} дБ  → {EQ[lab] or "без правки"}')
open('voice_report.txt', 'w', encoding='utf-8').write('\n'.join(report))
print('ОБЩИЙ ПЛАН ЗВУКА:'); print('\n'.join('  ' + r for r in report))

# ---------- 4. монтажный лист и слова на новой дорожке ----------
edl, t = [], 0.0
for s, e, lab in pieces:
    edl.append({'src': [round(s, 3), round(e, 3)], 'out': [round(t, 3), round(t + e - s, 3)], 'label': lab})
    t += e - s
json.dump(edl, open('edl.json', 'w'), ensure_ascii=False, indent=1)


def to_out(x):
    for p in edl:
        a, b = p['src']
        if a - 0.001 <= x <= b + 0.001:
            return p['out'][0] + (x - a)
    return None


words = []
for w, a, b in words_src:
    for sa, sb in sil:                       # начало слова попало в тишину — сдвигаем к концу тишины
        if sa <= a < sb and sb - sa >= 0.3:
            a = min(sb, b - 0.05)
    oa, ob = to_out(a), to_out(b)
    if oa is None or ob is None:
        oa = oa if oa is not None else ob
        ob = ob if ob is not None else oa
    if oa is None:
        continue
    words.append({'w': w, 's': round(oa, 3), 'e': round(max(ob, oa + 0.08), 3)})
json.dump(words, open('words.json', 'w'), ensure_ascii=False)

# ---------- 5. куски и склейка кадр в кадр ----------
os.makedirs('parts', exist_ok=True)
os.makedirs('proj', exist_ok=True)
for i, (s, e, lab) in enumerate(pieces):
    d = e - s
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{s:.3f}', '-i', SRC, '-t', f'{d + 0.1:.3f}',
                    '-vf', f'scale=1080:1920:flags=lanczos,fps={FPS}', '-frames:v', str(round(d * FPS)),
                    '-af', EQ[lab] + f'afade=t=in:d=0.02,afade=t=out:st={d - 0.03:.3f}:d=0.03,apad,atrim=0:{d:.4f}',
                    '-c:v', 'libx264', '-crf', '15', '-preset', 'fast', '-c:a', 'pcm_s16le', '-ar', '48000',
                    f'parts/p{i:02d}.mkv'], check=True)
n = len(pieces)
ins = sum([['-i', f'parts/p{i:02d}.mkv'] for i in range(n)], [])
fc = ''.join(f'[{i}:v]setpts=N/{FPS}/TB[v{i}];[{i}:a]asetpts=N/SR/TB[a{i}];' for i in range(n)) \
    + ''.join(f'[v{i}][a{i}]' for i in range(n)) + f'concat=n={n}:v=1:a=1[v][a0];' \
    + '[a0]highpass=f=80,afftdn=nf=-25,acompressor=threshold=-20dB:ratio=3:attack=5:release=80,loudnorm=I=-16:TP=-1.5:LRA=7[a]'
subprocess.run(['ffmpeg', '-v', 'error', '-y', *ins, '-filter_complex', fc, '-map', '[v]', '-map', '[a]',
                '-c:v', 'libx264', '-crf', '17', '-preset', 'medium', '-g', '30', '-keyint_min', '30',
                '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', 'proj/cut.mp4'], check=True)

# контроль: длина звука = длина картинки
vf = int(subprocess.check_output(['ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v', '-show_entries',
                                  'stream=nb_read_frames', '-of', 'csv=p=0', 'proj/cut.mp4']).decode())
au = len(subprocess.run(['ffmpeg', '-v', 'error', '-i', 'proj/cut.mp4', '-map', '0:a', '-ac', '1', '-ar', '48000',
                         '-f', 's16le', '-'], capture_output=True).stdout) / 96000
print(f'{n} кусков, {t:.2f} с; картинка {vf / FPS:.2f} с, звук {au:.2f} с', '— синхронно' if abs(vf / FPS - au) < 0.04 else '— РАСХОЖДЕНИЕ!')

# контроль: после последнего слова в готовой нарезке есть воздух
B = np.frombuffer(subprocess.run(['ffmpeg', '-v', 'error', '-i', 'proj/cut.mp4', '-map', '0:a', '-ac', '1', '-ar', '16000',
                                  '-f', 's16le', '-'], capture_output=True).stdout, np.int16).astype(float) / 32768
win = [db(B[i:i + 800]) for i in range(0, len(B) - 800, 800)]
last_voice = max(i for i, v in enumerate(win) if v > -45) * 0.05 + 0.05
air = len(B) / 16000 - last_voice
print(f'ПОСЛЕДНЕЕ СЛОВО: голос до {last_voice:.2f} с, ролик до {len(B) / 16000:.2f} с, воздух {air:.2f} с',
      '— ок' if air >= 0.5 else '— МАЛО, последнее слово обрежется!')
