// Распознавание речи с таймингами слов в Chrome (вкладка https://example.com через расширение Claude in Chrome).
// Контейнер не достаёт до huggingface/jsdelivr, а браузер Алекса достаёт — поэтому модель крутится у него в Chrome.
// 1) В контейнере: ffmpeg -i src.mov -ac 1 -ar 16000 -c:a libopus audio.webm (файл должен лежать в /home/claude).
// 2) На странице создать <input type=file id="aud">, загрузить audio.webm инструментом file_upload.
// 3) Выполнить этот код, потом читать window.__ASR.txt маленькими кусками (ответ инструмента режется на ~2000 символов).
window.__ASR = { done: 0, txt: '', err: '' };
(async () => {
  try {
    const { pipeline } = await import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.5.1');
    const asr = await pipeline('automatic-speech-recognition', 'onnx-community/whisper-small_timestamped',
      { device: 'webgpu', dtype: { encoder_model: 'fp32', decoder_model_merged: 'q4' } });
    const f = document.getElementById('aud').files[0];
    const ctx = new AudioContext({ sampleRate: 16000 });
    const pcm = (await ctx.decodeAudioData(await f.arrayBuffer())).getChannelData(0);
    const SEG = 24 * 16000, out = [];                       // куски ~24 с; лучше резать по тишинам из silences.txt
    for (let s = 0; s < pcm.length; s += SEG) {
      const r = await asr(pcm.slice(s, s + SEG), { language: 'russian', task: 'transcribe', return_timestamps: 'word' });
      for (const c of r.chunks || []) {
        const a = Math.round((s / 16000 + c.timestamp[0]) * 100), b = Math.round((s / 16000 + (c.timestamp[1] ?? c.timestamp[0] + .2)) * 100);
        out.push(`${c.text.trim()},${a},${b}`);
      }
    }
    window.__ASR.txt = out.join('|');                       // формат words_raw.txt
    window.__ASR.done = 1;
  } catch (e) { window.__ASR.err = String(e); }
})();
