"""Премиальный саунд-дизайн (Apple-презентация) для ролика со шляпой.
Иерархия: 4 главных момента — многослойные акценты (суб-удар + воздушный свип + блеск + хвост реверберации);
движения — мягкие воздушные свипы по физике движения (направление, панорама); появления — тихие чистые digital-тики;
мелочь — тишина. Отдельные стемы: low / air / ui / verb; шина эффектов приседает под голос.
Пишет stems/*.wav и sfxP.wav (48 кГц, стерео)."""
import json, os, wave, subprocess, numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
SR = 48000; END = 39.233; N = int(END * SR)
w = json.load(open('/home/claude/reel4/words.json')); S = lambda i: w[i]['s']
C = [3.5, 7.43, 11.87, 15.8, 25.2, 28.37, 34.3]
rng = np.random.default_rng(11)
os.makedirs('stems_v6', exist_ok=True)
BUS = {k: np.zeros((N, 2)) for k in ('low', 'air', 'ui')}
SEND = np.zeros((N, 2))                                   # посыл в реверберацию
T = lambda d: np.arange(int(d * SR)) / SR
def bp(x, lo, hi, o=2): return sosfilt(butter(o, [lo, hi], 'band', fs=SR, output='sos'), x)
def lp(x, f, o=2): return sosfilt(butter(o, f, 'low', fs=SR, output='sos'), x)
def hp(x, f, o=2): return sosfilt(butter(o, f, 'high', fs=SR, output='sos'), x)
def st(m, pan=0., width=0.):                              # моно → стерео с панорамой и лёгкой шириной
    L = m * np.sqrt(.5 * (1 - pan)); R = m * np.sqrt(.5 * (1 + pan))
    if width: d = int(width * SR); R = np.concatenate([np.zeros(d), R[:-d]]) if d else R
    return np.stack([L, R], 1)
def put(bus, a, t, g, send=0.):
    i = int(t * SR); a = a * g
    if i < 0: a = a[-i:]; i = 0
    m = min(len(a), N - i)
    if m <= 0: return
    BUS[bus][i:i + m] += a[:m]
    if send: SEND[i:i + m] += a[:m] * send
def fade(x, a=.004, r=.02):
    n = len(x); ea = int(a * SR); er = int(r * SR); e = np.ones(n)
    if ea: e[:ea] = np.linspace(0, 1, ea)
    if er: e[-er:] *= np.linspace(1, 0, er)
    return x * (e if x.ndim == 1 else e[:, None])
# ---------- палитра ----------
def sweep(d=.6, f0=300, f1=5000, peak=.6, pan0=0., pan1=0., q=.7):
    """воздушный свип: шум через движущуюся полосу, огибающая по физике движения, панорама следует за объектом"""
    n = int(d * SR); x = rng.normal(0, 1, n); t = np.arange(n) / n
    out = np.zeros(n); blk = 1024
    for s in range(0, n, blk):
        u = (s + blk / 2) / n; fc = f0 * (f1 / f0) ** u
        seg = bp(x[max(0, s - 2048):s + blk], fc / (1 + q), min(fc * (1 + q), 20000))[-min(blk, n - s):]
        out[s:s + len(seg)] = seg
    env = np.where(t < peak, (t / peak) ** 2, ((1 - t) / (1 - peak)) ** 1.6)
    out *= env; out /= np.abs(out).max() + 1e-9
    pan = np.linspace(pan0, pan1, n)
    return fade(np.stack([out * np.sqrt(.5 * (1 - pan)), out * np.sqrt(.5 * (1 + pan))], 1), .01, .05)
def swell(d=.45):                                          # обратная реверберация, втягивает в главный момент
    n = int(d * SR); x = hp(rng.normal(0, 1, n), 600) * np.exp(-np.arange(n)[::-1] / (SR * .14))
    x = lp(x, 9000) / (np.abs(x).max() + 1e-9); return fade(st(x, 0, .0007), .02, .004)
def sub(f0=62, f1=40, d=.55, click=.25):                   # контролируемый суб-удар: тон с падением, короткий хвост
    t = T(d); f = f1 + (f0 - f1) * np.exp(-t / .045); ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * (1 - np.exp(-t / .004)) * np.exp(-t / .16)
    tr = lp(rng.normal(0, 1, len(t)), 2500) * np.exp(-t / .006) * click
    x = lp(x + tr, 180, 4) * 1.0 + lp(tr, 4000) * .3
    x = x + bp(np.tanh(x / (np.abs(x).max() + 1e-9) * 3), 90, 320) * .45   # гармоники, чтобы низ читался на телефоне
    return fade(st(x / (np.abs(x).max() + 1e-9)), .001, .06)
def shimmer(base=2400, d=.9, n=5):                         # стеклянный блеск: негармоничные высокие парциалы
    t = T(d); x = np.zeros(len(t))
    for k in range(n):
        f = base * (1 + k * .618) * rng.uniform(.99, 1.01); x += np.sin(2 * np.pi * f * t + rng.uniform(0, 6)) * np.exp(-t / (.18 + .05 * k)) / (1 + k * .5)
    x *= 1 - np.exp(-t / .003); x = hp(x, 1800); return fade(st(x / (np.abs(x).max() + 1e-9), 0, .0011), .001, .1)
def tick(f=3600, d=.05, body=.5, pan=0.):                  # чистый digital-тик
    t = T(d); x = np.sin(2 * np.pi * f * t) * np.exp(-t / .0045) + np.sin(2 * np.pi * f * 1.5 * t) * np.exp(-t / .003) * .35
    x += hp(rng.normal(0, 1, len(t)), 6000) * np.exp(-t / .0012) * .4
    x += np.sin(2 * np.pi * 900 * t) * np.exp(-t / .008) * body * .4
    return fade(st(x / (np.abs(x).max() + 1e-9), pan), .0005, .01)
def sendswish(d=.24):
    t = T(d); n = len(t)
    x = rng.normal(0, 1, n); out = np.zeros(n); blk = 512
    for s0 in range(0, n, blk):
        u = (s0 + blk / 2) / n; fc = 900 * (6500 / 900) ** u
        seg = bp(x[max(0, s0 - 1024):s0 + blk], fc / 1.6, min(fc * 1.6, 20000))[-min(blk, n - s0):]; out[s0:s0 + len(seg)] = seg
    out /= np.abs(out).max() + 1e-9
    env = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 1.3
    f = 520 + 900 * (t / d) ** 1.5; ph = 2 * np.pi * np.cumsum(f) / SR
    tone = np.sin(ph) * np.exp(-((t - d * .45) / (d * .28)) ** 2)
    y = (out * .75 + tone * .45) * env
    return fade(st(y / (np.abs(y).max() + 1e-9), 0, .0006), .002, .03)
def press():                                               # нажатие физической кнопки: мягкий щелчок с корпусом
    t = T(.07); x = lp(rng.normal(0, 1, len(t)), 5000) * np.exp(-t / .003) + np.sin(2 * np.pi * 210 * t) * np.exp(-t / .018) * .8
    return fade(st(x / (np.abs(x).max() + 1e-9)), .0005, .02)
def delicate(d=.35):                                       # деликатный импакт: глухой толчок + короткий воздух
    t = T(d); x = np.sin(2 * np.pi * (95 + 60 * np.exp(-t / .02)) * t) * np.exp(-t / .07)
    x += bp(rng.normal(0, 1, len(t)), 300, 2200) * np.exp(-t / .02) * .25
    return fade(st(x / (np.abs(x).max() + 1e-9)), .001, .05)
def chime():                                               # подтверждение: два чистых тона, без «игровости»
    a = np.zeros(int(1.2 * SR))
    for f, t0, g in ((1046.5, 0, 1), (1568.0, .085, .75)):
        t = T(1.0); s = (np.sin(2 * np.pi * f * t) + .18 * np.sin(2 * np.pi * 2 * f * t)) * np.exp(-t / .32) * (1 - np.exp(-t / .002)) * g
        i = int(t0 * SR); a[i:i + len(s)] += s
    return fade(st(a / np.abs(a).max(), 0, .0009), .001, .2)
def pack(name, d=None, lpf=None):                          # звук из пака Алекса
    f = [x for x in os.listdir('/home/claude/kit/sfx_library/alex_pack') if x.startswith(name + '.')][0]
    a = np.frombuffer(subprocess.run(['ffmpeg', '-v', 'error', '-i', '/home/claude/kit/sfx_library/alex_pack/' + f, '-ac', '2', '-ar', str(SR), '-f', 's16le', '-'], capture_output=True).stdout, np.int16).astype(float).reshape(-1, 2) / 32767
    if d: a = a[:int(d * SR)]
    if lpf: a = np.stack([lp(a[:, 0], lpf), lp(a[:, 1], lpf)], 1)
    return fade(a / (np.abs(a).max() + 1e-9), .002, .08)
dB = lambda x: 10 ** (x / 20)

# ================= ГЛАВНЫЕ МОМЕНТЫ (многослойно) =================
# A1 · жидкое стекло 3.10–3.50 → новая сцена
put('air', swell(.42), 3.08, dB(-23), .5)
put('air', sweep(.5, 500, 7000, .75, 0, 0, .5), 3.02, dB(-25), .4)
put('low', sub(58, 38, .6), 3.49, dB(-15))
put('ui', shimmer(2600, 1.0), 3.50, dB(-29), .7)
put('air', sweep(.55, 6000, 900, .15, 0, 0, .6), 3.52, dB(-30), .5)          # пелена расходится
# A2 · ты уходишь в карточку на белом (11.57–12.27): воздух вниз + мягкий суб на посадке
put('air', sweep(.75, 4200, 420, .4, 0, 0, .6), C[2] - .32, dB(-30), .45)
put('low', sub(66, 44, .45, .15), C[2] + .33, dB(-21))
put('ui', tick(2900, .05, .8), C[2] + .36, dB(-34), .3)
# A3 · отправка запроса и скролл во весь кадр
put('ui', press(), S(73) + .12, dB(-25), .2)
put('ui', tick(4200, .04, .2), S(73) + .14, dB(-36), .3)
put('air', sweep(.65, 380, 6000, .55, 0, 0, .5), C[4] - .17, dB(-29), .45)
put('low', sub(60, 40, .55), C[4] + .43, dB(-16))
pass
# A4 · смахивание к призыву и «Сохранено» — кульминация
put('air', sweep(.55, 900, 5500, .45, .7, -.7, .55), C[6] - .3, dB(-28), .4)  # страница едет справа налево
put('low', sub(64, 42, .5, .2), C[6] + .22, dB(-19))
put('ui', press(), S(103) + .2, dB(-24), .2)
put('ui', chime(), S(103) + .27, dB(-27), .55)
put('low', sub(80, 55, .35, .1), S(103) + .27, dB(-27))

# ================= ДВИЖЕНИЯ (мягкие свипы, без «стандартных swoosh») =================
put('air', sweep(.9, 250, 2600, .55, 0, 0, .4), 0.0, dB(-31), .3)            # открытие: воздух под проявление заголовка
put('low', delicate(), S(9) - .04, dB(-27), .2)                                 # «не про работу» — мягкий толчок
put('air', sweep(.55, 300, 3000, .6, 0, 0, .5), S(9) - .25, dB(-34), .3)
for t in (S(19) - .14, C[1] - .04, S(30) - .09):                               # смена примеров в плитке — короткий воздух
    put('air', sweep(.32, 1200, 5200, .5, 0, 0, .5), t, dB(-36), .25)
put('air', pack('camera_whoosh', lpf=9000), C[3] - .4, dB(-30), .3)          # уменьшение в окошко
put('air', sweep(.6, 2600, 500, .3, 0, 0, .5), C[3] - .12, dB(-34), .3)      # всплытие карточки запроса
put('air', sweep(.5, 400, 3200, .6, 0, 0, .5), S(95) - .5, dB(-33), .3)     # плитка плана
put('low', delicate(), S(98) - .02, dB(-25), .25)                                # «к конкретному плану» — акцент + зум
pass
put('air', sweep(.45, 500, 3600, .6, 0, 0, .5), S(101) + .05, dB(-35), .3)  # капсула «Сохранить»

# ================= ПОЯВЛЕНИЯ v5: разные звуки на разные действия, «пув» (ui_04) — только на 2 крупных объекта =================
LIBS = {'a': '/home/claude/kit/sfx_library/alex_pack/', 'u': '/home/claude/kit/sfx_library/ui_pack/'}
_c = {}
def snd(name, rate=1.0):
    k = (name, rate)
    if k not in _c:
        lib, n = name.split(':'); d = LIBS[lib]; f = [x for x in os.listdir(d) if x.startswith(n + '.')][0]
        a = np.frombuffer(subprocess.run(['ffmpeg', '-v', 'error', '-i', d + f, '-ac', '2', '-ar', str(SR), '-f', 's16le', '-'], capture_output=True).stdout, np.int16).astype(float).reshape(-1, 2) / 32767
        if rate != 1.0:                                   # сдвиг высоты пересэмплированием (разнообразие одинаковых действий)
            idx = np.arange(0, len(a) - 1, rate); a = np.stack([np.interp(idx, np.arange(len(a)), a[:, c]) for c in range(2)], 1)
        m = np.abs(a).max(1); on = int(np.argmax(m > m.max() * .05)); pk = int(np.argmax(m))
        _c[k] = (fade(a[on:] / (m.max() + 1e-9), .001, .03), (pk - on) / SR)
    return _c[k]
def X(name, t, db, at='onset', rate=1.0, send=.15, pan=0., cut=None):
    a, pk = snd(name, rate)
    if cut: a = fade(a[:int(cut * SR)], .001, .04)
    if pan: a = a * np.array([np.sqrt(1 - pan), np.sqrt(1 + pan)])
    put('ui', a, t - (pk if at == 'peak' else 0), dB(db), send)
# --- хук: у каждого элемента свой звук ---
X('a:mouse_click', .02, -24)                                   # чип сверху — лёгкий клик
X('u:ui_09', .12, -22)                                         # иконка — мягкий низкий тон
X('u:ui_01', .18, -27, rate=.9)                               # проявление заголовка — мягкий тик
X('a:pop', S(5) - .03, -22, rate=1.06)                         # «к нейросети» — поп
X('a:hit_2', S(9) - .03, -27)                                  # «не про работу» — акцент
X('u:ui_01', S(10) + .05, -24)                                 # выделение
X('a:riser_2', 3.47, -27, 'peak', cut=None)                    # подводка к стеклу (хвост райзера)
X('u:ui_02', 2.62, -26)                                        # мягкий зум
# --- плитка с примерами ---
X('u:ui_04', C[0] + .06, -22)                                  # «пув» №1 — большая плитка
X('a:whoosh_1_2', S(12) - .12, -30)                            # смена содержимого
for k in range(4): X('u:ui_06' if k % 2 else 'a:click', S(14) + k * .16, -25, rate=1 + .05 * k, pan=-.3 + .2 * k)
X('u:ui_06', S(18) + .1, -25, rate=.92)                       # «→ 3 рецепта»
X('a:whoosh_1_2', S(19) - .14, -31)
X('u:ui_09', S(20), -23, rate=1.1)                             # входящее сообщение
X('a:keyboard', S(22) + .1, -29, cut=.45)                      # «печатает…»
put('ui', sendswish(), S(23) + .3, dB(-22), .2)                # ответ отправлен — «отправка сообщения»
X('a:whoosh_1_2', C[1] - .12, -31)
for k, i in enumerate((26, 27, 29)): X('u:ui_06', S(i), -23, rate=1 + .06 * k)
X('a:whoosh_1_2', S(30) - .12, -31)
X('u:ui_07', S(33) + .3, -27, 'peak')                          # текст сжимается
X('a:pop', S(34) - .03, -23, rate=.94)                         # «коротко и ясно»
# --- карточка на белом ---
X('u:ui_02', C[2] - .3, -23)
X('a:hit_1', S(38) - .03, -27)                                 # «маленькую задачу»
X('u:ui_01', S(39) - .1, -24)
X('u:ui_09', S(44), -23, rate=.9)                              # «слишком долго»
# --- запрос ---
X('u:ui_02', C[3] - .3, -24)
X('u:ui_04', C[3] - .08, -23)                                  # «пув» №2 — карточка запроса
for t0 in (S(47), S(55), S(66)): X('a:keyboard', t0 - .02, -29, cut=.5, pan=rng.uniform(-.2, .2))
for k, i in enumerate((50, 51, 52, 54)): X('a:click' if k % 2 == 0 else 'u:ui_06', S(i) - .03, -24, rate=1 + .04 * k, pan=-.2 + .13 * k)
for k, i in enumerate((56, 59, 63)): X('u:ui_09', S(i) - .03, -23, rate=1 + .07 * k, pan=.2 * (k - 1))
X('u:ui_01', S(67) - .03, -26); X('u:ui_01', S(71) - .03, -26, rate=1.08)
X('a:blink', S(72) - .03, -28)                                 # кнопка отправки появилась
X('a:mouse_click', S(73) + .12, -24); put('ui', sendswish(.28), S(73) + .16, dB(-20), .25)   # запрос отправлен
# --- ползунки ---
X('u:ui_08', S(76) - .05, -25); X('u:ui_08', S(80) - .05, -25, rate=1.12)
# --- план ---
X('a:whoosh_3', S(95) - .55, -31, 'peak')                      # плитка плана выплывает
X('u:ui_01', S(96) - .05, -24)
X('u:ui_02', S(98) - .2, -25)
for k, t in enumerate((S(99), S(99) + .3, S(100))): X('u:ui_06', t, -23, rate=1 + .06 * k)

# --- переходы из библиотеки переходов Алекса (alex_pack), пик звука — на середину движения ---
X('a:whoosh_2', C[2] + .05, -26, 'peak')                       # уход в карточку на белом
X('a:whoosh_3', C[4] + .12, -26, 'peak')                       # скролл и раскрытие во весь кадр
X('a:whoosh_4', C[6] + .0, -26, 'peak', pan=0.)                # смахивание к призыву
X('a:whoosh_1', C[3] - .05, -30, 'peak')                       # уменьшение в окошко
# --- призыв ---
X('a:camera_whoosh', S(101) + .05, -30)                        # капсула «Сохранить»
X('a:mouse_click', S(103) + .2, -23); put('ui', sendswish(.22), S(103) + .24, dB(-24), .2)
X('u:ui_09', S(110) - .03, -24, rate=.94); X('u:ui_01', S(111), -24)

# ================= реверберация (короткий воздушный хвост) =================
n = int(1.1 * SR); tt = np.arange(n) / SR
ir = np.stack([rng.normal(0, 1, n), rng.normal(0, 1, n)], 1) * np.exp(-tt / .28)[:, None]
ir[:int(.018 * SR)] = 0
for c in range(2): ir[:, c] = lp(hp(ir[:, c], 350), 7000)
ir /= np.sqrt((ir ** 2).sum(0))[None, :]
VERB = np.stack([fftconvolve(SEND[:, c], ir[:, c])[:N] for c in range(2)], 1) * .5

# ================= шина: приседание под голос, мягкая полка, лимит =================
v = np.frombuffer(subprocess.run(['ffmpeg', '-v', 'error', '-i', 'voice.wav', '-ac', '1', '-ar', str(SR), '-f', 's16le', '-'], capture_output=True).stdout, np.int16).astype(float) / 32767
v = np.pad(v, (0, max(0, N - len(v))))[:N]
env = np.sqrt(np.maximum(lp(v ** 2, 8), 0)); env = env / (env.max() + 1e-9)
duck = 1 - .32 * np.clip(env * 4, 0, 1)                                       # до −3,3 дБ под словами
STEMS = {'low': BUS['low'] * dB(2), 'air': BUS['air'] * duck[:, None] * dB(6), 'ui': BUS['ui'] * (1 - .15 * np.clip(env * 4, 0, 1))[:, None] * dB(0), 'verb': VERB * duck[:, None] * dB(3)}
mix = sum(STEMS.values())
mix[-int(.4 * SR):] *= np.linspace(1, 0, int(.4 * SR))[:, None]
pk = np.abs(mix).max(); g = min(1, .9 / pk)
def wr(p, a):
    f = wave.open(p, 'wb'); f.setnchannels(2); f.setsampwidth(2); f.setframerate(SR); f.writeframes((np.clip(a, -1, 1) * 32767).astype(np.int16).tobytes()); f.close()
for k, a in STEMS.items(): wr(f'stems_v6/sfx_{k}.wav', a * g)
wr('sfxV6.wav', mix * g)
print('пик', round(pk, 3), 'gain', round(g, 2))
