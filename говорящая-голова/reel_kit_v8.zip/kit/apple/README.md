# Стиль Apple (v6 утверждён 17.10.2026) — второй стиль монтажа
reference_apple_v6.html — шаблон HyperFrames (ролик со шляпой), reference_data.js — тайминги слов (WS/WE/WT).
lens.py — переход «жидкое стекло» постобработкой: `python3 lens.py out.mp4 T0 T1 CX CY seg.mp4`, затем overlay сегмента; фаза B (раздувание) должна закончиться ровно на склейке.
reference_mix_apple_v6.py — звук v6 (пути к words.json / voice.wav / паку — поправить под новый ролик). Пишет стемы и sfxV6.wav.
reference_apple_v6_540p.mp4 — эталон (уменьшенный).
