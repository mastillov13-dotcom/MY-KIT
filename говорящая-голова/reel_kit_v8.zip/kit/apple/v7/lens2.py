"""Переход «жидкое стекло» (как в референсе Apple): линза с преломлением → матовый пузырь раздувается на весь кадр →
молочная пелена расходится кругом и открывает новую сцену. Постобработка поверх рендера.
python3 lens.py in.mp4 T0 T1 CX CY out_seg.mp4   (кадры T0..T1 заменяются)"""
import sys, subprocess, numpy as np, cv2
src, T0, T1, CX, CY, out = sys.argv[1], float(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4]), float(sys.argv[5]), sys.argv[6]
W, H, FPS = 1080, 1920, 30
# тайминги фаз (секунды от начала ролика)
A0, A1 = T0 + .0, T0 + .16           # линза появляется
B0, B1 = T0 + .16, T0 + .52          # линза плавно (без рывка) раздувается на весь кадр
C0, C1 = T0 + .52, T1 - .02          # пелена расходится, открывая новую сцену
R0 = 235.
n = int(round((T1 - T0) * FPS))
raw = subprocess.run(['ffmpeg', '-v', 'error', '-ss', f'{T0:.4f}', '-i', src, '-frames:v', str(n), '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], capture_output=True).stdout
fr = np.frombuffer(raw, np.uint8).reshape(-1, H, W, 3).astype(np.float32) / 255.
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
dx, dy = xx - CX, yy - CY; D = np.sqrt(dx * dx + dy * dy) + 1e-6
ease = lambda u: 0 if u <= 0 else 1 if u >= 1 else u * u * (3 - 2 * u)
eio = lambda u: 0 if u <= 0 else 1 if u >= 1 else (4 * u ** 3 if u < .5 else 1 - (-2 * u + 2) ** 3 / 2)
eout = lambda u: 0 if u <= 0 else 1 if u >= 1 else 1 - (1 - u) ** 3
TINT = np.array([.80, .79, 1.0], np.float32)          # сиреневый оттенок стекла, как в референсе
RIM = int(np.ceil(np.sqrt(max(CX, W - CX) ** 2 + max(CY, H - CY) ** 2))) + 40

def refract(img, r, k=1.0):
    """линза: увеличение в центре, сжатие и выворот у края, хроматическая аберрация"""
    rho = np.clip(D / r, 0, 1)
    out = img.copy()
    inside = D < r
    for c, ab in enumerate((1.025, 1.0, .975)):
        s = (.74 + .26 * rho ** 2.2) * (1 - .55 * k * np.clip((rho - .78) / .22, 0, 1) ** 2) * ab
        s = 1 + (s - 1) * k
        mx, my = CX + dx * s, CY + dy * s
        ch = cv2.remap(np.ascontiguousarray(img[..., c]), mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        out[..., c] = np.where(inside, ch, img[..., c])
    return out

def glass_edges(img, r, a):
    """блик по краю, мягкая тень снаружи, светлое пятно сверху-слева"""
    ring = np.exp(-((D - r + 3) / 4.5) ** 2) * .4 + np.exp(-((D - r + 14) / 12) ** 2) * .12
    hx, hy = CX - r * .38, CY - r * .42
    spec = np.exp(-(((xx - hx) / (r * .32)) ** 2 + ((yy - hy) / (r * .16)) ** 2)) * .35 * (D < r)
    shadow = np.exp(-((D - r - 26) / 26) ** 2) * .16 * (D > r)
    img = img * (1 - shadow[..., None] * a) + (ring + spec)[..., None] * a
    return np.clip(img, 0, 1)

def blur(img, s):
    return cv2.GaussianBlur(img, (0, 0), s)

res = []
for i in range(n):
    t = T0 + i / FPS; f = fr[i]
    if t < B0:                                           # фаза A: линза
        a = ease((t - A0) / (A1 - A0)); r = R0 * (.55 + .45 * eout((t - A0) / (A1 - A0)))
        if a <= 0: res.append(f); continue
        g = refract(f, r, a)
        g = f * (1 - a) + g * a if a < 1 else g
        res.append(glass_edges(g, r, a)); continue
    if t < C0:                                           # фаза B: мутнеет и раздувается
        u = (t - B0) / (B1 - B0); us = .5 - .5 * np.cos(np.pi * u)              # синусная кривая без рывка
        r = float(np.exp(np.log(R0) + (np.log(RIM) - np.log(R0)) * us))          # рост в логарифме — ощущается равномерным
        g = refract(f, r, 1 - u * .8)
        fro = blur(f, 6 + 50 * u) * (1 - .22 * u) + TINT * .22 * u
        milky = .26 * u ** 2
        inner = g * (1 - min(1, u * 1.6)) + fro * min(1, u * 1.6)
        inner = inner * (1 - milky) + np.array([.97, .965, 1.0]) * milky
        m = (D < r)[..., None].astype(np.float32); m = cv2.GaussianBlur(m, (0, 0), 2.5)[..., None] if m.ndim == 2 else cv2.GaussianBlur(m[..., 0], (0, 0), 2.5)[..., None]
        res.append(glass_edges(f * (1 - m) + inner * m, r, 1)); continue
    # фаза C: молочная пелена расходится кругом от центра
    u = eout((t - C0) / (C1 - C0)); r2 = 40 + (RIM + 200) * u
    soft = 160
    m = np.clip((D - r2 + soft) / soft, 0, 1)[..., None]  # 0 внутри открытого круга, 1 снаружи
    fro = blur(f, 46 * (1 - u) + 4) * .78 + TINT * .1 + .08
    veil = np.clip(fro, 0, 1) * (1 - .4 * u)
    g = f * (1 - m) + veil * m * (1 - u * .6) + f * m * u * .6
    ring = np.exp(-((D - r2 + soft * .5) / 18) ** 2)[..., None] * .22 * (1 - u)
    res.append(np.clip(g + ring, 0, 1))

p = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                      '-c:v', 'libx264', '-crf', '12', '-preset', 'fast', '-pix_fmt', 'yuv420p', out], stdin=subprocess.PIPE)
for g in res: p.stdin.write((np.clip(g, 0, 1) * 255 + .5).astype(np.uint8).tobytes())
p.stdin.close(); p.wait(); print('кадров', len(res))
