# reel_kit_v8 — единый кит монтажа (30.10.2026; v7 от 19.10 + звуковой канон D2 + патч 30.10)

Один архив для всех скиллов монтажа: reel-montage-d2, reel-montage-apple, reel-montage-signal и их подстилей.
Распаковывать в /home/claude, чтобы получилось /home/claude/kit: старые скрипты ссылаются на этот путь.

Что где лежит:
- корень (cut.py, aqa.py, build_data.py, build_audio.py, asr_chrome.js, music2.py, mask.py, grade.*, sfx.py), voice/, burn/, fx/, v5/ — D2 v5 (база дизайна 1);
- apple/ — Apple v6 (база дизайна 2, README, lens.py);
- apple/v7/ — Apple v7, расширенный режим (тест): index.html, mix_events.py, lens2.py, takes.json, apple-v7-test-state.md, разбор референсов. Копия есть и в проекте, в claude/apple_v7/;
- signal/ — Сигнал (база дизайна 3, README, palette_board.py, redakt.js);
- substyles/ — 9 подстилей (D2/Apple/Сигнал × A/B/C), README с картой. Пути переносимые: папка ролика задаётся через SRC=… (по умолчанию substyles/src), там лежат words.js, voice.wav, graded.mp4 и person.webm;
- tools/check_cut.py — перепроверка нарезки до графики;
- pixel_preview/ — превью пиксельного стиля;
- fonts/ — все шрифты, sfx_library/ — звуки (alex_pack, ui_pack, SOUND_MAP.md).

- sfx_library/d2_canon/ — звуковой канон D2 (раньше отдельный d2_sound_canon_v1.zip), раздел «Не использовать» в README;
- sfx_library/gta_sa_main_theme.mp3 — трек Алекса для музыки по умолчанию (D2: с 9,88 с, −29 LUFS в стеме);
- tools/speed.py, person.py, finalmix.py, bounds.py — доускорение, person.webm, финальный микс с треком, проверка рамки числом;
- fonts/caveat — пропись D2 по умолчанию (Caveat 700).

Не входят в кит: модели распознавания (GigaAM) и маски (u2net), они в backup_4_modeli.zip.

---

# Кит монтажа «Стиль D2» (Алекс, говорящая голова, 9:16)

Порядок работы
1. Исходник → src.mov. Звук для распознавания: `ffmpeg -i src.mov -ac 1 -ar 16000 -c:a libopus audio.webm`.
2. Распознавание в Chrome: asr_chrome.js → words_raw.txt.
3. Выбрать дубли (в камеру — хук и призыв; чтение с ноутбука — под доску), записать в takes.json.
4. `python3 cut.py` — края в тишину, проверка срезанных слов, общий план звука, склейка кадр в кадр.
   Смотреть: «ПРОВЕРКА СЛОВ: всё чисто», voice_report.txt, «синхронно».
5. Готовую нарезку ещё раз прогнать через распознавание: ни одна фраза не повторяется, последнее слово целиком.
6. Положение лица: кадры с сеткой по дублям в камеру и по дублям с чтением (там голова ниже).
7. `python3 build_data.py projX hide.json` — подписи (mode short, 1–3 слова), тайминги слов.
8. `python3 sfx.py` (свой звуковой пак), `python3 music2.py <длина> 124 <seed> projX/music.wav`.
9. Шаблон по образцу reference_D2.html, звуковой план по образцу reference_plan_D2.py → `python3 build_audio.py projX plan.json`.
10. `npx hyperframes lint`, `snapshot`, `render` (HYPERFRAMES_BROWSER_PATH=/tmp/chromium, @sparticuz/chromium).
11. `python3 aqa.py out.mp4` — голос не пропал, эффекты не громче голоса. Сжать crf 21 (< 30 МБ), отправить.

## Резервная копия (17.10.2026)
- SKILL_reel-montage-d2_backup.md — текст скилла. Если скилл пропал из аккаунта: прислать этот файл Claude и попросить «восстанови скилл из файла».
- v5/reference_final_v5.mp4 — эталонный готовый ролик (красная майка v5).
- fonts/ — все шрифты, sfx_library/ — все звуки + SOUND_MAP.md.
