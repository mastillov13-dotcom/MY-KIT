"""Звук пиксельного превью «рабочий стол»: голос ElevenLabs + свои синты в духе старой ОС
(загрузочный аккорд, щелчки окон, печать), галочки, прогресс, нажатие кнопки, финальный аккорд."""
import json, wave, numpy as np
from scipy.signal import resample
SR = 48000; D = json.loads(open('proj/data.js').read().split('=', 1)[1].rstrip(';'))
P = D['ph']; T = lambda i: P[i]['s']; E = lambda i: P[i]['e']
N = int(9.1 * SR); st = {k: np.zeros((N, 2)) for k in ('voice', 'sfx')}; cache = {}
def load(n):
    f = wave.open(f'/home/claude/red3/sfx/{n}.wav'); a = np.frombuffer(f.readframes(f.getnframes()), np.int16).astype(float) / 32767
    return a.reshape(-1, f.getnchannels())
def put(a, t, g):
    i = int(t * SR); m = min(len(a), N - i)
    if m > 0: st['sfx'][i:i + m] += a[:m] * g
def X(n, t, g, rate=1.0):
    k = (n, rate)
    if k not in cache:
        a = load(n)
        if rate != 1: a = np.stack([resample(a[:, c], int(len(a) / rate)) for c in range(2)], 1)
        cache[k] = a
    put(cache[k], t, g)
def tone(fs, d, g=.3, attack=.01, rel=.3):
    t = np.arange(int(d * SR)) / SR; s = sum(np.sin(2 * np.pi * f * t) * (.6 ** k) for k, f in enumerate(fs))
    env = np.minimum(1, t / attack) * np.exp(-t / rel); return np.repeat((s * env * g)[:, None], 2, 1)
def chord(notes, t0, step, d, g):
    for k, f in enumerate(notes): put(tone([f, f * 2, f * 3], d, g, .02, d / 2.5), t0 + k * step, 1)
# загрузочный аккорд (свой синт)
chord([392, 523.25, 659.25, 783.99], .0, .07, .9, .07)
def win_open(t): put(tone([880, 1320], .09, .12, .002, .03), t, 1); X('k_click', t + .1, .1)
for t in (0.0, T(0) - .12, T(1) - .1, T(2) - .04): win_open(t + .12)
bed = load('k_tw_bed')
def typing(t0, d, g=.09):
    out = np.zeros((int(d * SR), 2)); i = 0; rng = np.random.default_rng(int(t0 * 100))
    while i < len(out):
        p = int(rng.uniform(0, len(bed) / SR - .6) * SR); take = min(len(out) - i, len(bed) - p); out[i:i + take] += bed[p:p + take]; i += take
    f = int(.02 * SR); out[:f] *= np.linspace(0, 1, f)[:, None]; out[-f:] *= np.linspace(1, 0, f)[:, None]; put(out, t0, g)
typing(T(0) + .05, E(0) - .2 - T(0)); typing(T(1) + .02, E(1) - .12 - T(1)); typing(T(2) + .05, E(2) - .15 - T(2))
for k, i in enumerate((3, 4, 5, 6)):
    X('ui_06', T(i) + .18, .12, rate=1 + .08 * k)
    for j in range(6): put(tone([660 + 40 * (k * 6 + j)], .03, .05, .001, .01), T(i) + .05 + j * ((E(i) - T(i) - .1) / 6), 1)
X('mouse_click', T(7) + .04, .16)
win_open(T(7) + .3); X('whoosh_2', T(7) + .25, .06)
chord([523.25, 659.25, 783.99, 1046.5], 8.55, .05, .7, .08)
# голос со сдвигом
f = wave.open('leonid1_vo.wav'); v = np.frombuffer(f.readframes(f.getnframes()), np.int16).astype(float) / 32767
i = int(D['off'] * SR); m = min(len(v), N - i); st['voice'][i:i + m] += np.repeat(v[:m, None], 2, 1)
e = np.abs(st['voice'][:, 0]); k = int(.08 * SR); env = np.convolve(e, np.ones(k) / k, 'same'); env /= env.max()
st['sfx'] *= (1 - .3 * np.clip(env * 4, 0, 1))[:, None]
fo = int(.25 * SR)
for kk in st: st[kk][-fo:] *= np.linspace(1, 0, fo)[:, None]
mix = sum(st.values()); g = min(1, .97 / np.abs(mix).max())
def wr(n, a):
    w = wave.open(n, 'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(a * g, -1, 1) * 32767).astype(np.int16).tobytes()); w.close()
wr('mix.wav', mix); wr('stem_voice.wav', st['voice']); wr('stem_sfx.wav', st['sfx']); print('ok')
