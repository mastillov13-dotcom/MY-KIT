// Стиль «Редакция»: общие приёмы. Подключать после gsap и data.js (window.R = {w:[{w,s,e}], total, env?}).
// Канон: текст выезжает из-под невидимой линии, линии прорисовываются, одна новая вещь за раз,
// переход — линия-развёртка, склейка на крупный ×1,4–1,5, стоп-кадр с затвором, штамп.
window.RK = function (tl, o) {
  const IR = { immediateRender: false };
  const $ = s => typeof s === "string" ? document.querySelectorAll(s) : (s.length !== undefined ? s : [s]);
  const W = i => R.w[i].s, WE = i => R.w[i].e;
  const FACE = o.face || "540px 660px";
  gsap.set([".pan", ".jolt", ".camzoom"], { transformOrigin: FACE });
  tl.set(".jolt", { scale: 1 }, 0); tl.set(".camzoom", { scale: 1 }, 0); tl.set(".pan", { scale: 1 }, 0);
  tl.set(".cam", { y: 0, clipPath: "inset(0px 0px 0px 0px)", filter: "brightness(1) blur(0px)" }, 0);

  const hide = sel => $(sel).forEach(e => gsap.set(e, { opacity: 0 }));
  // выезд из-под линии: .rm (overflow hidden) > .ri
  const rise = (sel, t, st, d) => { const els = []; $(sel).forEach(e => e.classList.contains("ri") ? els.push(e) : e.querySelectorAll(".ri").forEach(x => els.push(x)));
    els.forEach((e, k) => { gsap.set(e, { yPercent: 115 }); tl.fromTo(e, { yPercent: 115 }, { yPercent: 0, duration: d || .55, ease: "power3.out", ...IR }, t + k * (st || .12)); }); };
  const sink = (sel, t, st) => { const els = []; $(sel).forEach(e => e.classList.contains("ri") ? els.push(e) : e.querySelectorAll(".ri").forEach(x => els.push(x)));
    els.forEach((e, k) => tl.to(e, { yPercent: -115, duration: .32, ease: "power2.in" }, t + k * (st || .04))); };
  const show = (sel, t, d) => (hide(sel), tl.fromTo(sel, { opacity: 0 }, { opacity: 1, duration: d || .2, ease: "none", ...IR }, t));
  const out = (sel, t, d) => tl.to(sel, { opacity: 0, duration: d || .25, ease: "power2.in" }, t);
  const lineX = (sel, t, d, from) => { gsap.set(sel, { scaleX: 0, transformOrigin: from || "0% 50%" }); tl.fromTo(sel, { scaleX: 0 }, { scaleX: 1, duration: d || .5, ease: "power2.inOut", ...IR }, t); };
  const lineY = (sel, t, d) => { gsap.set(sel, { scaleY: 0, transformOrigin: "50% 0%" }); tl.fromTo(sel, { scaleY: 0 }, { scaleY: 1, duration: d || .4, ease: "power2.inOut", ...IR }, t); };
  const draw = (sel, t, d) => $(sel).forEach(p => { gsap.set(p, { strokeDasharray: 1, strokeDashoffset: 1 }); tl.fromTo(p, { strokeDashoffset: 1 }, { strokeDashoffset: 0, duration: d || .5, ease: "power2.inOut", ...IR }, t); });
  const pop = (sel, t, s) => (hide(sel), tl.fromTo(sel, { opacity: 0, scale: s || .7 }, { opacity: 1, scale: 1, duration: .3, ease: "back.out(2.2)", ...IR }, t));
  // счётчик: шаги tl.set, замедление к концу
  const count = (sel, t, a, b, d, fmt, n) => { const el = $(sel)[0]; n = n || Math.max(8, Math.round(d * 30));
    for (let k = 0; k <= n; k++) { const p = 1 - Math.pow(1 - k / n, 3); const v = a + (b - a) * p; tl.set(el, { textContent: (fmt || (x => Math.round(x)))(v) }, t + d * k / n); } };
  // печать: буквы появляются, курсор
  const type = (sel, t, d) => { const el = $(sel)[0]; const txt = el.textContent; el.textContent = "";
    const sp = [...txt].map(c => { const s = document.createElement("span"); s.textContent = c; s.style.display = "none"; el.appendChild(s); return s; });
    sp.forEach((s, k) => tl.set(s, { display: "inline" }, t + d * k / sp.length)); return sp; };
  const stamp = (sel, t, r) => { hide(sel); tl.fromTo(sel, { opacity: 0, scale: 2.1, rotation: (r || -8) - 6 }, { opacity: 1, scale: 1, rotation: r || -8, duration: .26, ease: "back.out(2.6)", ...IR }, t); punch(t + .18, 1.04); };
  const push = (t, d, a, b) => tl.fromTo(".pan", { scale: a }, { scale: b, duration: d, ease: "none", ...IR }, t);
  const punch = (t, k) => tl.fromTo(".jolt", { scale: k || 1.1 }, { scale: 1, duration: .32, ease: "power3.out", ...IR }, t);
  const snap = (t, k) => tl.set(".camzoom", { scale: k }, t);                       // склейка на крупный
  const flash = (t, a) => { tl.fromTo("#flash", { opacity: 0 }, { opacity: a || .8, duration: .04, ...IR }, t); tl.to("#flash", { opacity: 0, duration: .12 }, t + .04); };
  // переход: линия проходит сверху вниз, за ней меняется раскладка
  const sweep = (t, fn) => { tl.fromTo("#sweep", { y: -20, opacity: 1 }, { y: 1940, duration: .46, ease: "power2.inOut", ...IR }, t); tl.set("#sweep", { opacity: 0 }, t + .47); if (fn) fn(t + .2); };
  // сплит: лицо в верхнюю часть, снизу панель
  const splitOn = (t, dy, cut) => { tl.to(".cam", { y: dy, clipPath: `inset(${-dy}px 0px ${1920 - cut + dy}px 0px)`, duration: .5, ease: "expo.inOut" }, t);
    tl.fromTo("#bot", { y: 1000 }, { y: 0, duration: .5, ease: "expo.inOut", ...IR }, t); tl.set("#bot", { opacity: 1 }, t); };
  const splitOff = (t) => { tl.to(".cam", { y: 0, clipPath: "inset(0px 0px 0px 0px)", duration: .45, ease: "expo.inOut" }, t);
    tl.to("#bot", { y: 1000, duration: .45, ease: "expo.inOut" }, t); };
  // стоп-кадр: кадр замирает, становится фото в рамке
  const freeze = (t, hold, rot) => { tl.set("#still", { opacity: 1, scale: 1, rotation: 0, x: 0, y: 0 }, t); tl.set("#stillbg", { opacity: 1 }, t); flash(t, .9);
    tl.to("#still", { scale: .8, rotation: rot || -3, duration: .45, ease: "expo.out" }, t + .04);
    tl.to("#still", { scale: 1, rotation: 0, duration: .4, ease: "expo.inOut" }, t + hold);
    tl.set(["#still", "#stillbg"], { opacity: 0 }, t + hold + .4); };
  // фразовые субтитры: до 5 слов, 1–2 строки, смена целиком
  const caps = (hideWins, y) => {
    const host = document.getElementById("caps"); host.style.top = (y || 1440) + "px";
    const hidden = (s, e) => hideWins.some(([a, b]) => s < b && e > a);
    const ph = []; let cur = [];
    R.w.forEach((w, i) => { cur.push(i); const txt = cur.map(k => R.w[k].w).join(" ");
      const weak = /^(в|и|на|с|к|о|а|но|для|что|не|за|от|по|из|у|же|ни|как|это)$/i.test(w.w);
      if (/[.,!?:»]$/.test(w.w) && cur.length >= 2 || (cur.length >= 5 || txt.length > 26) && !weak || cur.length >= 7) { ph.push(cur); cur = []; } });
    if (cur.length) ph.push(cur);
    ph.forEach((p, n) => { const s = W(p[0]) - .04, e = n + 1 < ph.length ? Math.min(W(ph[n + 1][0]) - .04, WE(p[p.length - 1]) + .6) : WE(p[p.length - 1]) + .5;
      if (hidden(s, e)) return;
      const d = document.createElement("div"); d.className = "cap"; const ws = p.map(k => R.w[k].w.replace(/[«»]/g, ""));
      const half = ws.length > 3 ? Math.ceil(ws.length / 2) : ws.length;
      d.innerHTML = `<span>${ws.slice(0, half).join(" ")}</span>` + (half < ws.length ? `<br><span>${ws.slice(half).join(" ")}</span>` : "");
      host.appendChild(d); gsap.set(d, { opacity: 0 }); tl.set(d, { opacity: 1 }, s); tl.set(d, { opacity: 0 }, e); }); };
  return { W, WE, IR, hide, rise, sink, show, out, lineX, lineY, draw, pop, count, type, stamp, push, punch, snap, flash, sweep, splitOn, splitOff, freeze, caps };
};
