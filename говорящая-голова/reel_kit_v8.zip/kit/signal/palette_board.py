from playwright.sync_api import sync_playwright
P=[("A","Тёплый песок","#F3ECE2","#1D1B19","#E8872E","rgba(29,27,25,.5)"),
   ("B","Кобальт","#F6F6F3","#15161A","#2F5BFF","rgba(21,22,26,.5)"),
   ("C","Сирень","#EEEAFE","#17142B","#6A4CFF","rgba(23,20,43,.5)"),
   ("D","Лайм на графите","#1E2023","#F3F3EF","#C6F24E","rgba(243,243,239,.55)")]
T='''<html><head><style>
@font-face{font-family:U;font-weight:800;src:url(unbounded-cyrillic-800-normal.woff2)}
@font-face{font-family:G;font-weight:400;src:url(geologica-cyrillic-400-normal.woff2)}
@font-face{font-family:J;src:url(jetbrains-mono-cyrillic-500-normal.woff2)}
body{margin:0;width:1080px;height:1920px;background:url(frame.jpg);position:relative;overflow:hidden}
.lab{position:absolute;left:24px;top:24px;font:500 28px J;background:rgba(0,0,0,.6);color:#fff;padding:6px 14px}
.pn{position:absolute;left:70px;top:1060px;width:808px;box-sizing:border-box;padding:28px 36px 32px;background:PB;color:TX;box-shadow:0 24px 60px rgba(0,0,0,.35)}
.bar{position:absolute;left:0;top:0;width:8px;height:100%;background:AC}
.m{font:500 22px J;letter-spacing:.14em;text-transform:uppercase;color:MU}
.u{font:800 96px U;letter-spacing:-.02em}
.d{font:400 54px/1.15 G}
.st{position:absolute;left:520px;top:960px;padding:12px 26px 14px;border:5px solid AC;color:STC;background:STB;font:800 60px U;transform:rotate(-7deg)}
.hud{position:absolute;left:70px;top:230px;font:500 22px J;letter-spacing:.14em;color:#fff}
.hud i{display:inline-block;width:12px;height:12px;border-radius:50%;background:AC;margin-right:12px}
.cap{position:absolute;left:90px;width:900px;top:1480px;text-align:center;font:600 48px G}
.cap span{background:CB;color:CT;padding:2px 16px 6px}
</style></head><body><div class=lab>LBL</div>
<div class=hud><i></i>СИГНАЛ · ПРОМПТ</div>
<div class=pn><div class=bar></div><div style="display:flex;align-items:baseline;gap:22px"><div class=u>ПРОМПТ</div><div class=m>[сущ.]</div></div>
<div style="height:1px;background:MU;opacity:.4;margin:10px 0 16px"></div><div class=d>понятное задание для <span style="color:AC2">нейросети</span></div></div>
<div class=st>НЕ МАГИЯ</div><div class=cap><span>не специальный язык программистов</span></div></body></html>'''
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/tmp/chromium'); pg=b.new_page(viewport={'width':1080,'height':1920})
    for k,n,pb,tx,ac,mu in P:
        dark = k=='D'
        h=(T.replace('PB',pb).replace('TX',tx).replace('AC2',ac if not dark else ac).replace('AC',ac).replace('MU',mu).replace('LBL',f'{k} · {n}')
           .replace('STC',ac if dark else ac).replace('STB','rgba(30,32,35,.92)' if dark else pb)
           .replace('CB',pb).replace('CT',tx))
        if k=='A': h=h.replace('color:'+ac+'">нейросети','color:#C2661A">нейросети')
        open(k+'.html','w').write(h); pg.goto(f'file:///home/claude/red3/pal/{k}.html'); pg.wait_for_timeout(500); pg.screenshot(path=k+'.png')
    b.close()
