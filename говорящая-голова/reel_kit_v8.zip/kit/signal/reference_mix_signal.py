"""Звук стиля «Редакция» для трёх роликов: python3 mix.py v1|v2|v3
Слои: голос (чистый) + эффекты из паков Алекса (по канону: тики на линиях, подъём перед цифрой,
счётчик, затвор+бас на стоп-кадр, удар на штамп, развёртка-переход) + тихий пульс, у каждого варианта свой.
Эффекты приседают под голосом (до −3 дБ). Стемы: voice / sfx / bed."""
import sys, json, wave
import numpy as np
from scipy.signal import resample, butter, sosfilt
V = sys.argv[1]; SR = 48000; BASE = 'v2'
words = json.load(open(f'{V}/words.json')); W = lambda i: words[i]['s']
TOT = {'v1': 39.233, 'v2': 38.367, 'v3': 46.267, 'v2a': 38.367, 'v2b': 38.367}[V]; N = int((TOT + .05) * SR)
st = {k: np.zeros((N, 2)) for k in ('voice', 'sfx', 'acc', 'bed')}; cache = {}; rng = np.random.default_rng(7)
def load(n):
    f = wave.open(f'sfx/{n}.wav'); a = np.frombuffer(f.readframes(f.getnframes()), np.int16).astype(float) / 32767
    return a.reshape(-1, f.getnchannels())
def X(n, t, g, rate=1.0, pan=0.0, cut=None, to='sfx'):
    k = (n, rate)
    if k not in cache:
        a = load(n)
        if rate != 1.0: a = np.stack([resample(a[:, c], int(len(a) / rate)) for c in range(2)], 1)
        cache[k] = a
    a = cache[k] * g
    if cut: m = int(cut * SR); a = a[:m].copy(); f = int(.03 * SR); a[-f:] *= np.linspace(1, 0, f)[:, None]
    if pan: a = a * np.array([min(1, 1 - pan), min(1, 1 + pan)])
    i = int(t * SR)
    if i < 0: a = a[-i:]; i = 0
    m = min(len(a), N - i)
    if m > 0: st[to][i:i + m] += a[:m]
def typing(t0, d, g=.14, src='k_tw_bed'):
    bed = load(src); out = np.zeros((int(d * SR), 2)); i = 0
    while i < len(out):
        pos = int(rng.uniform(0, max(.01, len(bed) / SR - .6)) * SR); take = min(len(out) - i, len(bed) - pos)
        out[i:i + take] += bed[pos:pos + take]; i += take
    f = int(.02 * SR); out[:f] *= np.linspace(0, 1, f)[:, None]; out[-f:] *= np.linspace(1, 0, f)[:, None]
    j = int(t0 * SR); m = min(len(out), N - j); st['sfx'][j:j + m] += out[:m] * g
def bed(kind, g):
    t = np.arange(N) / SR; out = np.zeros(N)
    if kind == 'paper':                                   # мягкий низкий пульс 84 BPM
        B = 60 / 84
        for b in np.arange(.0, TOT, B):
            i = int(b * SR); n = int(.35 * SR); tt = np.arange(n) / SR
            out[i:i + n][:min(n, N - i)] += (np.sin(2 * np.pi * 58 * tt) * np.exp(-tt * 14) + .35 * np.sin(2 * np.pi * 116 * tt) * np.exp(-tt * 20))[:min(n, N - i)]
    elif kind == 'signal':                                # 120 BPM: глухая бочка + тихие шестнадцатые
        B = .5; noise = rng.standard_normal(N); hp = sosfilt(butter(4, 7000, 'hp', fs=SR, output='sos'), noise)
        for b in np.arange(0, TOT, B):
            i = int(b * SR); n = int(.25 * SR); tt = np.arange(n) / SR; m = min(n, N - i)
            out[i:i + m] += (np.sin(2 * np.pi * (52 + 60 * np.exp(-tt * 30)) * tt) * np.exp(-tt * 16))[:m]
        for b in np.arange(0, TOT, B / 4):
            i = int(b * SR); n = int(.03 * SR); m = min(n, N - i); acc = 1 if round(b / (B / 4)) % 2 else .5
            out[i:i + m] += hp[i:i + m] * np.exp(-np.arange(m) / SR * 160) * .18 * acc
    elif kind == 'clock':                                 # тик-так 100 BPM: корректор с секундомером
        B = .6; bp = butter(2, [1800, 5200], 'bp', fs=SR, output='sos'); noise = rng.standard_normal(int(.02 * SR))
        clk = sosfilt(bp, noise) * np.exp(-np.arange(len(noise)) / SR * 300)
        for k, b in enumerate(np.arange(0, TOT, B)):
            i = int(b * SR); m = min(len(clk), N - i); out[i:i + m] += clk[:m] * (1 if k % 2 == 0 else .6)
            n = int(.3 * SR); tt = np.arange(n) / SR; m2 = min(n, N - i)
            if k % 4 == 0: out[i:i + m2] += (.5 * np.sin(2 * np.pi * 64 * tt) * np.exp(-tt * 12))[:m2]
    f = int(1.0 * SR); out[:f] *= np.linspace(0, 1, f); out[-f:] *= np.linspace(1, 0, f)
    st['bed'] += np.repeat(out[:, None], 2, 1) * g

CL = lambda t, g=.1: X('k_click', t, g)
# ---------------- события ----------------
if V == 'v1':
    bed('paper', .05)
    X('k_tap', .2, .05); X('fast_whoosh', -.02, .07); X('k_thock', .12, .08); X('ui_01', .1, .05)
    X('k_thock', W(1), .09); X('k_thock', W(3), .08); X('k_swoosh', W(5), .04); X('ui_01', W(8) - .02, .06)
    X('whoosh_1', W(9) - .3, .05); X('k_impact', W(9) - .02, .05)
    for t in (3.42, 15.72, 30.32): X('whoosh_1_2', t - .12, .14); X('whoosh_2', t + .02, .05, pan=-.2)
    for k, i in enumerate((12, 19, 24, 30)): X('k_tap', W(i) + .02, .1); X('k_swoosh', W(i) + .22, .03, pan=.3)
    X('ui_01', W(34) - .05, .05)
    for t, u in ((11.45, 11.62), (24.85, 25.0), (34.05, 34.12)): X('whoosh_5', t, .04); X('whoosh_3', u - .1, .05)
    for t in (11.87, 25.2, 28.35): CL(t - .02, .1)
    X('fast_whoosh', W(36), .07); X('k_thock', W(37), .08); X('k_tap', W(40) - .1, .06); X('ui_08', W(45) - .05, .1, cut=.7)
    X('whoosh_1', W(45) - .3, .05); X('k_impact', W(45) - .03, .05)
    for k, i in enumerate((50, 51, 52, 54)): X('ui_06', W(i) - .02, .11, rate=1 + .06 * k)
    X('k_thock', W(56), .1); X('k_thock', W(60), .1); X('k_tap', W(61) - .1, .06)
    X('ui_08', W(64) - .1, .1, cut=.6); X('coin_collect', W(64) + .5, .09)
    X('ui_06', W(68), .11, rate=1.1); X('ui_06', W(73), .11, rate=1.2)
    X('fast_whoosh', W(74) - .05, .07)
    for k, i in enumerate((75, 76, 77, 79)): X('ui_06', W(i), .1, rate=.95 + .07 * k)
    X('riser_3', W(81) - 1.2, .05, cut=1.2); X('whoosh_1', W(81) - .3, .05); X('k_impact', W(81) - .03, .05)
    X('fast_whoosh', W(84), .07); X('k_strike', W(87) + .05, .13)
    X('k_swoosh', 31.0, .05); X('k_thock', W(93), .08)
    for d in (0, .08, .16): X('k_swoosh', W(98) - .1 + d, .04, pan=.4)
    for k, d in enumerate((-.05, .12, .29)): X('ui_06', W(99) + d, .1, rate=1 + .08 * k)
    X('hit_2', W(100), .08)
    F = W(101) + .03; X('camera_flash', F - .02, .2); X('bass_1', F, .12); X('k_low_boom', F, .05)
    X('hit_1', F + .29, .12); X('whoosh_2', F + 1.5, .05)
    X('fast_whoosh', W(105) - .05, .07); X('ui_01', W(107) - .05, .05); X('ui_09', 38.3, .05)
    voice = 'v1/voice.wav'
elif V in ('v2a', 'v2b'):
    import wave as _w
    f = _w.open(f'{V}/music.wav'); mu = np.frombuffer(f.readframes(f.getnframes()), np.int16).astype(float).reshape(-1, f.getnchannels()) / 32767
    if f.getframerate() != SR: mu = np.stack([resample(mu[:, c], int(len(mu) * SR / f.getframerate())) for c in range(mu.shape[1])], 1)
    if mu.shape[1] == 1: mu = np.repeat(mu, 2, 1)
    m = min(len(mu), N); st['bed'][:m] += mu[:m] * .17
    X('ui_01', .1, .05)
    X('fast_whoosh', .08, .07); X('ui_08', W(4) - .3, .12, cut=.45); X('k_thock', W(4) + .12, .09)
    X('whoosh_1', W(4) - .3, .05); X('k_impact', W(4) - .02, .05)
    for k in range(4): X('k_strike', W(6) - .06 + k * .075, .11, rate=.9 + .08 * k, pan=(-.3 + .2 * k))
    X('ui_07', W(6) + .05, .09); X('bass_1', W(6) + .2, .07, to='acc')
    X('ui_08', W(8) + .1, .08, rate=.85, cut=.55); X('ui_01', W(9), .05)
    for t in (3.87, 27.1): CL(t - .02, .11)
    X('fast_whoosh', W(12) - .1, .07); X('k_thock', W(12), .09); X('ui_01', W(13), .05); X('k_swoosh', W(13) + .05, .03)
    for i in (14, 15, 16, 17): X('k_tap', W(i) - .03, .05)
    for i, h in ((19, 'hit_1'), (24, 'hit_2')):                                  # штамп: слоёный удар, без приседания
        X(h, W(i), .2, to='acc'); X('bass_1', W(i) + .01, .16, to='acc'); X('k_thock', W(i) + .02, .14, to='acc')
        X('k_low_boom', W(i) + .02, .08, to='acc'); X('camera_flash', W(i) + .15, .06, to='acc'); X('whoosh_1', W(i) - .32, .05)
    for t in (9.05, 30.9): X('whoosh_1_2', t - .12, .15); X('whoosh_2', t + .05, .05)
    X('k_thock', W(27), .08); X('ui_01', W(30) - .1, .05)
    for d in (0, .07, .14): X('k_swoosh', W(30) + .05 + d, .04)
    for k, i in enumerate((32, 34, 38)): X('ui_06', W(i) - .05, .11, rate=1 + .07 * k)
    X('whoosh_5', 14.7, .04); X('whoosh_3', 14.75, .05)
    X('k_low_boom', 15.0, .05); X('fast_whoosh', 15.0, .09)
    X('ui_09', W(46) - .02, .1); X('mouse_click', W(46) - .06, .08); X('ui_01', W(45), .05); X('k_swoosh', W(46) + .15, .05, pan=.3)
    X('ui_01', W(48), .05); typing(W(49), W(66) + .3 - W(49), .1, 'keyboard'); X('k_swoosh', W(49) + .3, .05, pan=-.3)
    X('ui_09', W(66) + .32, .09)
    for k, i in enumerate((72, 73, 76)): X('mouse_click', W(i) - .05, .1); X('ui_06', W(i) - .03, .07, rate=1 + .08 * k)
    X('whoosh_4', 26.7, .06)
    X('fast_whoosh', W(82) - .25, .06)
    for k in range(5): X('k_tap', W(83) - .05 + k * .1, .06)
    X('whoosh_1', W(83) - .3, .05); X('k_impact', W(83) - .02, .05)
    X('riser_1', W(91) - 1.0, .06, cut=1.0); X('fast_whoosh', W(88), .06)
    X('k_thock', W(91) - .04, .11)
    for i in (92, 93): X('pop', W(i) - .1, .06); X('k_thock', W(i) - .04, .11)
    X('k_tap', W(93) + .3, .06); X('hit_2', W(93) + .45, .13, to='acc'); X('bass_1', W(93) + .46, .1, to='acc')
    X('fast_whoosh', W(95) - .1, .07); typing(W(95) + .05, .45, .13, 'keyboard')
    X('fast_whoosh', W(96) - .05, .06); X('ui_08', W(96) + .2, .07, cut=1.4); X('ui_09', W(96) + 1.62, .1); X('level_up', W(96) + 1.66, .06)
    voice = 'v2/voice_d.wav'
elif V == 'v2':
    bed('signal', .045)
    X('ui_01', .1, .05)
    X('fast_whoosh', .08, .07); X('ui_08', W(4) - .3, .12, cut=.45); X('k_thock', W(4) + .12, .09)
    X('whoosh_1', W(4) - .3, .05); X('k_impact', W(4) - .02, .05)
    X('k_strike', W(6) - .05, .14); X('ui_07', W(8) + .1, .1); X('ui_08', W(8) + .1, .08, rate=.85, cut=.55); X('ui_01', W(9), .05)
    for t in (3.87, 27.1): CL(t - .02, .11)
    X('fast_whoosh', W(12) - .1, .07); X('k_thock', W(12), .09); X('ui_01', W(13), .05); X('k_swoosh', W(13) + .05, .03)
    for i in (14, 15, 16, 17): X('k_tap', W(i) - .03, .05)
    X('hit_1', W(19), .12); X('whoosh_1', W(19) - .3, .04); X('hit_2', W(24), .12); X('k_impact', W(24) - .02, .05)
    for t in (9.05, 30.9): X('whoosh_1_2', t - .12, .15); X('whoosh_2', t + .05, .05)
    X('k_thock', W(27), .08); X('ui_01', W(30) - .1, .05)
    for d in (0, .07, .14): X('k_swoosh', W(30) + .05 + d, .04, pan=-.4 + .4 * (d / .07))
    for k, i in enumerate((32, 34, 38)): X('ui_06', W(i) - .05, .11, rate=1 + .07 * k)
    X('whoosh_5', 14.7, .04); X('whoosh_3', 14.75, .05)
    X('k_low_boom', 15.0, .05); X('fast_whoosh', 15.0, .09)
    X('ui_01', W(45), .05); X('ui_09', W(46) - .02, .1); X('mouse_click', W(46) - .06, .08)
    X('ui_01', W(48) - .05, .05); typing(W(49), W(66) + .3 - W(49), .1, 'keyboard')
    X('ui_09', W(66) + .32, .09)
    for k, i in enumerate((72, 73, 76)): X('mouse_click', W(i) - .05, .1); X('ui_06', W(i) - .03, .07, rate=1 + .08 * k)
    X('whoosh_4', 26.7, .06)
    X('fast_whoosh', W(82) - .25, .06)
    for k in range(5): X('k_tap', W(83) - .05 + k * .1, .06)
    X('whoosh_1', W(83) - .3, .05); X('k_impact', W(83) - .02, .05)
    X('riser_1', W(91) - 1.0, .06, cut=1.0); X('fast_whoosh', W(88), .06)
    for i in (91, 92, 93): X('k_thock', W(i) - .04, .11); X('k_impact', W(i) - .04, .045)
    X('fast_whoosh', W(94) - .05, .07); typing(W(95), .45, .12, 'keyboard'); X('ui_09', W(96) - .05, .1); X('pop', W(96) - .05, .06)
    X('ui_01', W(97) - .05, .05); X('level_up', 37.5, .05)
    voice = 'v2/voice_d.wav'
else:
    bed('clock', .05)
    X('fast_whoosh', -.02, .07); X('ui_01', .1, .05); X('k_thock', W(0), .09); X('k_thock', W(1), .08); X('ui_01', W(2), .05)
    X('k_scribble', W(2) + .3, .12); CL(1.53, .1)
    for i in (7, 8, 9, 10, 11): X('k_tap', W(i) - .03, .045)
    X('whoosh_1', W(8) - .3, .05); X('k_impact', W(8) - .02, .05); X('k_strike', W(10), .13); X('k_scribble', W(11) - .1, .08)
    for t in (6.01, 31.38, 36.25): CL(t - .02, .1)
    X('fast_whoosh', W(12) - .05, .06); X('ui_01', W(19) - .05, .04); X('fast_whoosh', W(21) - .05, .06); X('ui_01', W(26) - .05, .04)
    X('whoosh_1', W(22) - .3, .05); X('k_impact', W(22) - .02, .05); X('hit_2', W(27), .1)
    for t in (12.6, 20.75): X('whoosh_1_2', t - .12, .15); X('whoosh_2', t + .1, .05)
    X('ui_01', W(36), .05); X('hit_1', W(42) - .05, .11); X('k_tap', W(43) - .1, .05)
    for k, i in enumerate((45, 47, 50)): X('ui_06', W(i) - .08, .1, rate=1 + .07 * k); X('k_scribble', W(i) + .35, .08, rate=1.2)
    X('whoosh_5', 20.55, .04)
    X('fast_whoosh', 20.95, .07); typing(W(53), W(77) + .2 - W(53), .12)
    X('k_swoosh', 30.4, .03); X('mouse_click', 31.1, .14)
    X('ui_01', 31.45, .05); X('k_strike', W(85) - .05, .12)
    for k in range(8): X('k_tap', 32.0 + k * .12, .03)
    for k, i in enumerate((88, 89, 90)): X('ui_06', W(i) + .05, .11, rate=1 + .08 * k)
    X('ui_08', W(88), .07, cut=W(90) - W(88) + .1); X('k_thock', W(90) + .2, .08)
    X('whoosh_5', 35.95, .04); X('whoosh_3', 35.95, .05)
    X('fast_whoosh', W(92) - .05, .06); X('k_scribble', W(99) + .35, .12)
    F = W(102); X('camera_flash', F - .02, .2); X('bass_1', F, .12); X('k_low_boom', F, .05); X('hit_1', F + .29, .12); X('whoosh_2', F + 1.45, .05)
    X('fast_whoosh', W(108) - .05, .07); typing(W(109), .5, .12); X('ui_09', W(110) - .05, .1); X('pop', W(110) - .05, .06); X('ui_01', W(111) - .05, .05)
    voice = 'v3/voice_p.wav'

f = wave.open(voice); v = np.frombuffer(f.readframes(f.getnframes()), np.int16).astype(float) / 32767
if f.getnchannels() == 2: v = v.reshape(-1, 2).mean(1)
if f.getframerate() != SR: v = resample(v, int(len(v) * SR / f.getframerate()))
m = min(len(v), N); st['voice'][:m] += np.repeat(v[:m, None], 2, 1)
# эффекты и пульс приседают под голосом
e = np.abs(st['voice'][:, 0]); k = int(.08 * SR); env = np.convolve(e, np.ones(k) / k, 'same'); env = env / (env.max() + 1e-9)
duck = 1 - .3 * np.clip(env * 4, 0, 1); st['sfx'] *= duck[:, None]; st['bed'] *= (1 - .5 * np.clip(env * 4, 0, 1))[:, None]
fo = int(.4 * SR)
for kk in st: st[kk][-fo:] *= np.linspace(1, 0, fo)[:, None]
mix = sum(st.values()); g = min(1, .97 / np.abs(mix).max())
def wr(n, a):
    w = wave.open(n, 'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(a * g, -1, 1) * 32767).astype(np.int16).tobytes()); w.close()
wr(f'{V}/mix.wav', mix)
for kk, a in st.items(): wr(f'{V}/stem_{kk}.wav', a)
print(V, 'peak', round(float(np.abs(mix).max()), 2))
