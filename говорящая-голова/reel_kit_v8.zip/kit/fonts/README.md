# Библиотека шрифтов (все с кириллицей, woff2, @fontsource, лицензия OFL)
Подключение в шаблоне: <link rel="stylesheet" href="fonts/fonts.css"> (папку fonts положить рядом с index.html).

Канон D2: Alumni Sans 900/800 (крупное, субтитры) + Marck Script (рукопись) + JetBrains Mono (мелкий интерфейс).

Серьёзные (крупные слова): Alumni Sans, Oswald, Dela Gothic One, Tektur, Unbounded, Rubik Mono One, Montserrat, Rubik, Inter.
Пропись (акценты): Marck Script, Bad Script, Great Vibes, Pangolin.
Антиква/редакционные: Playfair Display, Prata, Yeseva One, Kelly Slab.
Мягкие: Comfortaa.
Моно: JetBrains Mono.
