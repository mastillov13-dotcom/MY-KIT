"""Звук 9 демо v2: python3 mix.py <id>. Свой набор на каждый подстиль, переходы тише, акценты — отдельной дорожкой acc."""
import json, sys, wave, os
import numpy as np
from scipy.signal import resample

H = os.path.dirname(os.path.abspath(__file__)); VID = sys.argv[1]
D = json.load(open(f'{H}/{VID}/events.json')); DUR = D['dur']; STY = D['style']
SR = 48000; N = int(DUR * SR)
st = {k: np.zeros((N, 2)) for k in ('voice', 'sfx', 'acc', 'bed')}; cache = {}


def rd(p):
    f = wave.open(p); a = np.frombuffer(f.readframes(f.getnframes()), np.int16).astype(float) / 32767; a = a.reshape(-1, f.getnchannels())
    if f.getnchannels() == 1: a = np.repeat(a, 2, 1)
    if f.getframerate() != SR: a = np.stack([resample(a[:, c], int(len(a) * SR / f.getframerate())) for c in range(2)], 1)
    return a


def put(a, t, g, to='sfx'):
    i = int(t * SR)
    if i < 0: a = a[-i:]; i = 0
    m = min(len(a), N - i)
    if m > 0: st[to][i:i + m] += a[:m] * g


def X(n, t, g, rate=1.0, cut=None, to='sfx', peak=False):
    k = (n, rate, cut)
    if k not in cache:
        a = rd(f'{H}/sfx/{n}.wav'); pk = 0.0
        if not any(w in n for w in ('whoosh', 'riser', 'swoosh', 'air', 'brushing')):
            i0 = int(np.argmax(np.abs(a[:, 0]) > np.abs(a[:, 0]).max() * .1)); a = a[max(0, i0 - int(.004 * SR)):]
        else:
            e = np.convolve(np.abs(a[:, 0]), np.ones(960) / 960, 'same'); pk = int(np.argmax(e)) / SR
        if rate != 1: a = np.stack([resample(a[:, c], int(len(a) / rate)) for c in range(2)], 1); pk /= rate
        if cut: a = a[:int(cut * SR)].copy(); f = int(.04 * SR); a[-f:] *= np.linspace(1, 0, f)[:, None]
        mx = np.abs(a).max(); a = a / (mx + 1e-9) * .9          # выравниваем пики сэмплов, громкость задаём сами
        cache[k] = (a, pk)
    a, pk = cache[k]; put(a, t - (pk if peak else 0), g, to)


def env(n, a=.003, r=.2): t = np.arange(n) / SR; return np.minimum(1, t / a) * np.exp(-t / r)
def mono(s): return np.repeat(s[:, None], 2, 1)
def tone(t, f, g=.03, d=.35, h=(1, .4, .15), to='sfx'):
    n = int(d * SR); tt = np.arange(n) / SR; put(mono(sum(np.sin(2 * np.pi * f * (k + 1) * tt) * a for k, a in enumerate(h)) * env(n, .002, d / 4)), t, g, to)
def sub(t, f=50, d=.6, g=.16):
    n = int(d * SR); tt = np.arange(n) / SR; fr = f * (1 + 1.6 * np.exp(-tt / .03)); s = np.sin(2 * np.pi * np.cumsum(fr) / SR) + .3 * np.sin(4 * np.pi * np.cumsum(fr) / SR)
    put(mono(s * env(n, .002, d / 3)), t, g, 'acc')
def chirp(t, f0, f1, d=.09, g=.05):
    n = int(d * SR); tt = np.arange(n) / SR; f = f0 + (f1 - f0) * tt / d; put(mono(np.sin(2 * np.pi * np.cumsum(f) / SR) * env(n, .003, d / 2)), t, g)
def popS(t, g=.05, f0=900): n = int(.09 * SR); tt = np.arange(n) / SR; f = 260 + (f0 - 260) * np.exp(-tt / .015); put(mono(np.sin(2 * np.pi * np.cumsum(f) / SR) * env(n, .001, .03)), t, g)
def air(t, d=.5, g=.03, up=True):
    n = int(d * SR); rng = np.random.default_rng(int(t * 97)); s = rng.normal(0, 1, n); from scipy.signal import butter, sosfilt
    s = sosfilt(butter(2, [800, 6000], 'band', fs=SR, output='sos'), s); e = np.sin(np.linspace(0, np.pi, n)) ** 2; put(np.stack([s * e * (.6 if up else 1), s * e * (1 if up else .6)], 1), t - d / 2, g)
def typing(t0, d, g=.08, src='typewriter_alex'):
    bed = rd(f'{H}/sfx/{src}.wav'); bed = bed / (np.abs(bed).max() + 1e-9) * .9; out = np.zeros((int(max(.1, d) * SR), 2)); i = 0; rng = np.random.default_rng(int(t0 * 100))
    while i < len(out):
        p = int(rng.uniform(0, max(.01, len(bed) / SR - .6)) * SR); tk = min(len(out) - i, len(bed) - p); out[i:i + tk] += bed[p:p + tk]; i += tk
    f = int(.02 * SR); out[:f] *= np.linspace(0, 1, f)[:, None]; out[-f:] *= np.linspace(1, 0, f)[:, None]; put(out, t0, g)
def keys(t0, d, g=.05):  # клавиатура: одна вспышка на строку + редкие тапы
    X('keyboard', t0, g, cut=min(.6, d)); [X('k_tap', t0 + .6 + k * .17, g * .5, rate=1.4) for k in range(int(max(0, d - .6) / .17))]
def pixrain(t, g=.03):
    rng = np.random.default_rng(int(t * 31))
    for k in range(26): X('k_tap', t - .3 + rng.uniform(0, .62), g * rng.uniform(.5, 1), rate=rng.uniform(1.4, 2.2))


C5, D5, E5, G5, A5, C6, E6 = 523.25, 587.33, 659.25, 783.99, 880.0, 1046.5, 1318.5
SC = [C5, D5, E5, G5, A5, C6, E6]
cnt = {}
def n_(k): cnt[k] = cnt.get(k, -1) + 1; return cnt[k]

S = {
 'd2A': dict(music=(.09, 118, 7),
   tr_paper=lambda e: (X('whoosh_2', e['t'], .022, peak=True), air(e['t'], .5, .015)),
   marker=lambda e: X('brushing', e['t'] + .02, .04, cut=e['d'] + .1),
   behind=lambda e: air(e['t'] + .1, .4, .022), scribble=lambda e: X('scribble', e['t'], .035) if n_('scrA') == 0 else X('tap', e['t'], .025, rate=1.3),
   big=lambda e: (X('swoosh', e['t'] - .05, .03), X('thock', e['t'] + .08, .05)), hand=lambda e: X('tap', e['t'], .028, rate=1.15 + .03 * (n_('hA') % 4)),
   plate=lambda e: X('pop', e['t'], .05), thock=lambda e: X('thock', e['t'], .06), hit=lambda e: (X('thock', e['t'], .06), X('impact', e['t'], .045)),
   panel=lambda e: X('whoosh_4', e['t'], .02, peak=True), type=lambda e: typing(e['t'], e['d'], .06), mode=lambda e: X('whoosh_2', e['t'] + .35, .03, peak=True),
   zcut=lambda e: (X('impact', e['t'], .05), X('mouse_click', e['t'], .04))),
 'd2B': dict(music=(.09, 112, 11),
   tr_band=lambda e: (X('camera_whoosh', e['t'], .024, peak=True), sub(e['t'], 46, .45, .07)),
   flap=lambda e: [X('click', e['t'] + k * .045, .028, rate=1.2 + .02 * (k % 5)) for k in range(int(e['d'] / .045))],
   behind=lambda e: X('click', e['t'], .04), big=lambda e: (X('fast_whoosh', e['t'] - .04, .03, peak=True), X('thock', e['t'] + .1, .05, rate=.9)),
   hand=lambda e: X('mouse_click', e['t'], .03, rate=.9), plate=lambda e: X('mouse_click', e['t'], .06), thock=lambda e: X('thock', e['t'], .06, rate=.85),
   sticker=lambda e: (X('tap', e['t'] + .12, .06, rate=.8 + .05 * e['n']), X('low_boom', e['t'] + .12, .02)),
   panel=lambda e: X('whoosh_4', e['t'], .02, peak=True), txt=lambda e: X('click', e['t'], .04), type=lambda e: typing(e['t'], e['d'], .065),
   hit=lambda e: (X('thock', e['t'], .06), X('low_boom', e['t'], .03)), mode=lambda e: X('whoosh_3', e['t'] + .35, .03, peak=True),
   zcut=lambda e: (X('hit_1', e['t'], .05), X('mouse_click', e['t'], .03))),
 'd2C': dict(music=(.08, 104, 21),
   tr_page=lambda e: (X('swoosh', e['t'] - .1, .025, rate=.8), air(e['t'], .55, .018, up=False)),
   torch=lambda e: (X('riser_1', e['t'] + e['d'], .025, cut=1.0, peak=True), X('low_boom', e['t'] + e['d'], .035)),
   behind=lambda e: air(e['t'] + .1, .35, .02), big=lambda e: X('pop', e['t'], .05, rate=.85), hand=lambda e: X('blink', e['t'], .022, cut=.3, rate=1.1),
   plate=lambda e: X('pop', e['t'], .055, rate=1.1), scribble=lambda e: X('swoosh', e['t'], .02, rate=1.4),
   card=lambda e: (X('swoosh', e['t'], .03, rate=1.1), X('tap', e['t'] + .3, .05, rate=.9 + .06 * e['n'])),
   hit=lambda e: (X('thock', e['t'], .065), X('low_boom', e['t'], .035), sub(e['t'], 48, .5, .1)), panel=lambda e: X('whoosh_5', e['t'], .02, peak=True),
   tick=lambda e: X('pop', e['t'], .03, rate=1.25), slide=lambda e: [X('tap', e['t'] + k * e['d'] / 12, .025, rate=1.6 + .03 * k) for k in range(13)],
   mode=lambda e: X('whoosh_1', e['t'] + .35, .03, peak=True), zcut=lambda e: (X('impact', e['t'], .045), X('click', e['t'], .03))),
 'apA': dict(music=None,
   lens=lambda e: (sub(e['t'], 55, .7, .11), air(e['t'] - .1, .7, .025), X('glass_cup', e['t'] + .25, .02, cut=.6)),
   panel=lambda e: X('ui_04', e['t'], .035) if n_('pan') < 2 else X('ui_06', e['t'], .03), sub=lambda e: X('ui_02', e['t'], .035), title=lambda e: X('ui_01', e['t'], .035),
   pill=lambda e: popS(e['t'], .05), tile=lambda e: (X('whoosh_1_2', e['t'], .025, peak=True), X('ui_06', e['t'] + .05, .03)),
   select=lambda e: X('ui_01', e['t'], .03, rate=1.1), tok=lambda e: X('ui_06', e['t'], .03, rate=1 + .04 * n_('tok')),
   slider=lambda e: [X('ui_08', e['t'] + e['d'] * k / 8, .015, rate=1 + .03 * k, cut=.12) for k in range(9)],
   mode=lambda e: (X('whoosh_2', e['t'] + .35, .035, peak=True), sub(e['t'] + .35, 60, .5, .1)), tr_soft=lambda e: air(e['t'], .45, .03)),
 'apB': dict(music=None,
   tr_island=lambda e: (X('whoosh_3', e['t'], .022, peak=True), sub(e['t'], 58, .55, .08)),
   panel=lambda e: X('ui_09', e['t'], .03), icon=lambda e: X('blink', e['t'], .03, cut=.3), sub=lambda e: X('ui_02', e['t'], .03, rate=1.1), title=lambda e: X('ui_09', e['t'], .035, rate=.9),
   pill=lambda e: X('blink', e['t'], .035, cut=.35), send=lambda e: (chirp(e['t'], 700, 1500, .08, .045), X('mouse_click', e['t'] - .03, .025)),
   toggle=lambda e: (X('ui_07', e['t'], .04), popS(e['t'] + .05, .02, 1200)), type=lambda e: keys(e['t'], e['d'], .04),
   dots=lambda e: [X('k_tap', e['t'] + k * .4, .015, rate=1.8) for k in range(int(e['d'] / .4))],
   seg=lambda e: X('ui_05', e['t'], .035, rate=1 + .1 * e['n']), button=lambda e: X('blink', e['t'], .03, cut=.35), saved=lambda e: X('bell_1', e['t'] + .05, .02, cut=1.2),
   mode=lambda e: X('whoosh_1', e['t'] + .35, .03, peak=True)),
 'apC': dict(music=None,
   tr_frost=lambda e: (X('whoosh_1', e['t'], .014, peak=True), air(e['t'], .6, .018, up=False)),
   panel=lambda e: X('ui_06', e['t'], .03), title=lambda e: X('ui_02', e['t'], .035), sub=lambda e: X('ui_02', e['t'], .028, rate=1.15), pill=lambda e: X('glass_cup', e['t'], .025, cut=.4),
   ring=lambda e: [X('ui_08', e['t'] + e['d'] * k / 10, .014, rate=1 + .035 * k, cut=.1) for k in range(11)],
   card=lambda e: (X('whoosh_4', e['t'], .025, peak=True), X('ui_05', e['t'] + .2, .03, rate=1 + .05 * e['n'])),
   check=lambda e: X('ui_06', e['t'], .032, rate=1 + .06 * e['n']), mode=lambda e: (X('whoosh_2', e['t'] + .35, .03, peak=True), sub(e['t'] + .35, 62, .5, .09))),
 'sgA': dict(music=(.17, 124, 3),
   tr_scan=lambda e: (X('whoosh_1_2', e['t'], .024, peak=True), X('ui_01', e['t'] - .2, .015, cut=.3)),
   count=lambda e: [X('ui_08', e['t'] + e['d'] * k / 6, .02, rate=1 + .05 * k, cut=.12) for k in range(7)], txt=lambda e: X('k_tap', e['t'], .04, rate=1.2),
   stamp=lambda e: (X('hit_2', e['t'], .09, to='acc'), X('bass_1', e['t'], .07, to='acc'), X('k_thock', e['t'], .05, to='acc'), X('k_low_boom', e['t'], .05, to='acc'), X('camera_flash', e['t'], .02)),
   big=lambda e: X('k_click', e['t'], .05), panel=lambda e: X('k_tap', e['t'], .035), line=lambda e: X('k_tap', e['t'], .03, rate=1.5), card=lambda e: X('mouse_click', e['t'], .05),
   col=lambda e: (X('k_tap', e['t'] - .02, .045, rate=1.35), tone(e['t'], SC[e['n'] % 7], .012, .2, (1, .2))), plus=lambda e: X('pop', e['t'], .045),
   result=lambda e: (X('riser_3', e['t'], .025, cut=1.2, peak=True), X('level_up', e['t'], .04), sub(e['t'], 50, .6, .14)),
   mode=lambda e: X('whoosh_1_2', e['t'] + .3, .025, peak=True), zcut=lambda e: (X('whoosh_3', e['t'] - .05, .03, peak=True), X('k_impact', e['t'], .05))),
 'sgB': dict(music=(.17, 128, 9),
   tr_slice=lambda e: (X('fast_whoosh', e['t'], .026, peak=True), X('k_click', e['t'], .03), sub(e['t'], 46, .4, .06)),
   type=lambda e: keys(e['t'], e['d'], .05), tag=lambda e: X('mouse_click', e['t'], .05), panel=lambda e: X('camera_whoosh', e['t'], .02, peak=True),
   txt=lambda e: X('k_tap', e['t'], .045), count=lambda e: (X('hit_1', e['t'] + e['d'], .06, to='acc'), X('bass_1', e['t'] + e['d'], .05, to='acc')), big=lambda e: X('k_click', e['t'], .05),
   bar=lambda e: (X('hit_1', e['t'], .045, rate=1 + .12 * e['n']), sub(e['t'], 60 + 12 * e['n'], .3, .08)),
   mode=lambda e: X('camera_whoosh', e['t'] + .3, .03, peak=True), zcut=lambda e: (X('fast_whoosh', e['t'] - .03, .03, peak=True), X('k_impact', e['t'], .055))),
 'sgC': dict(music=(.16, 120, 5),
   tr_pixel=lambda e: pixrain(e['t'], .03),
   scan=lambda e: (X('riser_2', e['t'] + e['d'], .03, cut=1.6, peak=True), chirp(e['t'] + e['d'], 1200, 1800, .06, .04)), txt=lambda e: X('k_tap', e['t'], .04, rate=1.1),
   row=lambda e: (X('k_tap', e['t'], .045, rate=1.1 + .08 * e['n']), tone(e['t'] + .05, SC[min(6, 2 + e['n'])], .018, .3)),
   panel=lambda e: X('k_tap', e['t'], .035, rate=.9), prog=lambda e: tone(e['t'] + .5, SC[min(6, 2 + e['n'])], .02, .3), tag=lambda e: chirp(e['t'], 1500, 1100, .05, .035),
   big=lambda e: X('k_click', e['t'], .045), graph=lambda e: X('ping_riser', e['t'] + e['d'], .025, cut=e['d'] + .2, peak=True),
   result=lambda e: (X('k_thock', e['t'], .06, to='acc'), sub(e['t'], 52, .6, .14)),
   dial=lambda e: ([X('k_tap', e['t'] + e['d'] * (1 - (1 - k / 14) ** .5), .025, rate=1.3 + .03 * k) for k in range(15)], X('coin_collect', e['t'] + e['d'], .04)),
   mode=lambda e: X('whoosh_5', e['t'] + .3, .03, peak=True), zcut=lambda e: (X('whoosh_3', e['t'] - .05, .03, peak=True), X('k_impact', e['t'], .05))),
}
M = S[VID]; miss = set()
for e in D['ev']:
    fn = M.get(e['k'])
    if fn is None and e['k'] == 'pill2': fn = M.get('pill')
    if fn: fn(e)
    else: miss.add(e['k'])
v = rd(os.environ.get('SRC', H + '/src') + '/voice.wav')[:N]; st['voice'][:len(v)] += v[:, :1].repeat(2, 1)
if M['music']:
    lv, bpm, seed = M['music']; mp = f'{H}/{VID}/music.wav'
    if not os.path.exists(mp): os.system(f'python3 {H}/../music2.py {DUR + .5} {bpm} {seed} {mp} > /dev/null')
    mu = rd(mp)[:N]; st['bed'][:len(mu)] += mu * lv
st['sfx'] *= 3.9 if STY == 'apple' else 3.4
e = np.abs(st['voice'][:, 0]); k = int(.08 * SR); en = np.convolve(e, np.ones(k) / k, 'same'); en /= en.max()
st['sfx'] *= (1 - .3 * np.clip(en * 4, 0, 1))[:, None]
st['bed'] *= (1 - .5 * np.clip(en * 4, 0, 1))[:, None]
fo = int(.35 * SR)
for kk in st: st[kk][-fo:] *= np.linspace(1, 0, fo)[:, None]
mix = sum(st.values()); g = min(1, .97 / np.abs(mix).max())
def p90(a):
    w = 4800; m = np.array([np.abs(a[i:i + w, 0]).max() for i in range(0, len(a) - w, w)]); m = m[m > 1e-3]; return round(20 * np.log10(np.percentile(m, 90)), 1) if len(m) else -99
print(VID, 'gain', round(g, 3), 'p90 voice/sfx/acc', p90(st['voice']), p90(st['sfx']), p90(st['acc']), 'missing', sorted(miss))
def wr(n, a):
    w = wave.open(n, 'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(a * g, -1, 1) * 32767).astype(np.int16).tobytes()); w.close()
wr(f'{H}/{VID}/mix.wav', mix)
for kk in st: wr(f'{H}/{VID}/stem_{kk}.wav', st[kk])
