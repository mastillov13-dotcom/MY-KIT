"""Собирает 9 проектов демо v2: v9/<id>/proj/index.html (всё инлайн), ассеты, видео; events.json — через headless Chromium."""
import json, os, shutil, subprocess, sys, wave
import numpy as np
H = os.path.dirname(os.path.abspath(__file__)); C = f'{H}/core'
SRC = os.environ.get('SRC', H + '/src')  # папка ролика: words.js, voice.wav, graded.mp4, person.webm
s = open(SRC + '/words.js').read(); R = json.loads(s[s.index('=') + 1:].rstrip().rstrip(';'))
DUR = 28.6
W = [[w['w'], round(w['s'], 3), round(w['e'], 3)] for w in R['w'] if w['s'] < DUR - .3]
f = wave.open(SRC + '/voice.wav'); sr = f.getframerate(); ch = f.getnchannels()
a = np.frombuffer(f.readframes(f.getnframes()), np.int16).astype(float).reshape(-1, ch)[:, 0] / 32767
hop = sr // 30; env = [float(np.sqrt(np.mean(a[i:i + hop] ** 2))) for i in range(0, int(DUR * sr), hop)]; mx = max(env); ENV = [round(min(1, x / mx * 1.4), 3) for x in env]
V = {
 'd2A': ('d2', {'--acc': '#F0B43C', '--accInk': '#1A1407', '--strict': '"Alumni"', '--strictW': '900', '--hand': '"Marck"', '--strictK': '1'}, {'anim': 'slide', 'capAcc': '#F0B43C', 'capInk': '#1A1407'}),
 'd2B': ('d2', {'--acc': '#F2ECE0', '--accInk': '#1F1F1D', '--pan': 'rgba(31,31,29,.9)', '--strict': '"Oswald"', '--strictW': '700', '--hand': '"BadScript"', '--strictK': '.9'}, {'anim': 'rise', 'capAcc': '#F2ECE0', 'capInk': '#1F1F1D'}),
 'd2C': ('d2', {'--acc': '#8CC09A', '--accInk': '#0F2016', '--acc2': '#3E6B4F', '--strict': '"Dela"', '--strictW': '400', '--hand': '"Pangolin"', '--strictK': '.72'}, {'anim': 'zoom', 'capAcc': '#3E6B4F', 'capInk': '#F6F1E7'}),
 'apA': ('apple', {'--hl': '"Inter"', '--pillBg': 'linear-gradient(180deg,#F6CF63,#E2A324)', '--pillInk': '#1A1407', '--acc': '#E2A324'}, {'anim': 'blur', 'hlAnim': 'letters'}),
 'apB': ('apple', {'--hl': '"Manrope"', '--pillBg': '#0A84FF', '--pillInk': '#FFFFFF', '--acc': '#0A84FF'}, {'anim': 'spring', 'hlAnim': 'spring'}),
 'apC': ('apple', {'--hl': '"Onest"', '--pillBg': '#E9B44C', '--pillInk': '#1A1203', '--acc': '#E9B44C'}, {'anim': 'rise', 'hlAnim': 'rise'}),
 'sgA': ('signal', {'--big': '"Unbounded"', '--txt': '"Geologica"', '--acc': '#C6F24E', '--accInk': '#15170F', '--panA': 'rgba(30,32,35,.95)', '--line': 'rgba(255,255,255,.12)'}, {}),
 'sgB': ('signal', {'--big': '"Tektur"', '--txt': '"Geologica"', '--acc': '#FF3B2F', '--accInk': '#FFFFFF', '--panA': 'rgba(14,14,16,.95)', '--line': 'rgba(255,255,255,.14)', '--bigTr': '0', '--labF': '"Geologica"', '--labW': '600', '--labTr': '.04em', '--labS': '30px', '--tagF': '"Tektur"'}, {}),
 'sgC': ('signal', {'--big': '"Montserrat"', '--txt': '"Plex"', '--acc': '#F5B841', '--accInk': '#1A1407', '--panA': 'rgba(28,28,30,.95)', '--line': 'rgba(255,255,255,.12)', '--bigTr': '-.02em'}, {}),
}
DJS = {'d2': 'd2', 'apple': 'apple', 'signal': 'signal'}
GR = {'d2': 'eq=contrast=1.05:saturation=.9:gamma=.97', 'apple': 'eq=contrast=1.04:saturation=.95:brightness=.01', 'signal': 'eq=contrast=1.08:saturation=.9:gamma=.95'}


def html(vid):
    d, vars_, extra = V[vid]
    css = open(f'{C}/fonts.css').read() + open(f'{C}/core.css').read() + open(f'{C}/{DJS[d]}.css').read()
    css += '#root{' + ';'.join(f'{k}:{v}' for k, v in vars_.items()) + '}'
    PS = {'d2': 1.06, 'apple': 1.045, 'signal': 1.05}[d]
    plan = dict(words=W, env=ENV, dur=DUR, style=d, push=[[a, b, 1, PS] for a, b in ((0, 3.45), (3.5, 11.85), (11.9, 15.8), (15.85, 25.15), (25.2, 28.6))], **extra)
    js = 'window.P=' + json.dumps(plan, ensure_ascii=False) + ';\n' + open(f'{C}/core.js').read() + '\n' + open(f'{C}/{DJS[d]}.js').read() + '\n' + open(f'{H}/var/{vid}.js').read()
    person = '<div id="behind"></div><video id="vp" src="person.webm" muted data-start="0" data-duration="28.6" data-track-index="1"></video>' if d == 'd2' else ''
    return f'''<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>{vid}</title><script src="assets/gsap.min.js"></script><style>{css}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-width="1080" data-height="1920" data-duration="{DUR}">
<div class="L" id="bgL"></div>
<div id="stage"><div id="mode"><div id="push"><div id="cam"><video id="v" src="graded.mp4" muted data-start="0" data-duration="{DUR}" data-track-index="0"></video>{person}</div></div><div id="winF"><b><i></i>REC · ЧИТАЮ</b></div></div></div>
<div class="L" id="vig"></div><div class="L" id="dimL"></div><div class="L" id="splitL"></div>
<div id="fx"></div><div id="caps"></div><div id="hud"></div><div id="trL"></div><div class="L" id="flashSoft"></div><div id="grain"></div>
</div><script>{js}</script></body></html>'''


if __name__ == '__main__':
    only = sys.argv[1:] or list(V)
    for vid in only:
        d = V[vid][0]; PJ = f'{H}/{vid}/proj'; os.makedirs(PJ, exist_ok=True)
        if not os.path.exists(f'{PJ}/assets'): shutil.copytree(f'{C}/assets', f'{PJ}/assets')
        g = f'{H}/graded_{d}.mp4'
        if not os.path.exists(g):
            subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', SRC + '/graded.mp4', '-t', str(DUR + .2), '-an', '-vf', GR[d], '-c:v', 'libx264', '-crf', '16', '-g', '30', '-pix_fmt', 'yuv420p', g], check=True)
        for src, dst in ((g, 'graded.mp4'), (SRC + '/person.webm', 'person.webm')):
            if dst == 'person.webm' and d != 'd2': continue
            if not os.path.exists(f'{PJ}/{dst}'): os.link(src, f'{PJ}/{dst}')
        open(f'{PJ}/index.html', 'w').write(html(vid))
        r = subprocess.run(['node', f'{H}/ev.js', f'{PJ}/index.html'], capture_output=True, text=True, timeout=120, cwd=H)
        o = json.loads(r.stdout.strip().splitlines()[-1]); evs = o['ev'] or []
        if o['errs']: print(vid, 'ERRORS', o['errs'][:5])
        json.dump({'style': d, 'dur': DUR, 'ev': evs}, open(f'{H}/{vid}/events.json', 'w'), ensure_ascii=False)
        print(vid, len(evs), 'events')
