/* Ядро демо v2: таймлайн, слои, камера, режимы кадра, 9 полупрозрачных переходов, субтитры трёх стилей,
   журнал звуковых событий (window.EV → events.json). Дизайны (d2.js / apple.js / signal.js) добавляют свои модули в window.X. */
(function () {
  const $ = s => document.querySelector(s);
  const tl = gsap.timeline({ paused: true });
  const W = P.words, root = $("#root"), fx = $("#fx");
  const T = i => +(W[i][1] - .04).toFixed(3), E = i => W[i][2];
  const EV = [];
  const ev = (k, t, o) => EV.push(Object.assign({ k, t: +(+t).toFixed(3) }, o || {}));
  const mk = (tag, cls, html, css) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; if (css) e.style.cssText = css; return e; };
  const NS = "http://www.w3.org/2000/svg";
  const sv = (tag, at, par) => { const e = document.createElementNS(NS, tag); for (const k in at) e.setAttribute(k, at[k]); if (par) par.appendChild(e); return e; };
  const split = el => { const t = el.textContent; el.textContent = ""; t.split(" ").forEach((wd, wi) => { if (wi) el.appendChild(document.createTextNode(" ")); const ws = mk("span", "", null, "display:inline-block;white-space:nowrap"); [...wd].forEach(c => ws.appendChild(mk("span", "ch", c))); el.appendChild(ws); }); return [...el.querySelectorAll(".ch")]; };
  const HIDE = [];   // окна, где субтитры прячем (на экране те же слова)
  const scene = (c, parent) => { const s = mk("div", "sc" + (c.cls ? " " + c.cls : "")); (parent || fx).appendChild(s);
    gsap.set(s, { autoAlpha: 0 }); tl.set(s, { autoAlpha: 1 }, c.t0 - .05); const t1 = c.t1 != null ? c.t1 : c.out + .3;
    if (c.out != null) tl.to(s, { autoAlpha: 0, filter: "blur(14px)", duration: .24, ease: "power2.in" }, c.out); tl.set(s, { autoAlpha: 0 }, t1 + .05);
    if (!c.caps) HIDE.push([c.t0 - .1, (c.out != null ? c.out : t1) + .1]); return s; };
  const shake = (t, a, n) => { a = a || 10; tl.to("#stage", { x: a, y: -a * .6, duration: .035, repeat: (n || 4) - 1, yoyo: true, ease: "none" }, t); tl.set("#stage", { x: 0, y: 0 }, t + .035 * (n || 4) + .01); };
  const typeIn = (el, text, t0, t1) => { el.textContent = ""; const n = text.length; [...text].forEach((ch, i) => { const x = mk("span", "", ch === " " ? "&nbsp;" : ch); x.style.display = "none"; el.appendChild(x); tl.set(x, { display: "inline" }, t0 + (t1 - t0) * i / n); }); };
  const count = (el, a, b, t0, t1, fmt, n) => { n = n || 16; for (let k = 0; k <= n; k++) { const u = k / n, e = 1 - Math.pow(1 - u, 2); tl.set(el, { textContent: (fmt || (v => v))(Math.round(a + (b - a) * e)) }, t0 + (t1 - t0) * u); } };

  /* ---------- камера ---------- */
  gsap.set(["#push", "#cam"], { scale: 1 });
  (P.push || []).forEach(([a, b, s0, s1]) => tl.fromTo("#push", { scale: s0 }, { scale: s1, duration: b - a, ease: "sine.inOut", immediateRender: false }, a));
  const punch = (t, s) => tl.fromTo("#cam", { scale: s || 1.1 }, { scale: 1, duration: .4, ease: "power3.out", immediateRender: false }, t);
  const zcut = (t, s, d) => { tl.set("#cam", { scale: s || 1.3 }, t); tl.to("#cam", { scale: 1, duration: .5, ease: "power3.out" }, t + (d || .6)); ev("zcut", t); };

  /* ---------- режимы кадра ---------- */
  const MODES = {
    full: { s: 1, x: 0, y: 0, r: 0 }, board: { s: .65, x: 304.5, y: -179.6, r: 0, bd: "board", win: 1 },
    card: { s: .45, x: 297, y: 112, r: 142, bd: "white" }, pip: { s: .278, x: 724, y: 84, r: 170, bd: "white" },
    cardDark: { s: .5, x: 270, y: 96, r: 120, bd: "dark" }, dim: { s: 1, x: 0, y: 0, r: 0, dim: 1 },
    split: { s: .78, x: 118.8, y: -150, r: 0, bd: "dark", split: 1 }
  };
  const bds = {}; ["board", "white", "dark"].forEach(b => { const e = mk("div", "bd bd-" + b); $("#bgL").appendChild(e); gsap.set(e, { opacity: 0 }); bds[b] = e; });
  gsap.set("#mode", { scale: 1, x: 0, y: 0, borderRadius: 0, filter: "brightness(1) blur(0px)" });
  const mode = (name, t, d) => { const S = MODES[name]; d = d || .7;
    tl.to("#mode", { scale: S.s, x: S.x, y: S.y, borderRadius: S.r, duration: d, ease: "expo.inOut" }, t);
    Object.keys(bds).forEach(b => tl.to(bds[b], { opacity: S.bd === b ? 1 : 0, duration: d * .6 }, t + (S.bd === b ? 0 : d * .3)));
    tl.to("#winF", { opacity: S.win ? 1 : 0, duration: .3 }, t + (S.win ? d * .7 : 0));
    tl.to("#dimL", { opacity: S.dim ? 1 : 0, duration: .45 }, t);
    tl.to("#mode", { filter: S.dim ? "brightness(.42) blur(9px)" : "brightness(1) blur(0px)", duration: .45 }, t);
    tl.to("#splitL", { opacity: S.split ? 1 : 0, duration: .5 }, t + (S.split ? .2 : 0));
    tl.to("#vig", { opacity: S.s === 1 ? 1 : 0, duration: .4 }, t);
    if (P.style === "signal") tl.to("#hud", { y: S.split ? -150 : 0, duration: d, ease: "expo.inOut" }, t);
    ev("mode", t, { mode: name }); };

  /* ---------- переходы: всё полупрозрачное, склейка прячется в середине ---------- */
  const trL = $("#trL");
  const TR = {
    // D2-A «калька»: матовый молочный лист проезжает снизу вверх
    paper: t => { const e = mk("div", "tr-paper"); trL.appendChild(e); gsap.set(e, { yPercent: 105 });
      tl.to(e, { yPercent: 0, duration: .32, ease: "power2.in" }, t - .32); tl.to(e, { yPercent: -105, duration: .4, ease: "power2.out" }, t + .02); punch(t, 1.06); },
    // D2-B «маркер»: полупрозрачный мазок акцентом по диагонали
    marker: t => { const s = sv("svg", { viewBox: "0 0 1080 1920", width: 1080, height: 1920, class: "tr-svg" }); trL.appendChild(s);
      const p = sv("path", { d: "M-200 1500 C 200 1300, 500 900, 700 700 S 1100 300, 1300 150", fill: "none", stroke: "var(--acc)", "stroke-width": 980, "stroke-linecap": "round", opacity: .62, pathLength: 1, "stroke-dasharray": 1, "stroke-dashoffset": 1 }, s);
      tl.to(p, { attr: { "stroke-dashoffset": 0 }, duration: .34, ease: "power2.in" }, t - .34); tl.to(p, { attr: { "stroke-dashoffset": -1 }, duration: .38, ease: "power2.out" }, t + .02); },
    // D2-C «страница»: полупрозрачный лист переворачивается справа налево
    page: t => { const e = mk("div", "tr-page"); trL.appendChild(e); gsap.set(e, { rotationY: -100, transformOrigin: "0% 50%", x: 1080, opacity: 0 });
      tl.to(e, { rotationY: 0, x: 0, opacity: 1, duration: .34, ease: "power2.in" }, t - .34); tl.to(e, { x: -1080, rotationY: 40, opacity: 0, duration: .4, ease: "power2.out" }, t + .02); },
    // D2-B «строгая полоса»: полупрозрачная графитовая панель с молочной кромкой проходит слева направо
    band: t => { const e = mk("div", "tr-band"); trL.appendChild(e); gsap.set(e, { x: -1200 });
      tl.to(e, { x: 0, duration: .3, ease: "power3.in" }, t - .3); tl.to(e, { x: 1200, duration: .36, ease: "power3.out" }, t + .02); punch(t, 1.08); },
    // Apple-B «Динамический остров»: тёмная стеклянная капсула раскрывается на весь кадр
    island: t => { const e = mk("div", "tr-island"); trL.appendChild(e); gsap.set(e, { x: 400, y: 30, width: 280, height: 84, borderRadius: 42, opacity: 0 });
      tl.to(e, { opacity: 1, duration: .1 }, t - .5); tl.to(e, { x: 0, y: 0, width: 1080, height: 1920, borderRadius: 0, duration: .42, ease: "expo.in" }, t - .42);
      tl.to(e, { x: 400, y: 30, width: 280, height: 84, borderRadius: 42, duration: .5, ease: "expo.out" }, t + .03); tl.to(e, { opacity: 0, duration: .2 }, t + .45); },
    // Apple-C «матовое стекло»: стеклянная панель проезжает справа налево
    frost: t => { const e = mk("div", "tr-frost"); trL.appendChild(e); gsap.set(e, { x: 1180 });
      tl.to(e, { x: 0, duration: .36, ease: "power3.in" }, t - .36); tl.to(e, { x: -1180, duration: .42, ease: "power3.out" }, t + .02); },
    // Apple: смахивание/уход в карточку делает сам режим; мягкий зум-блюр
    soft: t => { tl.to("#stage", { filter: "blur(14px) brightness(1.04)", duration: .2, ease: "power2.in" }, t - .2); tl.to("#stage", { filter: "blur(0px) brightness(1)", duration: .3, ease: "power2.out" }, t); punch(t, 1.05); },
    // Signal-A «луч»: акцентная линия сверху вниз с полупрозрачным шлейфом
    scan: t => { const e = mk("div", "tr-scan"); trL.appendChild(e); gsap.set(e, { y: -260, opacity: 0 }); tl.set(e, { opacity: 1 }, t - .26);
      tl.to(e, { y: 1920, duration: .5, ease: "power2.inOut" }, t - .25); tl.set(e, { opacity: 0 }, t + .26); punch(t, 1.1); },
    // Signal-B «RGB-срез»: полупрозрачные полосы с цветным сдвигом
    slice: t => { for (let k = 0; k < 7; k++) { const e = mk("div", "tr-slice", null, `top:${k * 275}px;background:${k % 2 ? "rgba(0,220,255,.22)" : "rgba(255,59,47,.30)"}`); trL.appendChild(e);
        const dir = k % 2 ? 1 : -1; gsap.set(e, { x: dir * 1100 }); tl.to(e, { x: 0, duration: .22, ease: "power3.in" }, t - .24 + k * .006); tl.to(e, { x: -dir * 1100, duration: .26, ease: "power3.out" }, t + .02 + k * .006); }
      tl.fromTo("#stage", { x: 0 }, { x: 22, duration: .04, repeat: 3, yoyo: true, ease: "none", immediateRender: false }, t - .06); tl.set("#stage", { x: 0 }, t + .12); },
    // Signal-C «пиксели»: сетка полупрозрачных квадратов накрывает и уходит
    pixel: t => { const g = mk("div", "tr-pix"); trL.appendChild(g); const cs = []; for (let k = 0; k < 12 * 22; k++) { const c = mk("i"); g.appendChild(c); cs.push(c); }
      gsap.set(cs, { opacity: 0, scale: .2 }); const r = (k) => ((k * 7919) % 263) / 263;
      cs.forEach((c, k) => { tl.to(c, { opacity: 1, scale: 1, duration: .1 }, t - .3 + r(k) * .26); tl.to(c, { opacity: 0, scale: .2, duration: .12 }, t + .03 + r(k + 5) * .28); }); }
  };
  const trans = (kind, t) => { TR[kind](t); ev("tr_" + kind, t); };

  /* ---------- субтитры ---------- */
  const caps = (cfg) => { const box = $("#caps"); box.className = "cap-" + P.style; if (cfg && cfg.y) box.style.top = cfg.y + "px";
    const weak = /^(в|и|на|с|к|о|а|но|для|что|не|за|от|по|из|у|же|ни|как|это|вы|тем|чем)$/i; const lim = P.style === "signal" ? 6 : P.style === "apple" ? 3 : 3;
    const chunks = []; let cur = [];
    W.forEach((w, i) => { cur.push(i); const end = /[.,!?»]$/.test(w[0]); if (end || (cur.length >= lim && !weak.test(w[0]))) { chunks.push(cur); cur = []; } }); if (cur.length) chunks.push(cur);
    const hid = (a, b) => HIDE.some(([x, y]) => a < y && b > x);
    chunks.forEach((c, n) => { const t0 = W[c[0]][1] - .04; const t1 = n + 1 < chunks.length ? Math.min(W[chunks[n + 1][0]][1] - .06, W[c[c.length - 1]][2] + .5) : W[c[c.length - 1]][2] + .5;
      if (hid(t0, t1)) return;
      const d = mk("div", "cp"); const pl = mk("span", "pl"); d.appendChild(pl); box.appendChild(d);
      const ws = c.map(i => { const s = mk("span", "w", W[i][0].replace(/[.,!?]$/, P.style === "d2" ? "" : "$&")); pl.appendChild(s); return [s, i]; });
      gsap.set(d, { opacity: 0 }); tl.fromTo(d, { y: 12, opacity: 0 }, { y: 0, opacity: 1, duration: .12, immediateRender: false }, t0); tl.set(d, { opacity: 0 }, t1);
      ws.forEach(([s, i]) => { const a = W[i][1] - .04;
        if (P.style === "d2") { tl.set(s, { backgroundColor: P.capAcc || "var(--acc)", color: P.capInk || "#1A1407", textShadow: "none" }, a); tl.set(s, { backgroundColor: "rgba(0,0,0,0)", color: "#EEE8DE", textShadow: "0 4px 12px rgba(0,0,0,.55)" }, W[i][2] + .02); }
        else if (P.style === "apple") { gsap.set(s, { opacity: .35 }); tl.to(s, { opacity: 1, duration: .12 }, a); }
        else { gsap.set(s, { color: "#F3F3EF" }); tl.set(s, { color: "var(--acc)" }, a); tl.set(s, { color: "#F3F3EF" }, W[i][2] + .02); } }); }); };

  /* ---------- HUD «Сигнал» ---------- */
  const hud = (title, kind) => { kind = kind || "bars"; const h = $("#hud"); h.className = "hud-" + kind;
    const svgW = kind === "ring" ? 70 : 380;
    h.innerHTML = `<div class="t"><i></i><span class="rec">REC</span> · ${title}</div><div class="tc">00:00.0</div><svg width="${svgW}" height="60" viewBox="0 0 ${svgW} 60">${kind === "ring" ? '<circle cx="35" cy="30" r="12" fill="none" stroke="var(--acc)" stroke-width="5"/><circle cx="35" cy="30" r="5" fill="var(--acc)"/>' : '<path d="" fill="none" stroke="var(--acc)" stroke-width="' + (kind === "scope" ? 4 : 5) + '" stroke-linecap="round" stroke-linejoin="round"/>'}</svg>`;
    gsap.set(h, { opacity: 0 }); tl.to(h, { opacity: 1, duration: .4 }, .1); const path = h.querySelector("path"), ring = h.querySelector("circle"), tc = h.querySelector(".tc"), Ev = P.env, dot = h.querySelector(".t i"), rec = h.querySelector(".rec");
    if (kind !== "bars") for (let f = 0; f < P.dur * 30; f += 15) tl.set(kind === "scope" ? rec : dot, { opacity: (f / 15) % 2 ? .25 : 1 }, f / 30);
    if (kind === "scope") { for (let f = 0; f < P.dur * 30; f += 1) { let d = ""; for (let k = 0; k <= 60; k++) { const e = Ev[Math.max(0, Math.min(Ev.length - 1, f - 60 + k))] || 0; const y = 30 + Math.sin(k * 1.7 + f * .9) * Math.max(1.5, e * 25); d += (k ? "L" : "M") + (6 + k * 6.1).toFixed(1) + " " + y.toFixed(1) + " "; } tl.set(path, { attr: { d } }, f / 30);
        if (f % 3 === 0) { const ds = Math.floor(f / 3); tl.set(tc, { textContent: "00:" + String(Math.floor(ds / 10)).padStart(2, "0") + "." + (ds % 10) }, f / 30); } } return; }
    if (kind === "ring") { for (let f = 0; f < P.dur * 30; f += 1) { const e = Ev[Math.min(Ev.length - 1, f)] || 0; tl.set(ring, { attr: { r: 10 + e * 18, opacity: .45 + e * .55 } }, f / 30);
        if (f % 3 === 0) { const ds = Math.floor(f / 3); tl.set(tc, { textContent: "00:" + String(Math.floor(ds / 10)).padStart(2, "0") + "." + (ds % 10) }, f / 30); } } return; }
    for (let f = 0; f < P.dur * 30; f += 1) { let d = ""; for (let k = 0; k < 40; k++) { const e = Ev[Math.max(0, Math.min(Ev.length - 1, f - k))] || 0; const a = Math.max(2, e * 26 * (1 - Math.abs(k - 20) / 24)); d += `M${(6 + k * 9.3).toFixed(1)} ${(30 - a).toFixed(1)} V${(30 + a).toFixed(1)} `; } tl.set(path, { attr: { d } }, f / 30);
      if (f % 3 === 0) { const ds = Math.floor(f / 3); tl.set(tc, { textContent: "00:" + String(Math.floor(ds / 10)).padStart(2, "0") + "." + (ds % 10) }, f / 30); } } };

  const finish = () => { tl.to("#root", { opacity: 0, duration: .3 }, P.dur - .3); tl.set({}, {}, P.dur);
    window.__timelines = window.__timelines || {}; window.__timelines["main"] = tl; window.EV = EV.sort((a, b) => a.t - b.t);
    if (location.hash === "#ev") { const pre = mk("pre", "", JSON.stringify(window.EV)); pre.id = "EVOUT"; document.body.appendChild(pre); } };
  window.X = { tl, $, mk, sv, split, T, E, W, ev, scene, shake, typeIn, count, punch, zcut, mode, trans, caps, hud, finish, fx, HIDE };
})();
