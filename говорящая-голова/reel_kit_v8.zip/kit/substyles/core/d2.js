/* D2: «серьёзный + пропись», текст за спиной (маска), заголовок-вылет на груди, доска с окном. Модули подстилей:
   A — лесенка, слэши, калька; B — стикеры на скотче, {скобки}, «было → стало», маркер; C — карточки-веер, слова-удары, рецепт, линейка, страница. */
(function () {
  const { tl, mk, sv, split, ev, scene, shake, typeIn } = X;
  const D = {};
  const APP = {
    slide: (el, t, dx) => tl.fromTo(el, { x: dx || 120, opacity: 0, filter: "blur(6px)" }, { x: 0, opacity: 1, filter: "blur(0px)", duration: .5, ease: "power2.out", immediateRender: false }, t),
    rise: (el, t) => tl.fromTo(el, { y: 100, opacity: 0, filter: "blur(6px)" }, { y: 0, opacity: 1, filter: "blur(0px)", duration: .5, ease: "power2.out", immediateRender: false }, t),
    zoom: (el, t) => tl.fromTo(el, { scale: 1.3, opacity: 0, filter: "blur(8px)" }, { scale: 1, opacity: 1, filter: "blur(0px)", duration: .45, ease: "power2.out", immediateRender: false }, t)
  };
  const app = (el, t, o) => { gsap.set(el, { opacity: 0 }); (APP[(o && o.anim) || P.anim] || APP.slide)(el, t, o && o.dx); };
  const font = r => r === "H" ? "var(--hand)" : "var(--strict)";
  const T_ = (role, text, px, css) => { const e = mk("div", "d2t " + (role === "H" ? "hand" : "strict"), text, css); e.style.fontSize = px + "px"; return e; };
  D.app = app;

  /* текст за спиной: хук с эффектом (marker | flap | torch) или просто появление */
  D.behind = c => { const s = mk("div", "bh"); X.$("#behind").appendChild(s); gsap.set(s, { autoAlpha: 0 }); tl.set(s, { autoAlpha: 1 }, c.t - .02);
    if (c.out != null) tl.to(s, { autoAlpha: 0, duration: .3 }, c.out);
    X.HIDE.push([c.t - .1, (c.out || c.t + 2) + .1]);
    c.lines.forEach((ln, k) => { const e = T_(ln.role || "S", ln.text, ln.size, ln.x != null ? `position:absolute;left:${ln.x}px;top:${ln.y}px;white-space:nowrap;color:${ln.color || "var(--milk)"}` : `position:absolute;left:0;width:1080px;text-align:center;top:${ln.y}px;color:${ln.color || "var(--milk)"}`); s.appendChild(e);
      const t = c.t + k * (c.gap || .45);
      if (!c.fx) { gsap.set(e, { opacity: 0 }); tl.to(e, { opacity: 1, duration: .25 }, t); ev("behind", t); return; }
      if (c.fx === "marker") { gsap.set(e, { clipPath: "inset(0% 100% 0% 0%)" }); tl.to(e, { clipPath: "inset(0% 0% 0% 0%)", duration: .55, ease: "power1.inOut" }, t);
        const tip = mk("div", "mtip", null, `top:${ln.y + ln.size * .45}px`); s.appendChild(tip); gsap.set(tip, { x: 60, opacity: 0 });
        tl.set(tip, { opacity: 1 }, t); tl.to(tip, { x: 1020, duration: .55, ease: "power1.inOut" }, t); tl.to(tip, { opacity: 0, duration: .1 }, t + .55); ev("marker", t, { d: .55 }); }
      if (c.fx === "flap") { const cs = split(e); const AB = "АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЭЮЯ0123456789";
        cs.forEach((ch, i) => { const fin = ch.textContent; ch.classList.add("flap"); gsap.set(ch, { opacity: 0 }); const t0 = t + i * .045; tl.set(ch, { opacity: 1 }, t0);
          for (let q = 0; q < 6; q++) tl.set(ch, { textContent: AB[(i * 7 + q * 5) % AB.length] }, t0 + q * .05); tl.set(ch, { textContent: fin }, t0 + .3);
          tl.fromTo(ch, { rotationX: -70 }, { rotationX: 0, duration: .3, ease: "back.out(2)", immediateRender: false }, t0); }); ev("flap", t, { d: cs.length * .045 + .3 }); }
      if (c.fx === "torch") { e.classList.add("torch"); gsap.set(e, { "--mx": "-20%", "--mr": "170px" }); tl.to(e, { "--mx": "120%", duration: .9, ease: "sine.inOut" }, t); tl.to(e, { "--mr": "1400px", duration: .5, ease: "power2.out" }, t + .8); ev("torch", t, { d: .9 }); } });
    if (c.under) { const u = sv("svg", { width: 1080, height: 80, style: `position:absolute;left:0;top:${c.under.y}px` }, s);
      const p = sv("path", { d: "M300 40 C 450 20, 650 60, 790 30", fill: "none", stroke: "var(--acc)", "stroke-width": 12, "stroke-linecap": "round", pathLength: 1, "stroke-dasharray": 1, "stroke-dashoffset": 1 }, u);
      tl.to(p, { attr: { "stroke-dashoffset": 0 }, duration: .35, ease: "power2.out" }, c.under.t); ev("scribble", c.under.t); } };

  /* заголовок-вылет на груди: асимметрия, акцентная плашка, рукописная стрелка */
  D.chest = c => { const s = scene(c);
    c.items.forEach(it => { const e = T_(it.role || "S", it.plate ? `<span>${it.text}</span>` : it.text, it.size, `position:absolute;left:${it.x}px;top:${it.y}px;white-space:nowrap;${it.color ? `color:${it.color};` : ""}${it.rot ? `transform:rotate(${it.rot}deg)` : ""}`);
      if (it.plate) e.classList.add("plate"); s.appendChild(e); app(e, it.t, it); ev(it.role === "H" ? "hand" : it.plate ? "plate" : "big", it.t); });
    if (c.arrow) { const a = c.arrow; const g = sv("svg", { width: 300, height: 220, style: `position:absolute;left:${a.x}px;top:${a.y}px;overflow:visible` }, s);
      const p = sv("path", { d: a.d || "M20 20 C 90 10, 160 60, 180 150", fill: "none", stroke: "var(--acc)", "stroke-width": 7, "stroke-linecap": "round", pathLength: 1, "stroke-dasharray": 1, "stroke-dashoffset": 1 }, g);
      const h = sv("path", { d: a.h || "M150 132 L182 156 L196 118", fill: "none", stroke: "var(--acc)", "stroke-width": 7, "stroke-linecap": "round", "stroke-linejoin": "round", opacity: 0 }, g);
      tl.to(p, { attr: { "stroke-dashoffset": 0 }, duration: .4, ease: "power2.out" }, a.t); tl.to(h, { attr: { opacity: 1 }, duration: .08 }, a.t + .36); ev("scribble", a.t); }
    return s; };

  /* A: лесенка 01/02/03 с рукописной подписью */
  D.ladder = c => { const s = scene(c);
    c.rows.forEach((r, k) => { const y = c.top + k * c.gap; const n = mk("div", "mono", r.num || "0" + (k + 1), `position:absolute;left:${c.x}px;top:${y + 14}px;font-size:40px;color:var(--acc)`); s.appendChild(n);
      const tx = T_(c.role || "S", r.text, c.size, `position:absolute;left:${c.x + 90}px;top:${y}px;white-space:nowrap`); s.appendChild(tx); app(n, r.t); app(tx, r.t + .05); ev("big", r.t);
      if (r.note) { const no = T_(c.noteRole || "H", r.note, c.noteSize || 50, `position:absolute;left:${c.x + 96}px;top:${y + c.size * .98}px;white-space:nowrap;color:var(--acc)`); s.appendChild(no); app(no, r.t + .4, { anim: "zoom" }); ev("hand", r.t + .4); } }); };

  /* /СЛЕШИ/ или {СКОБКИ} вокруг ключевого слова */
  D.wrap = c => { const s = scene(c); const L = c.kind === "brace" ? ["{", "}"] : ["/", "/"];
    const e = T_(c.role || "S", `<b class="wr">${L[0]}</b>${c.text}<b class="wr">${L[1]}</b>`, c.size, `position:absolute;left:0;width:1080px;text-align:center;top:${c.top}px;white-space:nowrap`); s.appendChild(e);
    const [a, b] = e.querySelectorAll(".wr"); app(e, c.t); tl.fromTo(a, { x: 60, opacity: 0 }, { x: 0, opacity: 1, duration: .35, ease: "back.out(2)", immediateRender: false }, c.t + .25); tl.fromTo(b, { x: -60, opacity: 0 }, { x: 0, opacity: 1, duration: .35, ease: "back.out(2)", immediateRender: false }, c.t + .25);
    ev("big", c.t); ev("thock", c.t + .25);
    (c.subs || []).forEach(sb => { const x = T_(sb.role || "H", sb.text, sb.size || 58, `position:absolute;left:0;width:1080px;text-align:center;top:${sb.y}px;white-space:nowrap;color:${sb.color || "var(--acc)"}`); s.appendChild(x); app(x, sb.t, { anim: "zoom" }); ev(sb.role === "S" ? "big" : "hand", sb.t); }); };

  /* B: стикеры на скотче 2×2 */
  D.stickers = c => { const s = scene(c);
    c.notes.forEach((n, k) => { const x = c.x + (k % 2) * c.dx, y = c.top + Math.floor(k / 2) * c.dy; const rot = [-4, 3, 2, -3][k % 4];
      const e = mk("div", "stk", `<i></i><div class="hand">${n.text}</div>`, `left:${x}px;top:${y}px;width:${c.w}px;height:${c.h}px`); s.appendChild(e);
      gsap.set(e, { opacity: 0, rotation: rot }); tl.fromTo(e, { opacity: 0, y: -70, scale: 1.12, rotation: rot - 8 }, { opacity: 1, y: 0, scale: 1, rotation: rot, duration: .38, ease: "back.out(1.7)", immediateRender: false }, n.t); ev("sticker", n.t, { n: k }); }); };

  /* C: карточки-веер (входят справа и ложатся стопкой со сдвигом) */
  D.fan = c => { const s = scene(c); const els = [];
    c.cards.forEach((cd, k) => { const e = mk("div", "icard", `<div class="ic-n mono">${cd.num}</div><div class="strict ic-t">${cd.title}</div><div class="hand ic-s">${cd.sub}</div>`, `left:${c.x}px;top:${c.top}px`); s.appendChild(e); els.push(e);
      gsap.set(e, { opacity: 0 }); tl.fromTo(e, { x: 700, rotation: 12, opacity: 0 }, { x: 0, rotation: (k - 1.5) * 2.2, opacity: 1, duration: .5, ease: "power3.out", immediateRender: false }, cd.t);
      for (let j = 0; j < k; j++) tl.to(els[j], { y: -(k - j) * 46, scale: 1 - (k - j) * .04, opacity: 1 - (k - j) * .22, duration: .4, ease: "power2.out" }, cd.t); ev("card", cd.t, { n: k }); }); };

  /* C: слова-удары столбиком, асимметрично */
  D.hits = c => { const s = scene(c);
    c.words.forEach(w => { const e = T_(w.role || "S", w.plate ? `<span>${w.text}</span>` : w.text, w.size, `position:absolute;left:${w.x}px;top:${w.y}px;white-space:nowrap`); if (w.plate) e.classList.add("plate"); s.appendChild(e);
      gsap.set(e, { opacity: 0 }); if (w.role === "H") { app(e, w.t, { anim: "zoom" }); ev("hand", w.t); } else { tl.fromTo(e, { scale: 1.6, opacity: 0 }, { scale: 1, opacity: 1, duration: .16, ease: "power4.in", immediateRender: false }, w.t - .12); shake(w.t + .04, 6, 3); ev("hit", w.t); } }); };

  /* доска: редактор промпта (печать строк, группы подчёркиваются маркером + рукописные метки) */
  D.editor = c => { const s = scene(c); const p = mk("div", "pnl ed", `<div class="ed-h mono">${c.title}</div>`, `left:${c.x}px;top:${c.top}px;width:${c.w}px;height:${c.h}px`); s.appendChild(p);
    tl.fromTo(p, { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: .4, ease: "power3.out", immediateRender: false }, c.t0); ev("panel", c.t0);
    if (c.before) { const b = mk("div", "ed-b", `<span class="mono">БЫЛО</span> ${c.before.text}`); p.appendChild(b); app(b, c.before.t, { anim: "rise" }); ev("txt", c.before.t);
      const ar = mk("div", "ed-ar mono", "↓ СТАЛО"); p.appendChild(ar); app(ar, c.before.t2, { anim: "rise" }); ev("txt", c.before.t2); }
    c.lines.forEach((ln, k) => { const r = mk("div", "ed-l", `<span class="ln mono">${k + 1}</span><span class="tx"></span>`, `top:${(c.before ? 200 : 86) + k * 86}px;width:${c.w - 72}px`); p.appendChild(r); const tx = r.querySelector(".tx");
      gsap.set(r, { opacity: 0 }); tl.set(r, { opacity: 1 }, ln.t); typeIn(tx, ln.text, ln.t, ln.t + ln.d); ev("type", ln.t, { d: ln.d });
      if (ln.tag) { const u = mk("div", "ed-u", null); r.appendChild(u); gsap.set(u, { scaleX: 0 }); tl.to(u, { scaleX: 1, duration: .3, ease: "power2.out" }, ln.t + ln.d + .1);
        const tg = mk("div", "hand ed-tag", ln.tag); r.appendChild(tg); app(tg, ln.t + ln.d + .25, { anim: "zoom" }); ev("hand", ln.t + ln.d + .25); } }); };

  /* доска: крупная цифра + рукопись слева от окна */
  D.digit = c => { const s = scene(c); const d = T_("S", c.num, c.size || 300, `position:absolute;left:${c.x}px;top:${c.y}px;color:var(--acc);line-height:.85`); s.appendChild(d);
    tl.fromTo(d, { scale: 1.5, opacity: 0 }, { scale: 1, opacity: 1, duration: .18, ease: "power4.in", immediateRender: false }, c.t - .14); ev("hit", c.t);
    if (c.note) { const n = T_("H", c.note, 64, `position:absolute;left:${c.x + 10}px;top:${c.y + (c.size || 300) * .86}px;white-space:nowrap;transform:rotate(-5deg)`); s.appendChild(n); app(n, c.t + .35, { anim: "zoom" }); ev("hand", c.t + .35); } };

  /* C: карточка рецепта — итог сверху, под ним состав с рукописными галочками */
  D.recipe = c => { const s = scene(c); const p = mk("div", "pnl rc", null, `left:${c.x}px;top:${c.top}px;width:${c.w}px;height:${c.h}px`); s.appendChild(p);
    tl.fromTo(p, { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: .4, ease: "power3.out", immediateRender: false }, c.t0); ev("panel", c.t0);
    const h = T_("S", c.title.text, 66, "position:absolute;left:44px;top:34px;color:var(--acc)"); p.appendChild(h); app(h, c.title.t); ev("big", c.title.t);
    c.rows.forEach((r, k) => { const row = mk("div", "rc-r", `<svg viewBox="0 0 40 40"><path d="M6 22 L16 32 L36 6" fill="none" stroke="var(--acc)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" pathLength="1" stroke-dasharray="1" stroke-dashoffset="1"/></svg><span class="hand">${r.text}</span>`, `top:${140 + k * 92}px`); p.appendChild(row);
      app(row, r.t, { anim: "rise" }); tl.to(row.querySelector("path"), { attr: { "stroke-dashoffset": 0 }, duration: .28 }, r.t + .25); ev("hand", r.t); ev("tick", r.t + .25); }); };

  /* C: линейка — рукописная стрелка едет к «точно» */
  D.ruler = c => { const s = scene(c); const p = mk("div", "pnl", null, `left:90px;top:${c.top}px;width:900px;height:300px`); s.appendChild(p); tl.fromTo(p, { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: .4, immediateRender: false }, c.t0); ev("panel", c.t0);
    const ttl = T_("S", c.title, 60, "position:absolute;left:44px;top:30px"); p.appendChild(ttl); app(ttl, c.t0 + .2);
    const r = mk("div", "rul"); p.appendChild(r); for (let k = 0; k <= 20; k++) r.appendChild(mk("i", k % 5 ? "" : "b", null, `left:${k * 39}px`));
    [["мало", 0], ["точно", 780]].forEach(([w, x]) => { const l = T_("H", w, 46, `position:absolute;left:${44 + x - (x ? 70 : 0)}px;top:236px;color:${x ? "var(--acc)" : "var(--milk)"}`); p.appendChild(l); });
    const a = mk("div", "rul-a", "▼"); p.appendChild(a); gsap.set(a, { x: 0 }); tl.to(a, { x: 760, duration: c.t1 - c.t0 - .6, ease: "power2.inOut" }, c.t0 + .4); ev("slide", c.t0 + .4, { d: c.t1 - c.t0 - .6 }); };

  window.D2 = D;
})();
