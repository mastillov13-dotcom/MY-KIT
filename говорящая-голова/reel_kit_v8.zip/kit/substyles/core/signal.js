/* «Сигнал»: тёмные панели с акцентной полосой, выезд из-под линии, HUD с волной.
   A — счётчик + штамп, словарная карточка, дерево в сплите, колонка в затемнении, формула;
   B — терминал, лог задач, спецификация, код-блок, столбцы; C — сканер, полосы прогресса, график, лист «итог сверху», шкала-циферблат. */
(function () {
  const { tl, mk, sv, split, ev, scene, shake, typeIn, count } = X;
  const S = {};
  const rev = (el, t) => tl.fromTo(el, { yPercent: 70, opacity: 0, clipPath: "inset(0% 0% 100% 0%)" }, { yPercent: 0, opacity: 1, clipPath: "inset(0% 0% 0% 0%)", duration: .55, ease: "power3.out", immediateRender: true }, t);
  const pop = (el, t) => tl.fromTo(el, { scale: .6, opacity: 0 }, { scale: 1, opacity: 1, duration: .3, ease: "back.out(2.4)", immediateRender: false }, t);
  const panel = (s, css, t, bar) => { const p = mk("div", "spnl" + (bar ? " " + bar : ""), null, css); s.appendChild(p); tl.fromTo(p, { opacity: 0, x: -40 }, { opacity: 1, x: 0, duration: .4, ease: "power3.out", immediateRender: false }, t); ev("panel", t); return p; };
  const big = (txt, px, css) => { const e = mk("div", "sbig", txt, css); e.style.fontSize = px + "px"; return e; };
  const lab = (txt, css) => mk("div", "slab", txt, css);
  S.rev = rev;

  /* A: счётчик 0 → N + подпись */
  S.counter = c => { const s = scene(c); const p = panel(s, `left:90px;top:${c.top}px;width:900px;height:300px`, c.t0);
    const G = c.gap || 64; const row = mk("div", "", null, `position:absolute;left:0;top:0;bottom:0;display:flex;align-items:center;gap:${G}px;padding-left:${G}px`); p.appendChild(row);
    const n = big(String(c.from), 200, `width:${c.nw || 130}px;text-align:center;padding-right:0;color:var(--acc)`); row.appendChild(n); count(n, c.from, c.to, c.t0 + .15, c.t0 + .15 + c.d); ev("count", c.t0 + .15, { d: c.d });
    const col = mk("div", "", null, "display:flex;flex-direction:column;gap:18px"); row.appendChild(col);
    const l = big(c.label, 76, "position:relative"); col.appendChild(l); rev(l, c.lt);
    const sb = mk("div", "stxt", c.sub.text, "position:relative;font-size:42px;max-width:560px"); col.appendChild(sb); rev(sb, c.sub.t); ev("txt", c.sub.t); };
  /* штамп: удар + тряска + лёгкая вспышка */
  S.stamp = c => { const s = scene(c); const e = mk("div", "sstamp", `<span>${c.text}</span>`, `top:${c.top}px`); e.firstChild.style.fontSize = c.size + "px"; s.appendChild(e);
    gsap.set(e.firstChild, { opacity: 0 }); tl.fromTo(e.firstChild, { scale: 2.4, opacity: 0, rotation: (c.rot || -6) - 10 }, { scale: 1, opacity: 1, rotation: c.rot || -6, duration: .16, ease: "power4.in", immediateRender: false }, c.t - .16);
    shake(c.t, 12, 5); tl.fromTo("#flashSoft", { opacity: .22 }, { opacity: 0, duration: .25, immediateRender: false }, c.t); ev("stamp", c.t); };
  /* словарная карточка «СЛОВО [сущ.] — определение» */
  S.dict = c => { const s = scene(c); const p = panel(s, `left:90px;top:${c.top}px;width:900px;height:330px`, c.t0);
    const w = big(c.word, 96, "position:absolute;left:46px;top:40px"); p.appendChild(w); rev(w, c.t0 + .1); ev("big", c.t0 + .1);
    const pos = lab(c.pos, "position:absolute;left:46px;top:160px;color:var(--acc)"); p.appendChild(pos); pop(pos, c.t0 + .4);
    const d = mk("div", "stxt", c.def.text, "position:absolute;left:46px;top:210px;width:800px;font-size:46px"); p.appendChild(d); rev(d, c.def.t); ev("txt", c.def.t); };
  /* сплит: узел → 3 карточки, линии дорисовываются */
  S.tree = c => { const s = scene(c); const root = mk("div", "spnl node", `<div class="sbig" style="font-size:54px">${c.root.text}</div>`, `left:290px;top:${c.top}px;width:500px;height:110px`); s.appendChild(root); pop(root, c.root.t); ev("panel", c.root.t);
    const g = sv("svg", { width: 1080, height: 200, style: `position:absolute;left:0;top:${c.top + 110}px` }, s);
    c.kids.forEach((k, i) => { const x = 90 + i * 310 + 140; const p = sv("path", { d: `M540 0 C 540 70, ${x} 60, ${x} 130`, fill: "none", stroke: "var(--acc)", "stroke-width": 4, pathLength: 1, "stroke-dasharray": 1, "stroke-dashoffset": 1 }, g);
      tl.to(p, { attr: { "stroke-dashoffset": 0 }, duration: .35 }, k.t - .3); ev("line", k.t - .3);
      const card = mk("div", "spnl", `<div class="slab" style="color:var(--acc)">0${i + 1}</div><div class="sbig" style="font-size:${c.kidSize || 30}px;margin-top:10px;white-space:nowrap">${k.text}</div><div class="stxt" style="font-size:32px;margin-top:8px">${k.sub}</div>`, `left:${90 + i * 310}px;top:${c.top + 250}px;width:280px;height:230px;padding:26px 24px;box-sizing:border-box`); s.appendChild(card); pop(card, k.t); ev("card", k.t, { n: i }); }); };
  /* колонка-прокрутка (утверждённый модуль): строка въезжает снизу, прошлые уходят вверх и размываются */
  S.column = c => { const s = scene(c); const col = mk("div", "", null, `position:absolute;left:0;width:1080px;top:${c.center}px`); s.appendChild(col); const els = [];
    c.lines.forEach((ln, k) => { const w = mk("div", "", null, "position:absolute;left:0;width:1080px;text-align:center"); const e = ln.type === "hl" ? big(ln.text, ln.size || 110, "display:inline-block;white-space:nowrap") : ln.type === "pill" ? mk("div", "spill", ln.text) : mk("div", "stxt", ln.text, "display:inline-block;font-size:50px;color:#C9CBCE");
      w.appendChild(e); col.appendChild(w); els.push(w); w.style.top = (ln.type === "hl" ? -60 : -36) + "px"; gsap.set(w, { opacity: 0 }); const t = ln.t - .08;
      tl.fromTo(w, { y: 260, opacity: 0, filter: "blur(16px)", scale: .92 }, { y: 0, opacity: 1, filter: "blur(0px)", scale: 1, duration: .35, ease: "power3.out", immediateRender: false }, t);
      for (let j = 0; j < k; j++) { const dd = k - j; tl.to(els[j], { y: -dd * (c.step || 140) - 20, opacity: Math.max(0, 1 - dd * .26), filter: `blur(${Math.min(14, dd * 3.2)}px)`, scale: 1 - dd * .03, duration: .35, ease: "power3.out" }, t); }
      ev("col", ln.t, { n: k }); }); };
  /* формула одним шрифтом: А + Б = ИТОГ */
  S.formula = c => { const s = scene(c); const box = mk("div", "", null, `position:absolute;left:60px;width:960px;top:${c.top}px;display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:16px 20px`); s.appendChild(box);
    c.parts.forEach((pt, k) => { if (k) { const pl = big("+", 80, "color:var(--acc)"); box.appendChild(pl); pop(pl, pt.t - .06); ev("plus", pt.t - .06); } const e = mk("div", "spnl chip", `<span class="sbig" style="font-size:56px">${pt.text}</span>`); box.appendChild(e); gsap.set(e, { opacity: 0 }); pop(e, pt.t); });
    const eq = big("=", 90, "color:var(--acc);width:100%;text-align:center;line-height:.8"); box.appendChild(eq); pop(eq, c.result.t - .1);
    const r = mk("div", "sres", c.result.text); box.appendChild(r); gsap.set(r, { opacity: 0 }); pop(r, c.result.t); shake(c.result.t + .05, 6, 4); ev("result", c.result.t); };

  /* B: терминал — команда печатается, статус-тег */
  S.term = c => { const s = scene(c); const p = panel(s, `left:90px;top:${c.top}px;width:900px;height:${c.h}px`, c.t0);
    const bar = mk("div", "sterm-h", "<i></i><i></i><i></i><span>terminal</span>"); p.appendChild(bar);
    c.lines.forEach((ln, k) => { const r = mk("div", "sterm-l", `<b>›</b> <span class="tx"></span>${ln.tag ? `<em>${ln.tag}</em>` : ""}`, `top:${80 + k * (c.lh || 90)}px;font-size:${ln.size || 48}px`); p.appendChild(r);
      gsap.set(r, { opacity: 0 }); tl.set(r, { opacity: 1 }, ln.t); typeIn(r.querySelector(".tx"), ln.text, ln.t, ln.t + ln.d); ev("type", ln.t, { d: ln.d });
      if (ln.tag) { const tg = r.querySelector("em"); gsap.set(tg, { opacity: 0 }); pop(tg, ln.t + ln.d + .1); ev("tag", ln.t + ln.d + .1); } });
    if (c.cursor) { const cu = mk("div", "scur"); p.appendChild(cu); gsap.set(cu, { opacity: 0 }); } };
  /* B: спецификация — строки «ПАРАМЕТР / значение», статус в конце */
  S.spec = c => { const s = scene(c); const p = panel(s, `left:90px;top:${c.top}px;width:900px;height:${90 + c.rows.length * 100}px`, c.t0);
    const h = lab(c.title, "position:absolute;left:46px;top:32px;color:var(--acc)"); p.appendChild(h); pop(h, c.t0 + .1);
    c.rows.forEach((r, k) => { const y = 90 + k * 100; const ln = mk("div", "sline", null, `top:${y}px`); p.appendChild(ln); gsap.set(ln, { scaleX: 0 }); tl.to(ln, { scaleX: 1, duration: .3 }, r.t - .1);
      const a = lab(r.k, `position:absolute;left:46px;top:${y + 34}px`); p.appendChild(a); pop(a, r.t);
      const b = r.tag ? mk("div", "stag", r.v, `position:absolute;right:46px;top:${y + 20}px`) : big(r.v, 50, `position:absolute;right:46px;top:${y + 24}px;text-align:right`); p.appendChild(b); r.tag ? pop(b, r.t + .15) : rev(b, r.t + .1); ev(r.tag ? "tag" : "txt", r.t + .1); }); };
  /* B: код-блок промпта (JSON-подобный), печать построчно */
  S.code = c => { const s = scene(c); const p = panel(s, `left:70px;top:${c.top}px;width:940px;height:${c.h}px`, c.t0);
    const h = lab(c.title, "position:absolute;left:46px;top:30px;color:var(--acc)"); p.appendChild(h); pop(h, c.t0 + .1);
    c.lines.forEach((ln, k) => { const r = mk("div", "scode", `<span class="k">${ln.k}</span><span class="p">${ln.k.trim() ? ": " : "  "}</span><span class="tx"></span>`, `top:${86 + k * 76}px`); p.appendChild(r);
      gsap.set(r, { opacity: 0 }); tl.set(r, { opacity: 1 }, ln.t); typeIn(r.querySelector(".tx"), ln.v, ln.t + .1, ln.t + .1 + ln.d); ev("type", ln.t + .1, { d: ln.d }); }); };
  /* B / A: столбцы-график */
  S.bars = c => { const s = scene(c); const p = panel(s, `left:110px;top:${c.top}px;width:860px;height:${c.h}px`, c.t0);
    const h = big(c.title.text, 54, "position:absolute;left:46px;top:36px"); p.appendChild(h); rev(h, c.title.t); ev("big", c.title.t);
    const bw = 200, H = c.h - 175; c.bars.forEach((b, k) => { const x = 70 + k * (bw + 60);
      const e = mk("div", "sbar" + (b.hi ? " hi" : ""), null, `left:${x}px;width:${bw}px;height:${b.v * H}px;bottom:70px`); p.appendChild(e); gsap.set(e, { scaleY: 0 }); tl.to(e, { scaleY: 1, duration: .45, ease: "back.out(1.6)" }, b.t);
      const l = lab(b.label, `position:absolute;left:${x}px;width:${bw}px;bottom:24px;text-align:center;color:${b.hi ? "var(--acc)" : "#C9CBCE"}`); p.appendChild(l); pop(l, b.t + .1); ev("bar", b.t, { n: k }); }); };

  /* C: сканер — луч проходит по панели, проценты растут, текст проявляется под лучом */
  S.scan = c => { const s = scene(c); const p = panel(s, `left:90px;top:${c.top}px;width:900px;height:${c.h}px`, c.t0);
    const h = lab(c.label, "position:absolute;left:46px;top:32px;color:var(--acc)"); p.appendChild(h); pop(h, c.t0 + .1);
    const pc = mk("div", "slab", "0%", "position:absolute;right:46px;top:32px;color:var(--acc)"); p.appendChild(pc); count(pc, 0, 100, c.t0 + .2, c.t0 + .2 + c.d, v => v + "%");
    c.lines.forEach((ln, k) => { const e = big(ln.text, ln.size, `position:absolute;left:46px;top:${ln.y}px;white-space:nowrap;${ln.acc ? "color:var(--acc)" : ""}`); p.appendChild(e);
      gsap.set(e, { clipPath: "inset(0% 0% 100% 0%)" }); tl.to(e, { clipPath: "inset(0% 0% 0% 0%)", duration: .4, ease: "none" }, ln.t); ev("txt", ln.t); });
    const beam = mk("div", "sbeam"); p.appendChild(beam); gsap.set(beam, { y: 0, opacity: 0 }); tl.set(beam, { opacity: 1 }, c.t0 + .2); tl.to(beam, { y: c.h - 10, duration: c.d, ease: "none" }, c.t0 + .2); tl.to(beam, { opacity: 0, duration: .15 }, c.t0 + .2 + c.d); ev("scan", c.t0 + .2, { d: c.d }); };
  /* C: полосы прогресса «подходит» */
  S.progress = c => { const s = scene(c); const p = panel(s, `left:90px;top:${c.top}px;width:900px;height:${100 + c.rows.length * 108}px`, c.t0);
    const h = lab(c.title, "position:absolute;left:46px;top:32px;color:var(--acc)"); p.appendChild(h); pop(h, c.t0 + .1);
    c.rows.forEach((r, k) => { const y = 92 + k * 108; const t = mk("div", "stxt", r.text, `position:absolute;left:46px;top:${y}px;font-size:38px;color:#F3F3EF;white-space:nowrap`); p.appendChild(t); rev(t, r.t);
      const tr = mk("div", "strack", "<b></b>", `top:${y + 62}px`); p.appendChild(tr); const b = tr.querySelector("b"); gsap.set(b, { scaleX: 0 }); tl.to(b, { scaleX: 1, duration: .6, ease: "power2.out" }, r.t + .1);
      ev("prog", r.t + .1, { n: k }); if (!c.noTag) { const ok = mk("div", "stag", "ПОДХОДИТ", `position:absolute;right:46px;top:${y}px`); p.appendChild(ok); gsap.set(ok, { opacity: 0 }); pop(ok, r.t + .6); ev("tag", r.t + .6); } }); };
  /* C: линейный график с точками */
  S.graph = c => { const s = scene(c); const PW = c.w || 900; const p = panel(s, `left:${c.x || 90}px;top:${c.top}px;width:${PW}px;height:${c.h}px`, c.t0);
    const h = big(c.title.text, c.titleSize || 50, "position:absolute;left:46px;top:34px"); p.appendChild(h); rev(h, c.title.t); ev("big", c.title.t);
    const W = PW - 100, H = c.h - 190; const g = sv("svg", { width: W, height: H + 20, style: "position:absolute;left:50px;top:120px;overflow:visible" }, p);
    for (let k = 0; k <= 4; k++) sv("line", { x1: 0, x2: W, y1: H * k / 4, y2: H * k / 4, stroke: "rgba(255,255,255,.08)", "stroke-width": 2 }, g);
    const pts = c.pts.map((v, k) => [k * W / (c.pts.length - 1), H - v * H]); const d = "M" + pts.map(p => p.join(" ")).join(" L");
    const path = sv("path", { d, fill: "none", stroke: "var(--acc)", "stroke-width": 7, "stroke-linejoin": "round", "stroke-linecap": "round", pathLength: 1, "stroke-dasharray": 1, "stroke-dashoffset": 1 }, g);
    if (c.area) { const gid = "ga" + Math.round(c.t * 100); const df = sv("defs", {}, g); const lg = sv("linearGradient", { id: gid, x1: 0, y1: 0, x2: 0, y2: 1 }, df); sv("stop", { offset: 0, "stop-color": "var(--acc)", "stop-opacity": .45 }, lg); sv("stop", { offset: 1, "stop-color": "var(--acc)", "stop-opacity": 0 }, lg);
      const ar = sv("path", { d: d + ` L${W} ${H} L0 ${H} Z`, fill: `url(#${gid})`, opacity: 0 }, g); g.insertBefore(ar, g.firstChild.nextSibling); tl.to(ar, { attr: { opacity: 1 }, duration: c.d, ease: "power1.in" }, c.t);
      const run = sv("circle", { cx: 0, cy: pts[0][1], r: 16, fill: "none", stroke: "var(--acc)", "stroke-width": 4 }, g); const N = 24; for (let k = 0; k <= N; k++) { const u = k / N * (pts.length - 1), i = Math.min(pts.length - 2, Math.floor(u)), f = u - i; tl.set(run, { attr: { cx: pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f, cy: pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f } }, c.t + c.d * k / N); } }
    tl.to(path, { attr: { "stroke-dashoffset": 0 }, duration: c.d, ease: "power1.inOut" }, c.t); ev("graph", c.t, { d: c.d });
    pts.forEach((pt, k) => { const dot = sv("circle", { cx: pt[0], cy: pt[1], r: 0, fill: "var(--acc)" }, g); tl.to(dot, { attr: { r: 11 }, duration: .2, ease: "back.out(3)" }, c.t + c.d * k / (pts.length - 1)); });
    if (c.end) { const e = mk("div", "stag", c.end.text, `position:absolute;right:46px;top:${118 + pts[pts.length - 1][1] - 70}px`); p.appendChild(e); gsap.set(e, { opacity: 0 }); pop(e, c.end.t); ev("tag", c.end.t); } };
  /* C: лист «итог сверху» — заголовок-результат, под ним состав */
  S.sheet = c => { const s = scene(c); const p = panel(s, `left:70px;top:${c.top}px;width:940px;height:${c.h}px`, c.t0);
    const r = mk("div", "sres", c.result.text, "position:absolute;left:46px;top:40px"); p.appendChild(r); gsap.set(r, { opacity: 0 }); pop(r, c.result.t); ev("result", c.result.t);
    c.rows.forEach((rw, k) => { const y = 170 + k * 104; const ln = mk("div", "sline", null, `top:${y}px`); p.appendChild(ln); gsap.set(ln, { scaleX: 0 }); tl.to(ln, { scaleX: 1, duration: .3 }, rw.t - .1);
      const a = lab(rw.k, `position:absolute;left:46px;top:${y + 36}px;color:var(--acc)`); p.appendChild(a); pop(a, rw.t);
      const b = mk("div", "stxt", rw.v, `position:absolute;left:250px;top:${y + 22}px;width:650px;font-size:${rw.size || 42}px;color:#F3F3EF;white-space:nowrap`); p.appendChild(b); rev(b, rw.t + .1); ev("txt", rw.t + .1); }); };
  /* C: циферблат — стрелка уходит к «ТОЧНО» */
  S.dial = c => { const s = scene(c); const p = panel(s, `left:90px;top:${c.top}px;width:900px;height:430px`, c.t0);
    const h = big(c.title.text, 50, "position:absolute;left:46px;top:34px"); p.appendChild(h); rev(h, c.title.t); ev("big", c.title.t);
    const g = sv("svg", { width: 520, height: 290, style: "position:absolute;left:190px;top:120px;overflow:visible" }, p);
    sv("path", { d: "M30 260 A230 230 0 0 1 490 260", fill: "none", stroke: "rgba(255,255,255,.12)", "stroke-width": 34, "stroke-linecap": "round" }, g);
    const arc = sv("path", { d: "M30 260 A230 230 0 0 1 490 260", fill: "none", stroke: "var(--acc)", "stroke-width": 34, "stroke-linecap": "round", pathLength: 100, "stroke-dasharray": 100, "stroke-dashoffset": 100 }, g);
    const nd = sv("line", { x1: 260, y1: 260, x2: 70, y2: 260, stroke: "#F3F3EF", "stroke-width": 9, "stroke-linecap": "round" }, g); sv("circle", { cx: 260, cy: 260, r: 18, fill: "#F3F3EF" }, g);
    const ang = a => { const r = (180 - a) * Math.PI / 180; return { x2: 260 + 190 * Math.cos(r), y2: 260 - 190 * Math.sin(r) }; };
    gsap.set(nd, { attr: ang(0) }); const st = { a: 0 }; const N = 18; for (let k = 0; k <= N; k++) { const u = k / N, e = 1 - Math.pow(1 - u, 3); tl.set(nd, { attr: ang(c.to * 1.8 * e) }, c.t + c.d * u); }
    tl.to(arc, { attr: { "stroke-dashoffset": 100 - c.to }, duration: c.d, ease: "power3.out" }, c.t); ev("dial", c.t, { d: c.d });
    [["МАЛО", 26], ["ТОЧНО", 440]].forEach(([w, x]) => p.appendChild(lab(w, `position:absolute;left:${190 + x - (x > 100 ? 40 : 0)}px;top:392px;color:${x > 100 ? "var(--acc)" : "#9EA1A6"}`)));
    const v = big(c.from + "%", 64, "position:absolute;left:0;width:900px;text-align:center;top:300px;color:var(--acc)"); p.appendChild(v); count(v, c.from, c.to, c.t, c.t + c.d, x => x + "%"); };

  /* панель-пояснение: крупная строка + текст */
  S.note = c => { const s = scene(c); const p = panel(s, `left:90px;top:${c.top}px;width:900px;height:${c.h}px`, c.t0, c.bar);
    (c.lines || []).forEach(ln => { const e = ln.big ? big(ln.text, ln.size || 64, `position:absolute;left:46px;top:${ln.y}px;white-space:nowrap;${ln.acc ? "color:var(--acc)" : ""}`) : mk("div", "stxt", ln.text, `position:absolute;left:46px;top:${ln.y}px;width:810px;font-size:${ln.size || 44}px`); p.appendChild(e); rev(e, ln.t); ev(ln.big ? "big" : "txt", ln.t); }); };
  /* B: хук-ярлык — крупные слова, под вторым словом проезжает акцентный блок, тег снизу */
  S.label = c => { const s = scene(c); c.words.forEach((w, k) => { const box = mk("div", "", null, `position:absolute;left:${w.x}px;top:${w.y}px`); s.appendChild(box);
      if (w.block) { const b = mk("div", "", null, `position:absolute;left:-18px;top:-6px;right:-22px;bottom:-10px;background:var(--acc);transform-origin:0 50%`); box.appendChild(b); gsap.set(b, { scaleX: 0 }); tl.to(b, { scaleX: 1, duration: .35, ease: "power3.inOut" }, w.t); }
      const e = big(w.text, w.size, `position:relative;white-space:nowrap;${w.block ? "color:var(--accInk)" : ""}`); box.appendChild(e); rev(e, w.t + (w.block ? .18 : 0)); ev("big", w.t); });
    if (c.tag) { const tg = mk("div", "stag big", c.tag.text, `position:absolute;left:${c.tag.x}px;top:${c.tag.y}px`); s.appendChild(tg); gsap.set(tg, { opacity: 0 }); pop(tg, c.tag.t); ev("tag", c.tag.t); } };
  /* B: сборка промпта — шапка акцентом, строки «тег — значение», полоса готовности */
  S.build = c => { const s = scene(c); const p = panel(s, `left:70px;top:${c.top}px;width:940px;height:${c.h}px`, c.t0, "nobar");
    const hd = mk("div", "shead", `<span>${c.title}</span><b>0%</b>`); p.appendChild(hd); const pc = hd.querySelector("b");
    c.rows.forEach((r, k) => { const y = 110 + k * 104; const tg = mk("div", "stag", r.k, `position:absolute;left:40px;top:${y + 22}px`); p.appendChild(tg); gsap.set(tg, { opacity: 0 }); pop(tg, r.t);
      const v = big(r.v, r.size || 46, `position:absolute;left:${r.vx || 300}px;top:${y + 18}px;white-space:nowrap`); p.appendChild(v); rev(v, r.t + .1); ev("tag", r.t); ev("txt", r.t + .1);
      X.count(pc, Math.round(k / c.rows.length * 100), Math.round((k + 1) / c.rows.length * 100), r.t, r.t + .5, x => x + "%", 6); });
    const bar = mk("div", "strack", "<b></b>", `left:40px;right:40px;bottom:30px;top:auto`); p.appendChild(bar); const bb = bar.querySelector("b"); gsap.set(bb, { scaleX: 0 });
    c.rows.forEach((r, k) => tl.to(bb, { scaleX: (k + 1) / c.rows.length, duration: .5, ease: "power2.out" }, r.t)); };
  /* C: очередь задач — строки по одной: янтарный номер + текст плотным шрифтом, без полос */
  S.queue = c => { const s = scene(c); const p = panel(s, `left:90px;top:${c.top}px;width:900px;height:${150 + c.rows.length * 100}px`, c.t0);
    const h = big(c.title, 54, "position:absolute;left:46px;top:40px"); p.appendChild(h); rev(h, c.t0 + .1); ev("big", c.t0 + .1);
    c.rows.forEach((r, k) => { const y = 130 + k * 100; const ln = mk("div", "sline", null, `top:${y - 12}px`); p.appendChild(ln); gsap.set(ln, { scaleX: 0 }); tl.to(ln, { scaleX: 1, duration: .3 }, r.t - .1);
      const tg = mk("div", "stag", "0" + (k + 1), `position:absolute;left:46px;top:${y + 6}px;font-size:30px`); p.appendChild(tg); gsap.set(tg, { opacity: 0 }); pop(tg, r.t);
      const tx = mk("div", "", r.text, `position:absolute;left:160px;top:${y + 4}px;font-family:var(--big);font-weight:800;font-size:44px;color:#F3F3EF;white-space:nowrap`); p.appendChild(tx); rev(tx, r.t + .08); ev("row", r.t, { n: k }); }); };
  window.SG = S;
})();
