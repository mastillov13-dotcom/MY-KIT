/* Apple: тёмное матовое стекло на кадре, карточка на белом/тёмном, пружинки, проявление из серого.
   A — плитка-морф, заголовок с выделением iOS, карточка запроса, ползунки (линза — постобработкой);
   B — чат‑стекло, переключатели, экран сообщений, сегменты + «Сохранено ✓» (остров);
   C — виджет, стопка карточек, кольцо, список с золотыми галочками, большое кольцо (матовая шторка). */
(function () {
  const { tl, mk, sv, split, ev, scene, typeIn, count } = X;
  const A = {};
  const words = (el, t, step) => { const t0 = el.innerHTML; const parts = el.textContent.split(" "); el.innerHTML = parts.map(w => `<span class="aw">${w}</span>`).join(" ");
    [...el.querySelectorAll(".aw")].forEach((w, k) => tl.fromTo(w, { y: 12, opacity: 0, filter: "blur(11px)", color: "#8E8E93" }, { y: 0, opacity: 1, filter: "blur(0px)", color: "inherit", duration: .45, ease: "power3.out", immediateRender: false }, t + k * (step || .09))); };
  const letters = (el, t) => { const cs = split(el); cs.forEach((c, k) => tl.fromTo(c, { scale: .3, opacity: 0, filter: "blur(4px)" }, { scale: 1, opacity: 1, filter: "blur(0px)", duration: .3, ease: "back.out(2.5)", immediateRender: false }, t + k * .037)); };
  const spring = (el, t, s0) => tl.fromTo(el, { scale: s0 || .5, opacity: 0 }, { scale: 1, opacity: 1, duration: .55, ease: "back.out(2)", immediateRender: false }, t);
  const rise = (el, t) => tl.fromTo(el, { y: 40, opacity: 0, filter: "blur(10px)", scale: .97 }, { y: 0, opacity: 1, filter: "blur(0px)", scale: 1, duration: .5, ease: "power3.out", immediateRender: false }, t);
  const IN = { blur: (el, t) => words(el, t), letters, spring: (el, t) => spring(el, t), rise };
  const app = (el, t, kind) => { gsap.set(el, { opacity: 0 }); tl.set(el, { opacity: 1 }, t); (IN[kind || P.anim] || IN.blur)(el, t); };
  const head = (el, t) => { gsap.set(el, { opacity: 0 }); tl.set(el, { opacity: 1 }, t); (P.hlAnim === "letters" ? letters : P.hlAnim === "spring" ? (e, tt) => spring(e, tt, .7) : P.hlAnim === "rise" ? rise : words)(el, t); };
  const glass = (cls, css) => mk("div", "glass " + (cls || ""), null, css);
  const OK = '<svg viewBox="0 0 24 24"><path d="M6.5 12.5 L10.5 16.5 L17.8 8.6" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  A.app = app;

  /* хук: стеклянный виджет с крупным заголовком и пилюлей */
  A.hook = c => { const s = scene(c); const g = glass("", `left:${c.x || 90}px;top:${c.top}px;width:${c.w || 900}px;height:${c.h}px`); s.appendChild(g); spring(g, c.t0, .8); ev("panel", c.t0);
    if (c.icon) { const ic = mk("div", "a-ico", c.icon); g.appendChild(ic); spring(ic, c.t0 + .15); ev("icon", c.t0 + .15); }
    const sb = mk("div", "a-sub", c.sub.text, `left:${c.icon ? 190 : 56}px;top:46px`); g.appendChild(sb); app(sb, c.sub.t); ev("sub", c.sub.t);
    const h = mk("div", "a-hl", c.title.text, `left:${c.icon ? 190 : 56}px;top:100px;font-size:${c.title.size || 118}px`); g.appendChild(h); head(h, c.title.t); ev("title", c.title.t);
    if (c.pill) { const p = mk("div", "a-pill", c.pill.text, `left:${c.icon ? 190 : 56}px;top:${100 + (c.title.size || 118) * 1.12}px`); g.appendChild(p); gsap.set(p, { opacity: 0 }); spring(p, c.pill.t); ev("pill", c.pill.t); } };

  /* A: плитка с морфингом содержимого + точки-пейджер */
  A.tile = c => { const s = scene(c); const g = glass("tile", `left:90px;top:${c.top}px;width:900px;height:380px`); s.appendChild(g); spring(g, c.t0, .7); ev("panel", c.t0);
    const ico = mk("div", "a-ico big"); g.appendChild(ico); const dots = mk("div", "a-dots", c.frames.map(() => "<i></i>").join("")); g.appendChild(dots);
    c.frames.forEach((f, k) => { const b = mk("div", "a-fr", `<div class="a-cap">${f.cap}</div><div class="a-hl" style="font-size:80px">${f.title}</div><div class="a-sub" style="position:static;margin-top:12px">${f.sub}</div>`); g.appendChild(b);
      gsap.set(b, { opacity: 0 }); tl.fromTo(b, { opacity: 0, filter: "blur(14px)", scale: 1.08 }, { opacity: 1, filter: "blur(0px)", scale: 1, duration: .38, ease: "power2.out", immediateRender: false }, f.t);
      if (k + 1 < c.frames.length) tl.to(b, { opacity: 0, filter: "blur(14px)", duration: .2 }, c.frames[k + 1].t - .16);
      tl.to(ico, { rotation: 90 * (k + 1), duration: .45, ease: "back.out(2)" }, f.t); tl.set(dots.children[k], { opacity: 1 }, f.t); if (k) tl.set(dots.children[k - 1], { opacity: .3 }, f.t); ev("tile", f.t, { n: k }); }); };

  /* A: заголовок на белом с выделением iOS (подсветка с ручками растёт слева направо) */
  A.select = c => { const s = scene(c); const box = mk("div", "a-white", null, `top:${c.top}px`); s.appendChild(box);
    c.lines.forEach((ln, k) => { const e = mk("div", "a-hl ink", ln.text, `font-size:${ln.size}px;margin-top:${k ? 6 : 0}px`); box.appendChild(e); head(e, ln.t); ev("title", ln.t);
      if (ln.sel) { e.classList.add("selw"); const hi = mk("i", "a-selhi"); e.appendChild(hi); gsap.set(hi, { scaleX: 0 }); tl.to(hi, { scaleX: 1, duration: .5, ease: "power2.inOut" }, ln.sel); ev("select", ln.sel); } });
    (c.subs || []).forEach(sb => { const e = mk("div", "a-sub ink2", sb.text, `position:static;margin-top:18px;font-size:${sb.size || 50}px`); box.appendChild(e); app(e, sb.t); ev("sub", sb.t); }); };

  /* A: белая карточка запроса — секции, токены, синие пилюли, список */
  A.prompt = c => { const s = scene(c); const card = c.dark ? glass("dk", `left:70px;top:${c.top}px;width:940px;height:${c.h}px`) : mk("div", "a-card", null, `left:70px;top:${c.top}px;width:940px;height:${c.h}px`); s.appendChild(card); spring(card, c.t0, .85); ev("panel", c.t0);
    const hd = mk("div", "a-cap", `<i class="a-dot"></i>${c.label}`, "position:absolute;left:48px;top:40px"); card.appendChild(hd);
    let y = 100; c.sections.forEach(sec => { const h = mk("div", c.dark ? "a-hl" : "a-hl ink", sec.head.text, `position:absolute;left:48px;top:${y}px;font-size:${c.headSize || 64}px`); card.appendChild(h); app(h, sec.head.t); ev("title", sec.head.t); y += 90;
      const row = mk("div", "a-row", null, `top:${y}px`); card.appendChild(row);
      sec.items.forEach(it => { const p = mk("span", sec.kind === "pill" ? "a-pb" : sec.kind === "list" ? "a-li" : "a-tok", (sec.kind === "tok" ? `<i style="background:${it.c || "var(--acc)"}"></i>` : sec.kind === "list" ? "• " : "") + it.text); row.appendChild(p); gsap.set(p, { opacity: 0 }); spring(p, it.t, .6); ev(sec.kind === "pill" ? "pill" : "tok", it.t); });
      y += (sec.kind === "tok" ? Math.max(row.offsetHeight, 150) : sec.h || (sec.kind === "list" ? 130 : 100)) + (sec.kind === "tok" ? 44 : 0); }); };

  /* A: ползунки «Детали» → «Точность ответа» в стекле */
  A.sliders = c => { const s = scene(c); const g = glass("", `left:90px;top:${c.top}px;width:900px;height:${110 + c.rows.length * 150}px`); s.appendChild(g); spring(g, c.t0, .8); ev("panel", c.t0);
    c.rows.forEach((r, k) => { const y = 54 + k * 150; const l = mk("div", "a-sub", r.label, `left:56px;top:${y}px;color:#fff;font-size:46px`); g.appendChild(l); app(l, r.lt != null ? r.lt : r.t);
      const tr = mk("div", "a-track", "<b></b><i></i>", `top:${y + 76}px`); g.appendChild(tr); const fill = tr.querySelector("b"), kn = tr.querySelector("i");
      gsap.set(fill, { scaleX: r.from }); gsap.set(kn, { x: r.from * 788 }); tl.to(fill, { scaleX: r.to, duration: r.d, ease: "power2.inOut" }, r.t + .2); tl.to(kn, { x: r.to * 788, duration: r.d, ease: "power2.inOut" }, r.t + .2); ev("slider", r.t + .2, { d: r.d }); }); };

  /* B: чат в стекле — одно окно, вопросы приходят снизу, старые уезжают вверх */
  A.chat = c => { const s = scene(c); const g = glass("chat", `left:90px;top:${c.top}px;width:900px;height:${c.h}px`); s.appendChild(g); spring(g, c.t0, .85); ev("panel", c.t0);
    const hd = mk("div", "a-chat-h", `<i></i>${c.title}`); g.appendChild(hd); const lane = mk("div", "a-lane"); g.appendChild(lane); const els = [];
    c.msgs.forEach((m, k) => { const b = mk("div", "a-bub me abs", m.text); lane.appendChild(b); els.push(b); gsap.set(b, { opacity: 0 });
      tl.fromTo(b, { opacity: 0, y: 70, scale: .85, transformOrigin: "100% 100%" }, { opacity: 1, y: 0, scale: 1, duration: .45, ease: "back.out(1.8)", immediateRender: false }, m.t);
      for (let j = 0; j < k; j++) tl.to(els[j], { y: -(k - j) * (c.step || 128), opacity: 1 - (k - j) * .26, duration: .4, ease: "power3.out" }, m.t); ev("send", m.t); }); };

  /* B: заголовок + переключатели iOS на белом */
  A.toggles = c => { const s = scene(c); const box = mk("div", "a-white left", null, `top:${c.top}px`); s.appendChild(box);
    c.lines.forEach(ln => { const e = mk("div", "a-hl ink", ln.text, `font-size:${ln.size}px`); box.appendChild(e); head(e, ln.t); ev("title", ln.t); });
    const card = mk("div", "a-card", null, `left:80px;top:${c.rowsTop}px;width:920px;height:${c.rows.length * 140 + 30}px`); s.appendChild(card); spring(card, c.rows[0].t - .25, .9); ev("panel", c.rows[0].t - .25);
    c.rows.forEach((r, k) => { const row = mk("div", "a-tg", `<span>${r.text}</span><b><i></i></b>`, `top:${30 + k * 140}px`); card.appendChild(row); app(row.querySelector("span"), r.t, "rise");
      const sw = row.querySelector("b"), kn = row.querySelector("i"); tl.to(sw, { backgroundColor: "#34C759", duration: .25 }, r.t + .35); tl.to(kn, { x: 52, duration: .3, ease: "back.out(2)" }, r.t + .35); ev("toggle", r.t + .35); }); };
  /* заголовок с выделением iOS на стекле (без белого фона) */
  A.selectGlass = c => { const s = scene(c); const g = glass("", `left:70px;top:${c.top}px;width:940px;height:${c.h}px`); s.appendChild(g); spring(g, c.t0, .85); ev("panel", c.t0);
    const box = mk("div", "", null, "position:absolute;left:52px;top:44px;width:840px"); g.appendChild(box);
    c.lines.forEach(ln => { const e = mk("div", "a-hl rel", ln.text, `font-size:${ln.size}px;margin-bottom:8px`); box.appendChild(e); head(e, ln.t); ev("title", ln.t);
      if (ln.sel) { e.classList.add("selw"); const hi = mk("i", "a-selhi"); e.appendChild(hi); gsap.set(hi, { scaleX: 0 }); tl.to(hi, { scaleX: 1, duration: .5, ease: "power2.inOut" }, ln.sel); ev("select", ln.sel); } });
    (c.subs || []).forEach(sb => { const e = mk("div", "a-sub rel", sb.text, `font-size:${sb.size || 46}px;margin-top:10px`); box.appendChild(e); app(e, sb.t); ev("sub", sb.t); }); };
  /* переключатели на стекле: заголовок + строки в одной плашке */
  A.toggleGlass = c => { const s = scene(c); const g = glass("", `left:70px;top:${c.top}px;width:940px;height:${c.h}px`); s.appendChild(g); spring(g, c.t0, .85); ev("panel", c.t0);
    c.lines.forEach((ln, k) => { const e = mk("div", "a-hl", ln.text, `left:52px;top:${44 + k * ln.size * 1.05}px;font-size:${ln.size}px`); g.appendChild(e); head(e, ln.t); ev("title", ln.t); });
    c.rows.forEach((r, k) => { const row = mk("div", "a-tg dk", `<span>${r.text}</span><b><i></i></b>`, `top:${c.rowsTop + k * 120}px`); g.appendChild(row); app(row.querySelector("span"), r.t, "rise");
      const sw = row.querySelector("b"), kn = row.querySelector("i"); tl.to(sw, { backgroundColor: "#34C759", duration: .25 }, r.t + .35); tl.to(kn, { x: 52, duration: .3, ease: "back.out(2)" }, r.t + .35); ev("toggle", r.t + .35); }); };
  /* набор промпта прямо на кадре: стеклянное поле ввода, текст едет за новыми словами, отправленные пузыри поднимаются вверх */
  A.compose = c => { const s = scene(c); const inp = glass("a-cin", `left:70px;top:${c.inputY}px;width:940px;height:120px;border-radius:60px`); s.appendChild(inp); spring(inp, c.t0, .9); ev("panel", c.t0);
    inp.innerHTML = '<div class="a-cin-in"><span class="ph">Сообщение</span></div><b>↑</b>'; const line = inp.querySelector(".a-cin-in"), ph = inp.querySelector(".ph"); const els = [];
    c.msgs.forEach((m, k) => { const sp = mk("span", "tl"); line.appendChild(sp); gsap.set(sp, { display: "none" }); tl.set(sp, { display: "inline" }, m.t0); tl.set(sp, { display: "none" }, m.t1 + .08);
      tl.set(ph, { display: "none" }, m.t0); tl.set(ph, { display: "inline" }, m.t1 + .08); typeIn(sp, m.text, m.t0, m.t1); ev("type", m.t0, { d: m.t1 - m.t0 });
      const b = mk("div", "a-bub me fl", m.text, `top:${c.inputY - 30}px`); s.appendChild(b); els.push(b); gsap.set(b, { opacity: 0, yPercent: -100 });
      tl.fromTo(b, { opacity: 0, y: 80, scale: .9 }, { opacity: 1, y: 0, scale: 1, duration: .4, ease: "back.out(1.7)", immediateRender: false }, m.t1 + .05); ev("send", m.t1 + .05);
      for (let j = 0; j < k; j++) { const dd = k - j; tl.to(els[j], { y: -dd * (c.step || 150), opacity: Math.max(0, 1 - dd * .3), duration: .4, ease: "power3.out" }, m.t1 + .05); } }); };

  /* B: экран сообщений на белом — набор строки и отправка, ответ «печатает…» */
  A.messages = c => { const s = scene(c); const scr = mk("div", "a-msgs", `<div class="a-mh"><i></i>${c.title}</div><div class="a-ml"></div><div class="a-in"><span class="ph">Сообщение</span><span class="tx"></span><b>↑</b></div>`, `top:${c.top}px;height:${c.h}px`); s.appendChild(scr);
    spring(scr, c.t0, .92); ev("panel", c.t0); const lane = scr.querySelector(".a-ml"), inp = scr.querySelector(".tx"), ph = scr.querySelector(".ph"); const els = []; let y = 0;
    c.msgs.forEach((m, k) => { const sp = mk("span", "tl"); inp.appendChild(sp); gsap.set(sp, { display: "none" }); tl.set(sp, { display: "inline" }, m.t0); tl.set(sp, { display: "none" }, m.t1 + .08);
      tl.set(ph, { opacity: 0 }, m.t0); typeIn(sp, m.text, m.t0, m.t1); ev("type", m.t0, { d: m.t1 - m.t0 }); tl.set(ph, { opacity: 1 }, m.t1 + .08);
      const b = mk("div", "a-bub me", m.text); lane.appendChild(b); els.push(b); gsap.set(b, { display: "none" }); tl.set(b, { display: "block" }, m.t1 + .05);
      tl.fromTo(b, { opacity: 0, y: 60, scale: .9, transformOrigin: "100% 100%" }, { opacity: 1, y: 0, scale: 1, duration: .38, ease: "back.out(1.8)", immediateRender: false }, m.t1 + .05); ev("send", m.t1 + .05); });
    if (c.typing) { const d = mk("div", "a-bub ai", '<i>●</i> <i>●</i> <i>●</i>'); lane.appendChild(d); gsap.set(d, { display: "none" }); tl.set(d, { display: "block" }, c.typing[0]); tl.fromTo(d, { opacity: 0 }, { opacity: 1, duration: .2, immediateRender: false }, c.typing[0]);
      d.querySelectorAll("i").forEach((x, k) => tl.to(x, { opacity: .25, duration: .2, repeat: Math.max(1, Math.round((c.typing[1] - c.typing[0]) / .4)), yoyo: true }, c.typing[0] + k * .1)); ev("dots", c.typing[0], { d: c.typing[1] - c.typing[0] }); } };

  /* B: сегменты «Мало / Средне / Детали» + капсула «Сохранить → Сохранено ✓» */
  A.segment = c => { const s = scene(c); const g = glass("", `left:90px;top:${c.top}px;width:900px;height:360px`); s.appendChild(g); spring(g, c.t0, .8); ev("panel", c.t0);
    const l = mk("div", "a-sub", c.label, "left:56px;top:40px;color:#fff;font-size:40px;font-weight:800;text-transform:uppercase;letter-spacing:.03em"); g.appendChild(l); app(l, c.t0 + .15);
    const sg = mk("div", "a-seg", `<b></b>${c.opts.map(o => `<span>${o}</span>`).join("")}`); g.appendChild(sg); const kn = sg.querySelector("b"); gsap.set(kn, { x: 0 });
    c.steps.forEach((st, k) => { tl.to(kn, { x: st.i * 262, duration: .4, ease: "back.out(1.6)" }, st.t); ev("seg", st.t, { n: k }); });
    if (c.save) { const b = mk("div", "a-save", `<span class="s1">Сохранить</span><span class="s2">Сохранено ${OK}</span>`, ""); g.appendChild(b); spring(b, c.save.t, .6); ev("button", c.save.t);
      gsap.set(b.querySelector(".s2"), { opacity: 0 }); tl.to(b, { scale: .82, duration: .1 }, c.save.t2); tl.to(b, { scale: 1, duration: .3, ease: "back.out(3)" }, c.save.t2 + .1); tl.to(b.querySelector(".s1"), { opacity: 0, y: -24, duration: .14 }, c.save.t2); tl.fromTo(b.querySelector(".s2"), { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: .25, immediateRender: false }, c.save.t2 + .2); ev("saved", c.save.t2); } };

  /* C: стопка карточек (новая въезжает снизу, прошлые сжимаются назад) */
  A.stack = c => { const s = scene(c); const els = [];
    c.cards.forEach((cd, k) => { const g = glass("stk", `left:110px;top:${c.top}px;width:860px;height:250px`); g.innerHTML = `<div class="a-ico sm">${k + 1}</div><div class="a-cap" style="position:absolute;left:150px;top:44px">${cd.cap}</div><div class="a-hl" style="position:absolute;left:150px;top:92px;font-size:64px;white-space:nowrap">${cd.title}</div>`; s.appendChild(g); els.push(g);
      gsap.set(g, { opacity: 0 }); tl.fromTo(g, { y: 220, opacity: 0, scale: .96 }, { y: 0, opacity: 1, scale: 1, duration: .5, ease: "power3.out", immediateRender: false }, cd.t);
      for (let j = 0; j < k; j++) tl.to(els[j], { y: -(k - j) * 40, scale: 1 - (k - j) * .05, opacity: Math.max(0, 1 - (k - j) * .3), duration: .45, ease: "power3.out" }, cd.t); ev("card", cd.t, { n: k }); }); };

  /* C: кольцо активности с числом в центре */
  A.ring = c => { const s = scene(c); const g = glass("", `left:${c.x || 90}px;top:${c.top}px;width:${c.w || 900}px;height:${c.h || 420}px`); s.appendChild(g); spring(g, c.t0, .8); ev("panel", c.t0);
    const R = c.r || 130; const svg = sv("svg", { width: R * 2 + 40, height: R * 2 + 40, style: `position:absolute;left:44px;top:${((c.h || 420) - R * 2 - 40) / 2}px` }, g);
    sv("circle", { cx: R + 20, cy: R + 20, r: R, fill: "none", stroke: "rgba(255,255,255,.14)", "stroke-width": 30 }, svg);
    const arc = sv("circle", { cx: R + 20, cy: R + 20, r: R, fill: "none", stroke: "var(--acc)", "stroke-width": 30, "stroke-linecap": "round", pathLength: 100, "stroke-dasharray": 100, "stroke-dashoffset": 100, transform: `rotate(-90 ${R + 20} ${R + 20})` }, svg);
    tl.to(arc, { attr: { "stroke-dashoffset": 100 - c.to }, duration: c.d, ease: "power2.inOut" }, c.t); ev("ring", c.t, { d: c.d });
    const num = mk("div", "a-hl", c.from + (c.suf || ""), `position:absolute;left:44px;width:${R * 2 + 40}px;text-align:center;top:${(c.h || 420) / 2 - 56}px;font-size:${c.numSize || 96}px`); g.appendChild(num);
    if (c.countTo != null) count(num, c.from, c.countTo, c.t, c.t + c.d, v => v + (c.suf || ""));
    const tx = mk("div", "", null, `position:absolute;left:${R * 2 + 120}px;top:0;bottom:0;width:${(c.w || 900) - R * 2 - 160}px;display:flex;flex-direction:column;justify-content:center`); g.appendChild(tx);
    c.text.forEach((tt, k) => { const e = mk("div", k ? "a-sub" : "a-hl", tt.text, `position:static;font-size:${k ? 46 : 64}px;margin-top:${k ? 14 : 0}px;white-space:normal;${k && tt.acc ? "color:var(--acc);font-weight:700" : ""}`); tx.appendChild(e); app(e, tt.t); ev(k ? "sub" : "title", tt.t); }); };

  /* C: стеклянный список с золотыми галочками */
  A.rows = c => { const s = scene(c); const g = glass("", `left:80px;top:${c.top}px;width:920px;height:${120 + c.rows.length * 112}px`); s.appendChild(g); spring(g, c.t0, .85); ev("panel", c.t0);
    const h = mk("div", "a-hl", c.title.text, "left:52px;top:40px;font-size:66px"); g.appendChild(h); head(h, c.title.t); ev("title", c.title.t);
    c.rows.forEach((r, k) => { const row = mk("div", "a-rw", `<b>${OK}</b><span${r.size ? ` style="font-size:${r.size}px"` : ""}>${r.text}</span>`, `top:${140 + k * 112}px`); g.appendChild(row); app(row.querySelector("span"), r.t, "rise");
      gsap.set(row.querySelector("b"), { opacity: 0 }); spring(row.querySelector("b"), r.t + .15, .3); ev("check", r.t + .15, { n: k }); }); };

  /* хук с центровкой: блок по центру плашки, подпись по левому краю заголовка, пилюля по правому */
  A.hookC = c => { const s = scene(c); const g = glass("", `left:${c.x || 90}px;top:${c.top}px;width:${c.w || 900}px;height:${c.h}px;display:flex;align-items:center;justify-content:center`); s.appendChild(g); spring(g, c.t0, .8); ev("panel", c.t0);
    const box = mk("div", "", null, "display:flex;flex-direction:column;gap:10px"); g.appendChild(box);
    const sb = mk("div", "a-sub rel", c.sub.text, "align-self:flex-start;white-space:nowrap"); box.appendChild(sb); app(sb, c.sub.t); ev("sub", c.sub.t);
    const h = mk("div", "a-hl rel", c.title.text, `font-size:${c.title.size}px;white-space:nowrap`); box.appendChild(h); head(h, c.title.t); ev("title", c.title.t);
    const p = mk("div", "a-pill", c.pill.text, "position:relative;align-self:flex-end;margin-top:8px"); box.appendChild(p); gsap.set(p, { opacity: 0 }); spring(p, c.pill.t); ev("pill", c.pill.t); };
  window.AP = A;
})();
