#!/bin/bash
# post.sh <id> — линза для Apple-A, звук (loudnorm), сжатие crf 21 → final/
cd "$(dirname "$0")" && mkdir -p final_v3
declare -A N=([d2A]=D2_A_kalka [d2B]=D2_B_polosa [d2C]=D2_C_stranica [apA]=Apple_A_steklo [apB]=Apple_B_soobshcheniya [apC]=Apple_C_vidzhety [sgA]=Signal_A_laim [sgB]=Signal_B_krasnyi [sgC]=Signal_C_yantar)
declare -A L=([d2A]=-14 [d2B]=-14 [d2C]=-14 [apA]=-16 [apB]=-16 [apC]=-16 [sgA]=-16 [sgB]=-16 [sgC]=-16)
v=$1; src=$v/out.mp4
if [ "$v" = "apA" ]; then
  python3 lens.py $v/out.mp4 3.0 3.97 540 1220 $v/lens_seg.mp4 && \
  ffmpeg -v error -y -i $v/out.mp4 -i $v/lens_seg.mp4 -filter_complex "[1]setpts=PTS+3.0/TB[l];[0][l]overlay=enable='between(t,3.0,3.96)'" -c:v libx264 -crf 14 -pix_fmt yuv420p $v/out_lens.mp4 && src=$v/out_lens.mp4
fi
ffmpeg -v error -y -i $v/mix.wav -af loudnorm=I=${L[$v]}:TP=-1.4:LRA=9 -ar 48000 $v/mix_norm.wav
ffmpeg -v error -y -i $src -i $v/mix_norm.wav -map 0:v -map 1:a -c:v libx264 -crf 21 -preset medium -pix_fmt yuv420p -c:a aac -b:a 192k -shortest final_v3/demo4_${N[$v]}.mp4
echo "$v -> final_v3/demo4_${N[$v]}.mp4 $(du -h final_v3/demo4_${N[$v]}.mp4 | cut -f1)"
