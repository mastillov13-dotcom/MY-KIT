const { chromium } = require('playwright');
(async () => { const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
  for (const f of process.argv.slice(2)) { const p = await b.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
    await p.goto('file://' + f, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(1500);
    const ev = await p.evaluate(() => window.EV || null); console.log(JSON.stringify({ f, ev, errs })); await p.close(); }
  await b.close(); })();
