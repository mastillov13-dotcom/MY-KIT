#!/bin/bash
K="$(cd "$(dirname "$0")" && pwd)"
export HYPERFRAMES_BROWSER_PATH=${HYPERFRAMES_BROWSER_PATH:-/tmp/chromium}
for v in sgA apA d2A sgB apB d2B sgC apC d2C; do
  cd "$K/$v/proj" && rm -f ../out.mp4
  s=$(date +%s); npx hyperframes render -o ../out.mp4 > ../render.log 2>&1 < /dev/null
  echo "$v $(( $(date +%s) - s ))s $(stat -c %s ../out.mp4 2>/dev/null)" >> "$K/render_done.txt"
done
