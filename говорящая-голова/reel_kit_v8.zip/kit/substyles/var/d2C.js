/* D2 · C «Страница»: Dela Gothic + Pangolin, зум из размытия, переход «страница», карточки-веер, слова-удары, рецепт на доске, линейка */
(function () {
  const { T, E, mode, trans, zcut, punch, caps, finish } = X;
  D2.behind({ t: .15, out: 3.35, fx: "torch", gap: .35, lines: [{ text: "ЗАПРОС", size: 160, y: 150, x: 70 }, { text: "№1", size: 230, y: 340, x: 560, color: "var(--acc)" }] });
  D2.chest({ t0: T(0), out: 3.3, items: [{ role: "H", text: "ваш первый полезный запрос", size: 66, x: 90, y: 1070, t: T(1) }, { role: "S", text: "НЕ ПРО РАБОТУ", size: 76, x: 90, y: 1160, t: T(9), plate: 1 }],
    arrow: { x: 760, y: 1250, t: T(9) + .3, d: "M20 20 C 90 0, 170 40, 180 120", h: "M150 104 L182 128 L198 92" } });
  zcut(T(9), 1.18);
  trans("page", T(12));
  D2.fan({ t0: T(12), out: 11.45, x: 150, top: 1170, cards: [{ num: "01", title: "УЖИН", sub: "из того, что есть дома", t: T(13) }, { num: "02", title: "СООБЩЕНИЯ", sub: "как ответить на сложное", t: T(20) },
    { num: "03", title: "ПОЕЗДКА", sub: "собрать список вещей", t: T(25) }, { num: "04", title: "ДОКУМЕНТ", sub: "объяснить простыми словами", t: T(31) }] });
  trans("page", T(36));
  D2.hits({ t0: T(36), out: 15.45, words: [{ text: "ОДНА", size: 140, x: 90, y: 1020, t: T(37) }, { text: "МАЛЕНЬКАЯ", size: 96, x: 130, y: 1160, t: T(38) }, { text: "ЗАДАЧА", size: 96, x: 90, y: 1270, t: T(39), plate: 1 },
    { role: "H", text: "которую вы откладываете", size: 62, x: 90, y: 1395, t: T(42) }] });
  punch(15.88, 1.08);
  D2.chest({ t0: T(47), out: 24.8, items: [{ role: "H", text: "ваш запрос", size: 66, x: 90, y: 950, t: T(47), rot: -4 }] });
  D2.recipe({ t0: T(47) - .2, out: 24.8, x: 60, top: 1050, w: 960, h: 560, title: { text: "ПЛАН УЖИНА", t: T(47) },
    rows: [{ text: "курица, картофель, морковь, сметана", t: T(50) }, { text: "3 простых варианта", t: T(56) }, { text: "не дольше 40 минут", t: T(62) }, { text: "шаги + чего не хватает", t: T(67) }] });
  trans("page", T(74) + .1);
  D2.ruler({ t0: T(74), t1: 28.1, out: 28.25, top: 1070, title: "БОЛЬШЕ ДЕТАЛЕЙ", caps: false });
  caps({ y: 1450 }); finish();
})();
