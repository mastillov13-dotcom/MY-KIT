/* Сигнал · A «Лайм»: Unbounded + Geologica, выезд из-под линии, луч; счётчик + штамп, словарь, дерево в сплите, колонка в затемнении, формула */
(function () {
  const { T, E, mode, trans, zcut, punch, caps, finish, hud } = X;
  hud("ПЕРВЫЙ ЗАПРОС");
  SG.counter({ t0: .1, out: 3.3, top: 1030, from: 0, to: 1, d: .7, label: "ЗАПРОС", lt: .35, sub: { text: "ваш первый полезный", t: T(2) } });
  SG.stamp({ t0: T(9) - .2, out: 3.3, top: 1270, text: "НЕ ПРО РАБОТУ", size: 76, t: T(9), rot: -5 });
  trans("scan", T(12));
  SG.dict({ t0: T(12), out: 5.35, top: 1040, word: "ЗАПРОС", pos: "[СУЩ.]", def: { text: "задача из жизни. например — ужин из того, что есть дома", t: T(15) } });
  X.punch(T(19), 1.08);
  SG.tree({ t0: T(19) - .1, out: 11.45, top: 1010, root: { text: "ЗАДАЧИ", t: T(19) }, kids: [{ text: "СООБЩЕНИЕ", sub: "сложный ответ", t: T(20) }, { text: "ПОЕЗДКА", sub: "список вещей", t: T(25) }, { text: "ДОКУМЕНТ", sub: "простыми словами", t: T(31) }] });
  trans("scan", T(36));
  SG.stamp({ t0: T(37) - .2, out: 15.45, top: 1030, text: "ОДНУ", size: 200, t: T(37), rot: -6 });
  SG.note({ t0: T(38), out: 15.45, top: 1310, h: 150, bar: "nobar", lines: [{ text: "маленькую задачу, которую вы откладываете", t: T(38) + .1, y: 34, size: 46 }] });
  mode("dim", 15.6, .5);
  SG.column({ t0: T(47) - .1, out: 24.8, center: 1000, step: 150, lines: [{ type: "txt", text: "у меня есть", t: T(47) }, { type: "hl", text: "курица", t: T(50) }, { type: "hl", text: "картофель", t: T(51) }, { type: "hl", text: "морковь", t: T(52) }, { type: "pill", text: "и сметана", t: T(54) },
    { type: "txt", text: "предложи", t: T(55) }, { type: "hl", text: "3 ужина", t: T(56) }, { type: "pill", text: "на двоих", t: T(60) }, { type: "hl", text: "≤ 40 минут", t: T(64) }, { type: "txt", text: "напиши", t: T(66) }, { type: "pill", text: "шаги + продукты", t: T(67) }, { type: "hl", text: "ЧЕГО НЕ ХВАТАЕТ", size: 84, t: T(72) }] });
  mode("full", 25.0, .5); trans("scan", T(74) + .05);
  SG.formula({ t0: T(76), t1: 28.6, top: 1070, parts: [{ text: "ДЕТАЛИ", t: T(77) }, { text: "КОНТЕКСТ", t: T(79) }], result: { text: "ТОЧНЫЙ ОТВЕТ", t: T(81) } });
  zcut(T(9), 1.28); zcut(T(37), 1.22);
  caps({ y: 1370 }); finish();
})();
