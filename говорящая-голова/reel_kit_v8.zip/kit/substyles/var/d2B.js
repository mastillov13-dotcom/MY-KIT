/* D2 · B «Строгая полоса»: Oswald крупно въезжает + Bad Script подписью, графит + молочный, быстрый темп с толчками, переход «полоса» */
(function () {
  const { T, E, mode, trans, zcut, punch, caps, finish } = X;
  D2.behind({ t: .15, out: 3.35, fx: "flap", lines: [{ text: "НЕ ПРО", size: 190, y: 170 }, { text: "РАБОТУ", size: 220, y: 350, color: "var(--acc)" }], gap: .55 });
  D2.chest({ t0: T(0), out: 3.3, items: [{ role: "S", text: "ПЕРВЫЙ ЗАПРОС", size: 132, x: 80, y: 1070, t: T(1) }, { role: "H", text: "к нейросети", size: 84, x: 470, y: 1210, t: T(5), rot: -4 }] });
  zcut(T(9), 1.18);
  // четыре примера — вылеты перед экраном (как эталонный финал), быстрые толчки
  trans("band", T(12));
  D2.chest({ t0: T(12), out: T(19) - .12, items: [{ role: "S", text: "УЖИН", size: 190, x: 80, y: 1040, t: T(13) }, { role: "H", text: "из того, что есть дома", size: 82, x: 120, y: 1230, t: T(16), rot: -3 }] });
  punch(T(13), 1.12);
  D2.chest({ t0: T(19), out: T(24) - .12, items: [{ role: "S", text: "СООБЩЕНИЯ", size: 160, x: 80, y: 1050, t: T(20) }, { role: "H", text: "ответить на сложное", size: 82, x: 300, y: 1220, t: T(22), rot: -3 }] });
  punch(T(20), 1.12);
  D2.chest({ t0: T(24), out: T(30) - .12, items: [{ role: "S", text: "ПОЕЗДКА", size: 180, x: 80, y: 1040, t: T(25) }, { role: "H", text: "список вещей", size: 86, x: 420, y: 1230, t: T(26), rot: -3 }] });
  punch(T(25), 1.12);
  D2.chest({ t0: T(30), out: 11.5, items: [{ role: "S", text: "ДОКУМЕНТ", size: 170, x: 80, y: 1040, t: T(31) }, { role: "H", text: "простыми словами", size: 86, x: 320, y: 1225, t: T(34), rot: -3 }] });
  punch(T(31), 1.12);
  // одна задача: без скобок, выделение подписью
  trans("band", T(36));
  D2.chest({ t0: T(36) - .1, out: 15.45, items: [{ role: "S", text: "ОДНА ЗАДАЧА", size: 150, x: 80, y: 1070, t: T(37) }, { role: "H", text: "которую вы откладываете", size: 80, x: 90, y: 1240, t: T(40), color: "var(--acc)" }] });
  zcut(T(37), 1.25);
  // промпт на полном кадре: «40 минут» слева сверху, «было → стало» на груди
  punch(15.88, 1.1);
  D2.chest({ t0: T(47) - .1, out: T(55) - .12, items: [{ role: "S", text: "ЧТО ЕСТЬ", size: 170, x: 80, y: 1030, t: T(47) }, { role: "H", text: "курица, картофель, морковь, сметана", size: 54, x: 80, y: 1215, t: T(50), rot: -3 }] });
  punch(T(47), 1.1);
  D2.chest({ t0: T(55), out: T(61) - .12, items: [{ role: "S", text: "3 УЖИНА", size: 190, x: 80, y: 1030, t: T(56) }, { role: "H", text: "простых, на двоих", size: 80, x: 380, y: 1225, t: T(57), rot: -3 }] });
  punch(T(56), 1.12);
  D2.chest({ t0: T(61), out: T(66) - .12, items: [{ role: "S", text: "40 МИНУТ", size: 180, x: 80, y: 1030, t: T(64) }, { role: "H", text: "не дольше", size: 84, x: 520, y: 1225, t: T(62), rot: -3, color: "var(--acc)" }] });
  punch(T(64), 1.12);
  D2.chest({ t0: T(66), out: 24.8, items: [{ role: "S", text: "ШАГИ", size: 190, x: 80, y: 1030, t: T(67) }, { role: "H", text: "и чего не хватает", size: 82, x: 330, y: 1225, t: T(71), rot: -3 }] });
  punch(T(67), 1.12);
  trans("band", T(74) + .1);
  D2.behind({ t: T(77), out: 28.3, lines: [{ text: "ДЕТАЛИ", size: 250, y: 200 }] });
  D2.chest({ t0: T(74), out: 28.25, items: [{ role: "S", text: "БОЛЬШЕ ДЕТАЛЕЙ", size: 120, x: 80, y: 1070, t: T(75) }, { role: "S", text: "ТОЧНЕЕ ОТВЕТ", size: 84, x: 300, y: 1210, t: T(81), plate: 1 }] });
  caps({ y: 1450 }); finish();
})();
