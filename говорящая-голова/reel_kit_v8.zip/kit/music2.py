"""Динамичнее фон: 112 BPM, хаус-грув — бочка на каждую долю, клэп на 2 и 4,
шестнадцатые хэты, синкопированный бас, плак-арпеджио. Пишет music.wav (стерео 44.1 кГц)."""
import sys
import wave
import numpy as np
from scipy.signal import butter, sosfilt

SR = 44100
BPM = float(sys.argv[2]) if len(sys.argv) > 2 else 112
B = 60 / BPM
DUR = float(sys.argv[1]) if len(sys.argv) > 1 else 90.0
OUT = sys.argv[4] if len(sys.argv) > 4 else 'music.wav'
N = int(DUR * SR)
rng = np.random.default_rng(int(sys.argv[3]) if len(sys.argv) > 3 else 5)


def lp(x, f):
    return sosfilt(butter(2, f, 'low', fs=SR, output='sos'), x)


def hp(x, f):
    return sosfilt(butter(2, f, 'high', fs=SR, output='sos'), x)


def m(n):
    return 440 * 2 ** ((n - 69) / 12)


def add(buf, sig, at):
    s = int(at * SR)
    if s >= N:
        return
    e = min(N, s + len(sig))
    buf[s:e] += sig[: e - s]


kick, clap, hat, bass, pluck, pad = (np.zeros(N) for _ in range(6))
side = np.ones(N)
tk = np.arange(int(0.32 * SR)) / SR
kick_s = np.sin(2 * np.pi * np.cumsum(50 + 110 * np.exp(-tk * 35)) / SR) * np.exp(-tk * 10)
tc = np.arange(int(0.25 * SR)) / SR
clap_s = hp(rng.standard_normal(len(tc)), 900) * (np.exp(-tc * 28) + 0.5 * np.exp(-((tc - 0.012) * 300) ** 2))
th = np.arange(int(0.05 * SR)) / SR
hat_s = hp(rng.standard_normal(len(th)), 8000) * np.exp(-th * 90)

PROG = [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]]   # Am F C G
BASSN = [33, 29, 36, 31]
beats = int(DUR / B)
for b in range(beats):
    t0 = b * B
    bar = b // 4
    chord = PROG[(bar // 2) % 4]
    intro = b < 8                         # первые 2 такта без бочки — вход
    if not intro:
        add(kick, kick_s, t0)
        s = int(t0 * SR)
        sl = min(int(0.22 * SR), N - s)
        if sl > 0:
            side[s:s + sl] = np.minimum(side[s:s + sl], 0.4 + 0.6 * (np.arange(sl) / sl) ** 0.6)
    if b % 4 in (1, 3) and not intro:
        add(clap, clap_s, t0)
    for k in range(4):
        vel = 0.5 if k % 2 == 0 else 1.0
        if k == 2:
            vel = 1.2
        add(hat, hat_s * vel, t0 + k * B / 4)
    # бас: восьмые с синкопой
    for k, on in enumerate([0, 1, 0, 1]):
        if on and not intro:
            tb = np.arange(int(B / 2 * 0.9 * SR)) / SR
            f = m(BASSN[(bar // 2) % 4] + (12 if k == 3 else 0))
            sig = np.tanh(2.2 * np.sin(2 * np.pi * f * tb)) * np.exp(-tb * 5)
            add(bass, sig, t0 + k * B / 2)
    # плак: арпеджио шестнадцатыми через одну
    for k in range(0, 4, 1):
        if (b * 4 + k) % 3 == 0:
            note = chord[(b + k) % 3] + 12
            tp = np.arange(int(0.25 * SR)) / SR
            sig = (np.sin(2 * np.pi * m(note) * tp) + 0.3 * np.sin(4 * np.pi * m(note) * tp)) * np.exp(-tp * 14)
            add(pluck, sig, t0 + k * B / 4)
# пэд по 2 такта
for i in range(int(DUR / (8 * B)) + 1):
    t0 = i * 8 * B
    tp = np.arange(int(8 * B * SR)) / SR
    e = np.minimum(1, tp / 0.6) * np.minimum(1, (8 * B - tp) / 0.6)
    sig = sum(np.sin(2 * np.pi * m(n) * tp * (1 + d)) for n in PROG[i % 4] for d in (-0.002, 0.002)) * e
    add(pad, sig, t0)

mix = kick * 0.34 + clap * 0.12 + hat * 0.05 + lp(bass, 900) * 0.16 * side + lp(pluck, 4000) * 0.07 * side + lp(pad, 1500) * 0.035 * side
mix = lp(mix, 9000)
tt = np.arange(N) / SR
mix *= np.minimum(1, tt / 1.0) * np.clip((DUR - tt) / 2.5, 0, 1)
mix = mix / (np.max(np.abs(mix)) + 1e-9) * 0.85
left = mix + 0.004 * np.roll(lp(pluck, 4000), 300)
right = mix + 0.004 * np.roll(lp(pluck, 4000), -300)
st = np.stack([left, right], 1)
st = st / np.max(np.abs(st)) * 0.85
with wave.open(OUT, 'wb') as w:
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(SR)
    w.writeframes((st * 32767).astype(np.int16).tobytes())
print('music.wav', DUR)
