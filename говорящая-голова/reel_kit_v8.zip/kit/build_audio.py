"""Вставляет звуковую дорожку в шаблон: музыка + эффекты, дорожки раздаются автоматически
без перекрытий. Использование: python3 build_audio.py <проект> <plan.json>"""
import json
import subprocess
import sys

proj, plan_path = sys.argv[1], sys.argv[2]
plan = json.load(open(plan_path))
dur_cache = {}


def dur(f):
    if f not in dur_cache:
        dur_cache[f] = float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
                                                      '-of', 'csv=p=0', f'{proj}/{f}']).decode().strip())
    return dur_cache[f]


total = plan['total']
tags = [f'  <audio id="music" src="music.wav" data-start="0" data-duration="{total}" data-track-index="1" data-volume="{plan["music"]}"></audio>']
tracks = []   # конец последнего звука на каждой дорожке
for i, (f, t, v) in enumerate(sorted(plan['sfx'], key=lambda x: x[1])):
    d = min(dur(f), total - t)
    if d <= 0.02:
        continue
    k = next((j for j, end in enumerate(tracks) if end <= t - 0.01), None)
    if k is None:
        tracks.append(0)
        k = len(tracks) - 1
    tracks[k] = t + d
    tags.append(f'  <audio id="s{i:02d}" src="{f}" data-start="{t:.2f}" data-duration="{d:.2f}" data-track-index="{k + 2}" data-volume="{v}"></audio>')
html = open(plan['tpl'], encoding='utf-8').read().replace('<!--AUDIO-->', '\n'.join(tags))
open(f'{proj}/index.html', 'w', encoding='utf-8').write(html)
print(len(tags) - 1, 'sfx on', len(tracks), 'tracks')
