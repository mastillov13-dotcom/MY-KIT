# Кит «видео под текст» v1 (30.10.2026) — для скилла reel-motion-voiceover
Прикрепи этот архив в новый чат и напиши «видео под текст» + сценарий (стиль по умолчанию — СИСТЕМА).

## Что внутри
- SKILL_reel-motion-voiceover.md — копия скилла (все правила стилей, голос, порядок работы)
- templates/sistema — стиль СИСТЕМА (эталон «Система монтажа» v6): tpl.html, mix_ev.py, mix_lib.py (библиотеки a:/u:/r:)
- templates/bam, neon, katana — стили из «Трендов Genjutsu» (tpl.html + mix_ev.py)
- scripts — vo_proc.py (обработка голоса Леонида), chunks.py + asr.py + align2.py (тайминги слов),
  build.py (подстановка END), dbg2.js / export_ev.js (выгрузка BAMS/EV для звука), mix_tail.py (сведение),
  grab.js + prep.py (запасной захват кадров с сайта), mdx_sep.py + cut_sfx.py (отделить голос, вырезать звуки)
- assets — gsap.min.js + шрифт Inter (папка ap/assets композиции)
- fonts — Unbounded, Alumni Sans (папка ap/fonts композиции)
- sfx_library — alex_pack (a:), ui_pack (u:), apple_reel_pack (r:)

## Как Клоду развернуть
1. Распаковать; ap/assets ← assets, ap/fonts ← fonts.
2. В mix_lib.py поправить LIBS на путь к sfx_library этого кита.
3. Распознавание: sherpa-onnx zipformer-ru (pip install sherpa-onnx + модель с GitHub k2-fsa), путь M в asr.py.
4. Разделение голоса: модель UVR-MDX-NET-Inst_HQ_3.onnx с GitHub TRvlvr/model_repo (путь в mdx_sep.py).
5. Рендер: hyperframes (npm), HYPERFRAMES_BROWSER_PATH на headless_shell.
Видео-эталоны и голос-эталон — у Алекса в Downloads\video_pod_tekst_etalony и Downloads\Leonid_etalon.
